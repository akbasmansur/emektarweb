package tr.gov.sgk.emektarWeb.genel.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.validator.Field;
import org.apache.commons.validator.GenericValidator;
import org.apache.commons.validator.Validator;
import org.apache.commons.validator.ValidatorAction;
import org.apache.commons.validator.util.ValidatorUtils;
import org.apache.struts.action.ActionMessages;
import org.apache.struts.validator.Resources;


/**
 * ValidationUtil Helper class for performing custom validations that
 * aren't already included in the core Struts Validator.
 */
public class ValidationUtil{

    /*
     * Validates that two fields match.
     */
    public static boolean validateTwoFields(Object bean, ValidatorAction va,
                                            Field field, ActionMessages errors,
                                            HttpServletRequest request) {
        String value =
            ValidatorUtils.getValueAsString(bean, field.getProperty());
        String sProperty2 = field.getVarValue("secondProperty");
        String value2 = ValidatorUtils.getValueAsString(bean, sProperty2);

        if (!GenericValidator.isBlankOrNull(value)) {
            try {
                if (!value.equals(value2)) {
                    errors. add(field.getKey(),
                               Resources.getActionMessage(request, va, field));

                    return false;
                }
            } catch (Exception e) {
                errors.add(field.getKey(),
                           Resources.getActionMessage(request, va, field));

                return false;
            }
        }

        return true;
    }
    
    /*
     * Validates that user choose a valid date range
     */  
	public static boolean validateDateRange(Object bean, ValidatorAction va,
                                             Field field, ActionMessages errors, Validator validator,
                                             HttpServletRequest request) {
        boolean isValid = true;
        
        //Fetch the end date value.
        String endDate = ValidatorUtils.getValueAsString(bean, field.getProperty());
        
        //Fetch the start date value from the bean.

	  // String beginDate = ValidatorUtils.getValueAsString(bean, "beginDateField");
	   String otherField = field.getVarValue("beginDateField");
	   String beginDate = ValidatorUtils.getValueAsString( bean, otherField );


        // If either of the dates is blank pass the validation
        if (GenericValidator.isBlankOrNull(endDate) || GenericValidator.isBlankOrNull(beginDate)) {
            return isValid;
        }
        
        int passCode = compareDates(beginDate, endDate);
        
        switch(passCode){
        
        case 1: //Dates are equal
            isValid=false;
            errors.add(field.getKey(), Resources.getActionMessage(validator, request, va, field)); 
            break;
	 
        case 2: //Date range is invalid
            isValid=false;  
            errors.add(field.getKey(), Resources.getActionMessage(validator, request, va, field));   
            break;          
        }
        return isValid;
    }
    
    public static int compareDates(String beginDate, String endDate) {
        // default code if the dates are okay
        int passCodeValue = 0;
        // Convert both dates into their calendar objects.
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Calendar begin = new GregorianCalendar();
        Calendar end = new GregorianCalendar();
        try {
            begin.setTime((Date) formatter.parse(beginDate));
            end.setTime((Date) formatter.parse(endDate));
        } catch (ParseException e) {
            // Ignore parse exception
            return passCodeValue;
        }
        // Karsılastırılan iki tarih aynı
        if (begin.getTime().getTime() == end.getTime().getTime()) {
            passCodeValue = 1;
        // karsilastirilan tarih buyuk ise 2 doner
        } else if (end.before(begin)) {
            passCodeValue = 2;
        }
        // kucuk ise 0 doner
        
        return passCodeValue;
    }

    public static boolean validateSysdate( String ptarih ){
    	 SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
    	 Calendar today = new GregorianCalendar();
    	 Calendar tarih = new GregorianCalendar();    	 
    	 Boolean kontrol = false;    	 
    	 try{
    		 today = today.getInstance();
    		 tarih.setTime((Date) formatter.parse(ptarih));
    		 
    		 if(today.before(ptarih))
    			 kontrol=  false;
    		 else 
    			 kontrol = true; 
    	 }
    	 catch (ParseException e){
    		 
    	 }  
    	 return kontrol;
    }
}

