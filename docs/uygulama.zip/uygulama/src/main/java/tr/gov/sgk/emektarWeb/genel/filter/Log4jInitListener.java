package tr.gov.sgk.emektarWeb.genel.filter;

import java.net.URL;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.logging.log4j.core.config.Configurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import tr.gov.sgk.emektarWeb.genel.util.Sabit;
import tr.gov.sgk.emektarWeb.genel.util.SabitLokal;


public class Log4jInitListener implements ServletContextListener {

	private static final Logger log = LoggerFactory.getLogger(Log4jInitListener.class);
	
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {

	}

	@Override
	public void contextInitialized(ServletContextEvent e) {
	
		URL resource = null;
		
		System.out.println(">>> EMEKTARWEB - Log4jInitListener called...");

		resource = getClass().getClassLoader().getResource("log4j2.properties");	
		
		if (SabitLokal.ortam.compareTo(Sabit.ortamProd) == 0) {
			resource = getClass().getClassLoader().getResource("log4j2_Prod.xml");
		}else if (SabitLokal.ortam.compareTo(Sabit.ortamTest) == 0) {
			resource = getClass().getClassLoader().getResource("log4j2_Test.xml");
		} else if (SabitLokal.ortam.compareTo(Sabit.ortamLokal) == 0) {
			resource = getClass().getClassLoader().getResource("log4j2_Local.xml");
		}

		try {
			if (resource != null) {
				Configurator.reconfigure(resource.toURI());
			}
		} catch (Exception e1) {
			//e1.printStackTrace();
			log.error(e1.getMessage());
		}

		log.warn(">>> EMEKTARWEB - Log4jInitListener called..." + " -ortam:"+SabitLokal.ortam +" -version:"+SabitLokal.version);
	}
}

