package tr.gov.sgk.emektarWeb.genel.filter;


import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class HealthCheckFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        String uri = httpRequest.getRequestURI();
        String contextPath = httpRequest.getContextPath();
        String path = uri.substring(contextPath.length());

        if ("/health/liveness".equals(path)) {
            handleLivenessCheck(httpResponse);
            return;
        } else if ("/health/readiness".equals(path)) {
            handleReadinessCheck(httpResponse);
            return;
        }

        chain.doFilter(request, response);
    }

    private void handleLivenessCheck(HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        response.setStatus(HttpServletResponse.SC_OK);
        PrintWriter writer = response.getWriter();
        response.getWriter().write("{\"status\": \"UP\"}");
        writer.flush();
    }

    private void handleReadinessCheck(HttpServletResponse response) throws IOException {

        response.setStatus(HttpServletResponse.SC_OK);
        response.setContentType("application/json");
        response.getWriter().write("{\"status\": \"OK\"}");

    }


    @Override
    public void destroy() {

    }
}