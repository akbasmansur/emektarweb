<%@page language="java" contentType="text/html; charset=ISO-8859-9"
	pageEncoding="ISO-8859-9"%>
<%@page import="tr.gov.sgk.emektarWeb.genel.util.SabitLokal"%>
<div id="footer">
  		<div class="left">T�rkiye Cumhuriyeti Sosyal G�venlik Kurumu � 2014 v.<%=SabitLokal.version.toString() %></div>
  		<div class="right">
        	<ul class="horizontal" style="margin-top: 0px;">
                <li><a href="http://www.sgk.gov.tr/wps/portal/tr/e_sgk/diger_uygulamalar/bize_ulasin/" 
                       title="ileti�im V.1.3">
                       �leti�im
                       </a>
                </li>
            </ul>
        </div>
</div>