package tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.httpclient.util.DateParseException;
import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.validator.ValidatorForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.business.HizmetBilgileriService;
import tr.gov.sgk.emektarWeb.genel.util.GetTarih;
import tr.gov.sgk.emektarWeb.genel.util.Sabit;

public class HizmetBilgileriForm extends ValidatorForm implements Comparable<HizmetBilgileriForm>{

	private static final Logger log = LoggerFactory.getLogger(HizmetBilgileriForm.class);
	
	private static final long serialVersionUID = 3248957464375479100L;
	private Integer siraNo;
	private Integer hizmetTuru;
	private String baslangicTarihi;
	private String bitisTarihi;
	private String hizmetSuresi;
	private String fiiliHizmetSuresi;

	public Integer getHizmetTuru() {
		return hizmetTuru;
	}
	public void setHizmetTuru(Integer hizmetTuru) {
		this.hizmetTuru = hizmetTuru;
	}
	public String getBaslangicTarihi() {
		return baslangicTarihi;
	}
	public void setBaslangicTarihi(String baslangicTarihi) {
		baslangicTarihi=baslangicTarihi.replace('.', '/');
		baslangicTarihi=baslangicTarihi.replace('-', '/');
		this.baslangicTarihi = baslangicTarihi;
	}
	public String getBitisTarihi() {
		return bitisTarihi;
	}
	public void setBitisTarihi(String bitisTarihi) {
		bitisTarihi=bitisTarihi.replace('.', '/');
		bitisTarihi=bitisTarihi.replace('-', '/');
		this.bitisTarihi = bitisTarihi;
	}
	public String getHizmetSuresi() {
		return hizmetSuresi;
	}
	public void setHizmetSuresi(String hizmetSuresi) {
		this.hizmetSuresi = hizmetSuresi;
	}
	public String getFiiliHizmetSuresi() {
		return fiiliHizmetSuresi;
	}
	public void setFiiliHizmetSuresi(String fiiliHizmetSuresi) {
		this.fiiliHizmetSuresi = fiiliHizmetSuresi;
	}
	public Integer getSiraNo() {
		return siraNo;
	}
	public void setSiraNo(Integer siraNo) {
		this.siraNo = siraNo;
	}

	public ActionErrors validate(ActionMapping mapping, HttpServletRequest request){

		ActionErrors errors = super.validate(mapping, request);

		if(errors==null)
			errors = new ActionErrors();

		if(((EmeklilikBilgileriForm)request.getSession().getAttribute(Sabit.SESSION_EMEKLILIKBILGILERI)).getSadece3201() == false){
			if(!baslangicTarihi.equals("") && !bitisTarihi.equals("") && !hizmetSuresi.equals("")){
				Date yas18 = GetTarih.tarihinUstuneYilAyGunEkle(new Integer[]{18,0,0}, GetTarih.convertStringToDate(((EmeklilikBilgileriForm)request.getSession().getAttribute(Sabit.SESSION_EMEKLILIKBILGILERI)).getDogumTarihi(), ""));
				dogumTarihiniKontrolEt(errors, request);
			//	Yas18AltiHizmetKontroluYap(errors, yas18); 	//jazz:74126 28/05/2020 kontrol kapatildi
				hizmetlerCakisiyormu(errors, request);
				girilenHizmetSuresiniKontrolEt(errors, request);
				if(fiiliHizmetSuresi !=null && !fiiliHizmetSuresi.equals(""))
					fiiliHizmetSuresiniKontrolEt(errors, request);
				tamEmeklilikHizmetKontrolEt(errors, request);
				kismiEmeklilikHizmetKontrolEt(errors, request);
				askerlikBorclanmasiKontrol(errors, request);
			}
		} else{
			if(!bitisTarihi.equals("") && !hizmetSuresi.equals("")){
				baslangicTarihi = GetTarih.convertDateToString(GetTarih.tarihinUstuneYilAyGunCikart(HizmetBilgileriService.getYilAyGunArray(Integer.parseInt(hizmetSuresi)), GetTarih.convertStringToDate(bitisTarihi,""))) ;
				Date yas18 = GetTarih.tarihinUstuneYilAyGunEkle(new Integer[]{18,0,0}, GetTarih.convertStringToDate(((EmeklilikBilgileriForm)request.getSession().getAttribute(Sabit.SESSION_EMEKLILIKBILGILERI)).getDogumTarihi(), ""));
			//	Yas18AltiHizmetKontroluYap(errors, yas18);	//jazz:74126 28/05/2020 kontrol kapatildi
				if(GetTarih.convertStringToDate(baslangicTarihi, "").before(yas18))
					baslangicTarihi = GetTarih.convertDateToString(yas18);

				dogumTarihiniKontrolEt(errors, request);
				try {
					if(GetTarih.isAfterOrEqualTo(baslangicTarihi, bitisTarihi)){
						errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","\u00d6deme tarihi do\u011fum tarihi ile uyumlu de\u011fil. (Bor\u00e7lanma ba\u015flang\u0131\u00e7 tarihi 18 ya\u015f\u0131ndan \u00f6nce olamaz)"));
					}
				} catch (DateParseException e) {
//					e.printStackTrace();
					log.error("HizmetBilgileriForm-validate", e.getMessage());
				}

			}
		}
		return errors;
	}

	
	public void Yas18AltiHizmetKontroluYap(ActionErrors errors, Date yas18){

		try {
			if(hizmetTuru.equals(Sabit.HIZMETTURU_BAGKUR) || hizmetTuru.equals(Sabit.HIZMETTURU_SSK)){
				if(hizmetTuru.equals(Sabit.HIZMETTURU_SSK)){
					if(GetTarih.isAfterOrEqualTo(baslangicTarihi, Sabit.TARIH_01_04_1981) && GetTarih.isAfter(GetTarih.convertDateToString(yas18), baslangicTarihi)){
						errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","Hizmet ba\u015flang\u0131\u00e7 tarihi 18 ya\u015f\u0131ndan \u00f6nce olamaz"));
						return;
					}		
					if(GetTarih.isAfter(Sabit.TARIH_01_04_1981, baslangicTarihi) && GetTarih.isAfter(GetTarih.convertDateToString(yas18), baslangicTarihi)){
						if(GetTarih.isAfter(bitisTarihi, GetTarih.convertDateToString(yas18))){
							errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","18 ya\u015f\u0131na kadar olan ("+GetTarih.convertDateToString(yas18)+") hizmet aral\u0131\u011f\u0131n\u0131 ayr\u0131 giriniz"));
							return;
						}
					}
				}
				if(hizmetTuru.equals(Sabit.HIZMETTURU_BAGKUR)){
					if(GetTarih.isAfterOrEqualTo(baslangicTarihi, Sabit.TARIH_04_05_1979) && GetTarih.isAfter(GetTarih.convertDateToString(yas18), baslangicTarihi)){
						errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","Hizmet ba\u015flang\u0131\u00e7 tarihi 18 ya\u015f\u0131ndan \u00f6nce olamaz"));
						return;
					}		
					if(GetTarih.isAfter(Sabit.TARIH_04_05_1979, baslangicTarihi) && GetTarih.isAfter(GetTarih.convertDateToString(yas18), baslangicTarihi)){
						if(GetTarih.isAfter(bitisTarihi, GetTarih.convertDateToString(yas18))){
							errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","18 ya\u015f\u0131na kadar olan ("+GetTarih.convertDateToString(yas18)+") hizmet aral\u0131\u011f\u0131n\u0131 ayr\u0131 giriniz"));
							return;
						}
					}
				}
			}else{
				if(GetTarih.isAfter(GetTarih.convertDateToString(yas18), baslangicTarihi)){
					errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","Hizmet ba\u015flang\u0131\u00e7 tarihi 18 ya\u015f\u0131ndan \u00f6nce olamaz"));
					return;
				}
			}
		} catch (DateParseException e) {
			//e.printStackTrace();
			log.error("HizmetBilgileriForm-Yas18AltiHizmetKontroluYap", e.getMessage());
		}
	}


	public void dogumTarihiniKontrolEt(ActionErrors errors, HttpServletRequest request){

		String dogumTarihi = ((EmeklilikBilgileriForm)request.getSession().
				getAttribute(Sabit.SESSION_EMEKLILIKBILGILERI)).getDogumTarihi();
		try {
			if(!GetTarih.isAfter(baslangicTarihi, dogumTarihi)){
				errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","Hizmet ba\u015flang\u0131\u00e7 tarihi do\u011fum tarihinden \u00f6nce olamaz"));
			}
		} catch (DateParseException e) {
			//e.printStackTrace();
			log.error("HizmetBilgileriForm-dogumTarihiniKontrolEt", e.getMessage());
		}
	}

	public void hizmetlerCakisiyormu(ActionErrors errors, HttpServletRequest request){

		ArrayList<HizmetBilgileriForm> hizmetBilgileriList = (ArrayList<HizmetBilgileriForm>)request.getSession().
		getAttribute(Sabit.SESSION_HIZMETLISTESI);

		if(hizmetBilgileriList.size()>0)
			for(HizmetBilgileriForm hizmetForm:hizmetBilgileriList){
				if(!hizmetForm.getSiraNo().equals(siraNo) && GetTarih.tarihAraliklariKesisiyormu(baslangicTarihi, bitisTarihi, hizmetForm.getBaslangicTarihi(), hizmetForm.getBitisTarihi())){
					errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","Girmeye \u00e7al\u0131\u015ft\u0131\u011f\u0131n\u0131z hizmet aral\u0131\u011f\u0131 girilmi\u015f hizmetlerle \u00e7ak\u0131\u015fmaktad\u0131r."));
					break;
				}
			}
	}

	public void girilenHizmetSuresiniKontrolEt(ActionErrors errors, HttpServletRequest request){

		if(!GetTarih.convertStringToDate(getBitisTarihi(), "").before(GetTarih.convertStringToDate(Sabit.TARIH_01_10_2008, ""))){
			if(Integer.parseInt(hizmetSuresi) > GetTarih.getDateDifferenceForBagkur(baslangicTarihi, bitisTarihi)+1){
				errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","Hizmet s\u00fcresi fazla girilmi\u015f"));
			}
		}
		else 
			if(Integer.parseInt(hizmetSuresi) > GetTarih.getDateDifferenceForBagkur(baslangicTarihi, bitisTarihi)){
				errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","Hizmet s\u00fcresi fazla girilmi\u015f"));
			}


	}
	public void fiiliHizmetSuresiniKontrolEt(ActionErrors errors, HttpServletRequest request){

		if(Integer.parseInt(fiiliHizmetSuresi)*4 > Integer.parseInt(hizmetSuresi)){
			errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","Fiili hizmet s\u00fcresi fazla girilmi\u015f. (Hizmet s\u00fcresinin 1/4'\u00fcnden fazla olmamal\u0131.)"));
		}
	}

	public void tamEmeklilikHizmetKontrolEt(ActionErrors errors, HttpServletRequest request){
		if(((EmeklilikBilgileriForm)request.getSession().getAttribute(Sabit.SESSION_EMEKLILIKBILGILERI)).getMaluliyetVarmi().equals(Sabit.EVET) || 
				((EmeklilikBilgileriForm)request.getSession().getAttribute(Sabit.SESSION_EMEKLILIKBILGILERI)).getErkenYaslanmaVarmi().equals(Sabit.EVET)	) {
			//maluliyeti veya erken yaslanmasi olanlarda 01.06.2002 oncesi/sonrasi kontrolu yapmadik
			return;
		}

		if(((EmeklilikBilgileriForm)request.getSession().getAttribute(Sabit.SESSION_EMEKLILIKBILGILERI)).getEmeklilikTuru().equals(Sabit.EMEKLILIKTURU_TAM))
			//		if(hizmetTuru != Sabit.HIZMETTURU_BAGKUR && hizmetTuru != Sabit.HIZMETTURU_ASKERLIKBORC && hizmetTuru != Sabit.HIZMETTURU_YURTDISIBORC){
			try {
				if(Integer.parseInt(hizmetSuresi)< GetTarih.getDateDifferenceForBagkur(baslangicTarihi, bitisTarihi)){
					if(GetTarih.isAfter(bitisTarihi, Sabit.TARIH_01_06_2002) && !GetTarih.isAfterOrEqualTo(baslangicTarihi, Sabit.TARIH_01_06_2002)){
						errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","Hizmet aral\u0131\u011f\u0131n\u0131 01/06/2002 \u00f6ncesi ve sonras\u0131 \u015feklinde ayr\u0131 ayr\u0131 giriniz"));
					}
				}
				/**
				 * normal hizmet tam oldugunda 010620002 icin  bir soru yok.Fakat fiili hizmet girilirse, bu fiili ,
				hizmetlerin de 01062002 ye gore ayrilmasi gerekiyor.Dolayisiyla normal hizmetleri de 01062002 ye gore 
				bolerek fiili hizmetle beraber girilmesi saglanmalidir.
				 */
				else if(StringUtils.isNotBlank(fiiliHizmetSuresi) && Integer.parseInt(fiiliHizmetSuresi)>0) {
					if(GetTarih.isAfter(bitisTarihi, Sabit.TARIH_01_06_2002) && !GetTarih.isAfterOrEqualTo(baslangicTarihi, Sabit.TARIH_01_06_2002)){
						errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","Hizmet aral\u0131\u011f\u0131n\u0131 01/06/2002 \u00f6ncesi ve sonras\u0131 \u015feklinde ayr\u0131 ayr\u0131 giriniz"));
					}
				}
			}catch (DateParseException e) {
				//e.printStackTrace();
				log.error("HizmetBilgileriForm-tamEmeklilikHizmetKontrolEt", e.getMessage());
			}
			//	}
	}

	public void kismiEmeklilikHizmetKontrolEt(ActionErrors errors, HttpServletRequest request){
		if(((EmeklilikBilgileriForm)request.getSession().getAttribute(Sabit.SESSION_EMEKLILIKBILGILERI)).getMaluliyetVarmi().equals(String.valueOf(Sabit.EVET)) || 
				((EmeklilikBilgileriForm)request.getSession().getAttribute(Sabit.SESSION_EMEKLILIKBILGILERI)).getErkenYaslanmaVarmi().equals(String.valueOf(Sabit.EVET))	) {
			//maluliyeti veya erken yaslanmasi olanlarda 01.10.1999 oncesi/sonrasi kontrolu yapmadik.
			return;
		}

		if(((EmeklilikBilgileriForm)request.getSession().getAttribute(Sabit.SESSION_EMEKLILIKBILGILERI)).getEmeklilikTuru().equals(Sabit.EMEKLILIKTURU_KISMI))
			//		if(hizmetTuru != Sabit.HIZMETTURU_BAGKUR && hizmetTuru != Sabit.HIZMETTURU_ASKERLIKBORC && hizmetTuru != Sabit.HIZMETTURU_YURTDISIBORC){
			try {
				if(Integer.parseInt(hizmetSuresi)< GetTarih.getDateDifferenceForBagkur(baslangicTarihi, bitisTarihi)){
					if(GetTarih.isAfter(bitisTarihi, Sabit.TARIH_01_10_1999) && !GetTarih.isAfterOrEqualTo(baslangicTarihi, Sabit.TARIH_01_10_1999)){
						errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","Hizmet aral\u0131\u011f\u0131n\u0131 01/10/1999 \u00f6ncesi ve sonras\u0131 \u015feklinde ayr\u0131 ayr\u0131 giriniz"));
					}
				}
				/**
				 * normal hizmet tam oldugunda 01101999 icin  bir soru yok.Fakat fiili hizmet girilirse, bu fiili ,
				hizmetlerin de 01101999 ye gore ayrilmasi gerekiyor.Dolayisiyla normal hizmetleri de 01101999 ye gore 
				bolerek fiili hizmetle beraber girilmesi saglanmalidir.
				 */
				else if(StringUtils.isNotBlank(fiiliHizmetSuresi) && Integer.parseInt(fiiliHizmetSuresi)>0) {
					if(GetTarih.isAfter(bitisTarihi, Sabit.TARIH_01_10_1999) && !GetTarih.isAfterOrEqualTo(baslangicTarihi, Sabit.TARIH_01_10_1999)){
						errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","Hizmet aral\u0131\u011f\u0131n\u0131 01/10/1999 \u00f6ncesi ve sonras\u0131 \u015feklinde ayr\u0131 ayr\u0131 giriniz"));
					}
				}
			} catch (DateParseException e) {
//				e.printStackTrace();
				log.error("HizmetBilgileriForm-kismiEmeklilikHizmetKontrolEt", e.getMessage());
			}
			//	}
	}
	public int compareTo(HizmetBilgileriForm o){

		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		int returnValue=3;
		try {
			Date date1 = format.parse(baslangicTarihi);
			Date date2 = format.parse(o.getBaslangicTarihi());

			if(date1.after(date2))
				returnValue = 1;
			else if(date2.after(date1))
				returnValue= -1;
			else returnValue= 0;
		} catch (ParseException e) {
//			e.printStackTrace();
			log.error("HizmetBilgileriForm-compareTo", e.getMessage());
		}
		return returnValue;
	}

	public void askerlikBorclanmasiKontrol(ActionErrors errors, HttpServletRequest request){
		String cinsiyet = ((EmeklilikBilgileriForm)request.getSession().getAttribute(Sabit.SESSION_EMEKLILIKBILGILERI)).getCinsiyet();
		if(hizmetTuru.equals(Sabit.HIZMETTURU_ASKERLIKBORC) && cinsiyet.equals(Sabit.CINSIYET_KADIN)){
			errors.add(ActionErrors.GLOBAL_MESSAGE, new ActionMessage("error.hata","Bayanlar i\u00e7n askerlik bor\u00e7lanmas\u0131 girilemez"));			
		}
	}

}
