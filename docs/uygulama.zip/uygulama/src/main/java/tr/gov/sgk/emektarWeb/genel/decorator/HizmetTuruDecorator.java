/**
 * 
 */
package tr.gov.sgk.emektarWeb.genel.decorator;
import java.util.ResourceBundle;

import javax.servlet.jsp.PageContext;

import org.displaytag.decorator.DisplaytagColumnDecorator;
import org.displaytag.exception.DecoratorException;
import org.displaytag.properties.MediaTypeEnum;

import tr.gov.sgk.emektarWeb.genel.util.Arac;
import tr.gov.sgk.emektarWeb.genel.util.Sabit;


public class HizmetTuruDecorator implements DisplaytagColumnDecorator
{
	public Object decorate(Object columnValue, PageContext pageContext, MediaTypeEnum media) throws DecoratorException {
		if (columnValue != null) {
			ResourceBundle bundle = Arac.getResourceBundle(pageContext.getRequest().getLocale());
			if (bundle != null) {
				if (((Integer)columnValue).intValue()==Sabit.HIZMETTURU_BAGKUR)  {
					return "Ba\u011fkur";
				}
				else if (((Integer)columnValue).intValue()==Sabit.HIZMETTURU_SSK){
					return "SSK";
				}
				else if (((Integer)columnValue).intValue()==Sabit.HIZMETTURU_ES){
					return "Emekli Sand\u0131\u011f\u0131";
				}
				else if (((Integer)columnValue).intValue()==Sabit.HIZMETTURU_DS){
					return "Di\u011fer Sand\u0131klar";
				}
				else if (((Integer)columnValue).intValue()==Sabit.HIZMETTURU_YURTDISIBORC){
					return "Yurt d\u0131\u015f\u0131 bor\u00e7lanmas\u0131";
				}
				else if (((Integer)columnValue).intValue()==Sabit.HIZMETTURU_ASKERLIKBORC){
					return "Askerlik bor\u00e7lanmas\u0131";
				}
				else if (((Integer)columnValue).intValue()==Sabit.HIZMETTURU_VERGIBORCLANMASI){
					return "Vergi bor\u00e7lanmas\u0131";
				}

			}
		}
		return "";
	}
}
