package tr.gov.sgk.emektarWeb.genel.util;
 
public class SabitLokal {
	
	public static final String version = "1.1.0";
	public static final String ortam = System.getenv().getOrDefault("UYG_PROFIL", "***"); //server.env
	public static final String ortamDB = System.getenv().getOrDefault("EMEKTAR_DB_NAME", "***"); //server.xml > databaseName
	public static final String ortamAdresLocal = System.getProperty("uyg.properties.path.local"); //bootstrap.properties
	public static final String ortamAdres =	(ortam.compareTo(Sabit.ortamLokal)==0 ?  ortamAdresLocal : System.getenv().getOrDefault("UYG_PROPERTIES_PATH", "***")) ; //Dockerfile
	public static final String uygulamaAd = "EMEKTARWEB";
	//properties dosyasi kullanilmiyor. kullanildiginda acılacak..

}