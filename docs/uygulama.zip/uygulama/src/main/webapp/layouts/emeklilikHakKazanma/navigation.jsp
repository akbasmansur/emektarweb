<%@page language="java" contentType="text/html; charset=ISO-8859-9"
	pageEncoding="ISO-8859-9"%>
<%@taglib prefix="bean" uri="/WEB-INF/config/tld/struts-bean.tld"%>
<%@taglib prefix="display" uri="/WEB-INF/config/tld/displaytag.tld"%>
<%@taglib prefix="tiles" uri="/WEB-INF/config/tld/struts-tiles.tld"%>
<%@taglib prefix="html" uri="/WEB-INF/config/tld/struts-html.tld"%>
<%@taglib prefix="logic" uri="/WEB-INF/config/tld/struts-logic.tld"%>
<%@taglib prefix="nested" uri="/WEB-INF/config/tld/struts-nested.tld"%>
<%@taglib prefix="emektar" uri="/WEB-INF/config/tld/emektar.tld"%>

<script language="JavaScript">
	function goToPage(url) {
		window.location = '/EMEKTARWEB' + url;
	}
	
</script>
<tiles:importAttribute />
	<table width="100%" border="0" cellspacing="1" cellpadding="3" class="menuText" bgcolor="#AFAFAF" style="margin-bottom:4px;">
		<tr>
			<td class="menuHeader"><html:img page="/img/topFrame/menuDot.gif" /> ��lemler</td>
		</tr>
		<logic:iterate id="item" name="Links" type="org.apache.struts.tiles.beans.MenuItem">
			<bean:define id="link" name="item" property="link" type="java.lang.String" />
			<tr>
				<td bgcolor="#FFFFFF">
					<a href="javascript:goToPage('<%=link%>')"> <html:img
				page="/img/topFrame/menuLinkDot.gif" align="absmiddle" border="none"/> <bean:write
				name="item" property="value" /></a>
				</td>
		</tr>
		</logic:iterate>
	</table>


