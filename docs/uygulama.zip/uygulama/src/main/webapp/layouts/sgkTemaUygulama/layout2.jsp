<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<%@page language="java" contentType="text/html; charset=ISO-8859-9"
	pageEncoding="ISO-8859-9"%>
	
<%@taglib prefix="bean" uri="/WEB-INF/config/tld/struts-bean.tld"%>
<%@taglib prefix="display" uri="/WEB-INF/config/tld/displaytag.tld"%>
<%@taglib prefix="tiles" uri="/WEB-INF/config/tld/struts-tiles.tld"%>
<%@taglib prefix="html" uri="/WEB-INF/config/tld/struts-html.tld"%>
<%@taglib prefix="logic" uri="/WEB-INF/config/tld/struts-logic.tld"%>
<%@taglib prefix="nested" uri="/WEB-INF/config/tld/struts-nested.tld"%>
<%@taglib prefix="emektar" uri="/WEB-INF/config/tld/emektar.tld"%>

<tiles:useAttribute name="Links" scope="request"/>
<%@page import="tr.gov.sgk.emektarWeb.genel.util.Sabit"%>
<%@page import="java.util.ResourceBundle"%>
<%@page import="tr.gov.sgk.emektarWeb.genel.util.Arac"%>

<html xmlns="http://www.w3.org/1999/xhtml" >

<head>
	<title>T.C. Sosyal G�venlik Kurumu</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9"></meta>
	<meta http-equiv="Pragma" content="no-cache"></meta>
	<meta http-equiv="Expires" content="-1"></meta>
	<meta http-equiv="cache-control" content="no-cache"></meta>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9"></meta>
	
<link type="text/css" rel="stylesheet" href="css/style.css" />
<link type="text/css" rel="stylesheet" href="css/displayTag.css" />
<script type="text/javascript" src="js/displayTag/tablo.js"></script>
<script type="text/javascript" src="js/PopUp.js"></script>
<script type="text/javascript" src="js/utils.js"></script>
<script type="text/javascript" src="js/window/windows.js"></script>
<script type="text/javascript" src="js/window/prototype.js"> </script>
<script type="text/javascript" src="js/window/effects.js"> </script>
<script type="text/javascript" src="js/window/debug.js"> </script>

<script type="text/javascript" src="js/scriptsSGK/sgk_main.js"> </script>

<link type="text/css" rel="stylesheet" href="css/window/alphacube.css"/>
<link type="text/css" rel="stylesheet" href="css/window/default.css"/>

<script type="text/javascript" src="js/calendar/date.js"></script>
<script type="text/javascript" src="js/calendar/dateFormat.js"></script>
<script> invalidDate = 'gecersiz tarih'; </script>
<script type="text/javascript" src="js/calendar/calendar.js"></script>
<script type="text/javascript" src="js/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="js/calendar/calendar-tr.js"></script>
<style> @import url("<%=Sabit.ANA_DIZIN%>css/calendar/calendar-system.css"); </style>

<script type='text/javascript' src="js/staticJavascript.js"></script>
	
	<script language="JavaScript">
		var maxExportKayitSayisi = <%= Sabit.MAX_EXPORT_SIZE %>;
		var maxExportUyarisi = ' ';
	
		function paintTheRow(row) {
			row.style.cursor='hand';
			row.style.background='#EAF4FF';
		}
		function resetTheRowColor(row) {
			row.style.background='#FFFFFF';
		}
		
		function browser(){
			if ((navigator.appName).indexOf("Microsoft")!=-1){  
				return true;
			}
			else{ 
				alert("Bu uygulama Microsoft Internet Explorer taray�c�s� ile uyumludur.");
				return false;
			}
		}
		function goToPage(url) {
			window.location = '/EMEKTARWEB' + url;
		}
	
	</script>
	
<%
	ResourceBundle bundle = Arac.getResourceBundle(request);
%>

<script language="javascript">
	var secinizUyarisi = '<%=Arac.getBundleValue(bundle, "label.genel.kayitSeciniz")%>';
	var siliniyorUyarisi = '<%=Arac.getBundleValue(bundle, "label.genel.silinecek")%>';
	
</script>
</head>

<body onload="browser();" style="margin:0px; padding: 0px; border: 0px;" >
<table align="center" border="0" >
    <tr> 
		<td>
 		<tiles:insert  attribute="header"/>
  	    <tiles:insert attribute="navigation"/>
      		<div class="contentContainer">
      			<table align="center" border="0">     
      				<tr> 
      					<td>  		 
					 	<logic:iterate id="item" name="Links" type="org.apache.struts.tiles.beans.MenuItem">
						<bean:define id="link" name="item" property="link" type="java.lang.String" />
      						<div align="center" style="font-weight: bold; font-size: large"  >
   		 						<a  href="javascript:goToPage('<%=link%>')">
   		 							<bean:write	name="item" property="value" />
   		 						</a>
   		 					</div>
						</logic:iterate>
						<br>	 					
      					</td>
      				</tr>
      				<tr>
      					<td>
						<tiles:insert attribute="messages"/>
						<tiles:insert attribute="content"/>
						</td>
					</tr>
				</table>
			  </div>	
 			<tiles:insert attribute="footer"/>
 		</td>
 	</tr>
</table>
</body>
</html>
