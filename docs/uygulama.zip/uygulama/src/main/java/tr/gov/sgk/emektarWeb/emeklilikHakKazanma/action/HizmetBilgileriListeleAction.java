package tr.gov.sgk.emektarWeb.emeklilikHakKazanma.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm.HizmetBilgileriForm;
import tr.gov.sgk.emektarWeb.genel.util.Sabit;

public class HizmetBilgileriListeleAction extends Action {

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ArrayList<HizmetBilgileriForm> sessionHizmetListesi = (ArrayList<HizmetBilgileriForm>)request.getSession().getAttribute(Sabit.SESSION_HIZMETLISTESI);
		
		request.setAttribute(Sabit.LISTE, sessionHizmetListesi);

		return mapping.findForward(Sabit.SUCCESS);
	}
}