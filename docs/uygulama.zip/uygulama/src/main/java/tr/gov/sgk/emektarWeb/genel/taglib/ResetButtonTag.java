package tr.gov.sgk.emektarWeb.genel.taglib;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;


public class ResetButtonTag extends TagSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String formName = null;

	public String getFormName() {
		return formName;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

	private String getButton() {
		String html = "";
		html += "<INPUT type='button' value=\"Temizle\"	class='buton' onclick=\"formTemizle('"+formName+"')\">";
/*		html += "var form = '"+formName+"';  var elements, i, elm; ";
		html += "form = document.getElementById ";
		html += "  ? document.getElementById(form) ";
		html += "  : document.forms[form]; ";
		html += "	if (document.getElementsByTagName)";
		html += "	{";
		html += "		elements = form.getElementsByTagName('input');";
		html += "		for( i=0, elm; elm=elements.item(i++); )";
		html += "		{";
		html += "			if (elm.getAttribute('type') == 'text' || elm.getAttribute('type') == 'hidden')";
		html += "			{";
		html += "			elm.value = '';";
		html += "		}";
		html += "	}";
		html += "	}";
		html += "else";
		html += "	{";
		html += "	elements = form.elements;";
		html += "	for( i=0, elm; elm=elements[i++]; )";
		html += "	{";
		html += "		if (elm.type == 'text' || elm.type == 'hidden' )";
		html += "		{";
		html += "			elm.value ='';";
		html += "		}";
		html += "	}";
		html += "	}";
		html += "	elements = form.getElementsByTagName('select');";
		html += "	for( i=0, elm; elm=elements.item(i++); )";
		html += "		{";
		html += "			elm.options.selectedIndex=0;";
		html += "		}";
		html += "\" >";
*/
		/*html += "<INPUT type='button' value=\"Temizle\"	class='buton'";
		html += " onclick=' "+formName+".reset(); ' >";*/
		return html;
	}

	public int doStartTag() throws JspException {

		try {
			JspWriter out = pageContext.getOut();

			out.print(getButton());
		} catch (Exception ex) {
			throw new JspException(ex.getMessage());
		} finally {
			this.release();
		}
		return SKIP_BODY;
	}

	/**
	 * Release any acquired resources.
	 */
	public void release() {
		super.release();
		formName = null;
	}

}
