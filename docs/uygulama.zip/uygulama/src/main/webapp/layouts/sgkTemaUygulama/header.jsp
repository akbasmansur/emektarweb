<%@page language="java" contentType="text/html; charset=ISO-8859-9"
	pageEncoding="ISO-8859-9"%>

<div id="wrapper"> 
	<div id="header">
    	<h1 id="logo" title="T.C. Sosyal G�venlik Kurumu">T.C. SOSYAL G�VENL�K KURUMU</h1>
   </div>
</div>
