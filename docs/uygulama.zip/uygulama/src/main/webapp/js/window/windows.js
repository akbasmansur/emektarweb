// Copyright (c) 2006 Meteksan Sistem ve Bilgisayar Teknolojileri A.S. (http://www.meteksan.com.tr)
// 
// TWindow, TUIK Kapsamimdaki projeler dahilinde kullanilmakta
// olan web arayuzlerinde bulunan interaktif pencerelerin iskelet kodunu icerir.
// 
// @author Mehmet Dogus Uysal - 27.Haz.2006 
//


var xidx = 0;					// Artan ID soneki
var cascade = 0;				// Yeni acilan pencerenin kaydirma katsayisi
var cOffset = 23;				// Yeni acilan pencerenin kaydirma miktari

// Constructor		
// Parametreler:	id, className, title, minWidth, minHeight, maxWidth, maxHeight, width, height, top, left, bottom, right, resizable, zIndex, opacity, 
//					hideEffect, showEffect, showEffectOptions, hideEffectOptions, effectOptions, url, draggable, closable, minimizable, maximizable, parent, onload
function TWindow(parameters){

	this.myWindow;
	
	this.id= "IKS_WINDOW"+xidx;
	
	this.className= "dialog";	
	
	this.title= "&nbsp;"
	
	this.minWidth= 100;
	this.minHeight= 20;
	this.maxWidth;
	this.maxHeight;
	
	this.width= 300;
	this.height= 400;	
		
	this.top= 100 +(cascade*cOffset);
	this.left= 250 +(cascade*cOffset);
	this.bottom;
	this.right;

	this.resizable = true;
		
	this.zIndex= 100;
	this.opacity= 1;
		
	this.hideEffect = Element.hide;	
	this.showEffect = Element.show;
	this.showEffectOptions;
	this.hideEffectOptions;
	this.effectOptions;

	this.url= "about:blank";

	this.draggable= true;
	this.closable= true;
	this.minimizable= true;
	this.maximizable= true;
	
	this.parent= document.getElementsByTagName("body").item(0);
	this.onLoad;
	this.close=closeMyWindow;
	this.show=showMyWindow;	
	
	if(parameters!=null){
		if(parameters.id != null){
			this.id= parameters.id;	
		}
		if(parameters.className != null){
			this.className= parameters.className;	
		}	
		if(parameters.title!= null){
			this.title= parameters.title;	
		}	
		
		if(parameters.minWidth!= null){
			this.minWidth= parameters.minWidth;	
		}
		if(parameters.minHeight!= null){
			this.minHeight= parameters.minHeight;	
		}
		if(parameters.maxWidth!= null){
			this.maxWidth= parameters.maxWidth;	
		}
		if(parameters.maxHeight!= null){
			this.maxHeight= parameters.maxHeight;	
		}	
		
		if(parameters.width!= null){
			this.width= parameters.width;	
		}	
		if(parameters.height!= null){
			this.height= parameters.height;	
		}	
				
		if(parameters.top!= null){
			this.top= parameters.top;	
		}	
		if(parameters.left!= null){
			this.left= parameters.left;	
		}			
		if(parameters.bottom!= null){
			this.bottom= parameters.bottom;	
		}			
		if(parameters.right!= null){
			this.right= parameters.right;	
		}	
		
		if(parameters.resizable!= null){
			this.resizable= parameters.resizable;	
		}		
		
		if(parameters.zIndex!= null){
			this.zIndex= parameters.zIndex;	
		}			
		if(parameters.opacity!= null){
			this.opacity= parameters.opacity;	
		}			

		if(parameters.hideEffect!= null){
			this.hideEffect= parameters.hideEffect;	
		}			
		if(parameters.showEffect!= null){
			this.showEffect= parameters.showEffect;	
		}	
		if(parameters.showEffectOptions!= null){
			this.showEffectOptions= parameters.showEffectOptions;	
		}			
		if(parameters.hideEffectOptions!= null){
			this.hideEffectOptions= parameters.hideEffectOptions;	
		}			
		if(parameters.effectOptions!= null){
			this.effectOptions= parameters.effectOptions;	
		}			
		
		if(parameters.url!= null){
			this.url= parameters.url;	
		}	

		if(parameters.draggable!= null){
			this.draggable= parameters.draggable;	
		}	
		if(parameters.closable!= null){
			this.closable= parameters.closable;	
		}	
		if(parameters.minimizable != null){
			this.minimizable= parameters.minimizable ;	
		}	
		if(parameters.maximizable != null){
			this.maximizable= parameters.maximizable;	
		}	

		if(parameters.parent != null){
			this.parent= parameters.parent;	
		}	
		if(parameters.onLoad != null){
			this.onLoad= parameters.onLoad;	
		}

	}

}


// showMyWindow		Gecerli pencereyi goruntuler
// Parametreler:	
function showMyWindow(){
		
	this.myWindow = new Window(this.id, {className: this.className, title: this.title, minWidth: this.minWidth, minHeight: this.minHeight, maxWidth: this.maxWidth, maxHeight: this.maxHeight, width: this.width, height: this.height, top: this.top, left: this.left, bottom: this.bottom, right: this.right, resizable: this.resizable, zIndex: this.zIndex, opacity: this.opacity, hideEffect: this.hideEffect, showEffect: this.showEffect, showEffectOptions: this.showEffectOptions, effectOptions: this.effectOptions, url: this.url, draggable: this.draggable, closable: this.closable,  minimizable: this.minimizable, maximizable: this.maximizable, parent: this.parent});
		
	this.myWindow.show();
	this.myWindow.toFront();
	this.myWindow.setConstraint(true, {left:0, right:0, top: 30, bottom:10});
	this.myWindow.setDestroyOnClose();
	cascade++;
	xidx++;
}

// closeMyWindow	Gecerli pencereyi kapatir	
// Parametreler:	
function closeMyWindow(){
	this.myWindow.close();
}

