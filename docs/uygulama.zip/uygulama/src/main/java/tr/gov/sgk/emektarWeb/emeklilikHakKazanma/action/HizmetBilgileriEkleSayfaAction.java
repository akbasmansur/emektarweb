package tr.gov.sgk.emektarWeb.emeklilikHakKazanma.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm.EmeklilikBilgileriForm;
import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm.HizmetBilgileriForm;
import tr.gov.sgk.emektarWeb.genel.util.Sabit;

public class HizmetBilgileriEkleSayfaAction extends Action {

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		HizmetBilgileriForm hizmetBilgileriForm = (HizmetBilgileriForm)form;
		
		if(((EmeklilikBilgileriForm)request.getSession().getAttribute(Sabit.SESSION_EMEKLILIKBILGILERI)).getSadece3201()==true){
			if(((ArrayList<HizmetBilgileriForm>)request.getSession().getAttribute(Sabit.SESSION_HIZMETLISTESI)).size()>=1){
				ActionMessages messages = new ActionMessages();
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("error.hata","Yurt d\u0131\u015f\u0131 bor\u00e7lanma hizmeti tek kalemde girilir"));
				saveErrors(request, messages);
				
				return mapping.getInputForward();
			}
		}
		
		return mapping.findForward(Sabit.SUCCESS);
	}
}