package tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm;

import org.apache.commons.lang.StringUtils;
import org.apache.struts.validator.ValidatorForm;
import tr.gov.sgk.emektarWeb.genel.util.Sabit;

public class EmeklilikBilgileriForm extends ValidatorForm{
	
	private static final long serialVersionUID = -8043619923867770551L;
	private String emeklilikTuru;
	private String emeklilikTuruString;
	private String cinsiyet;
	private String cinsiyetString;
	private String dogumTarihi;
	private String maluliyetVarmi;
	private String maluliyetVarmiString;
	private String maluliyetDerecesi;
	private String maluliyetDerecesiString;
	private String erkenYaslanmaVarmi;
	private String erkenYaslanmaVarmiString;
	private boolean sadece3201;
	private String sadece3201String;
	// bakıma muhtaç çocuğa sahip sigortalılar için
	private boolean bakMuhCoc;
	private String bakGunSayisi;// 1.10.2008 sonrası bakılan gün sayısı
	private String bakMuhCocString;
	public boolean getSadece3201() {
		return sadece3201;
	}
	public void setSadece3201(boolean sadece3201) {
		this.sadece3201 = sadece3201;
	} 
	public String getSadece3201String() {
		if(sadece3201 == true)
			return "Evet";
		else return "Hay\u0131r";
	}
	public void setSadece3201String(String sadece3201String) {
		this.sadece3201String = sadece3201String;
	}
	public String getEmeklilikTuruString() {
//		System.out.println(emeklilikTuru);
		
		if((maluliyetVarmi!=null && Integer.valueOf(maluliyetVarmi).equals(Sabit.EVET)) ||
		   (erkenYaslanmaVarmi!=null && Integer.valueOf(erkenYaslanmaVarmi).equals(Sabit.EVET)))
			return "\u00d6zel durum";
		
		if(emeklilikTuru.equals(Sabit.EMEKLILIKTURU_TAM))
			return "Tam";
		else if(emeklilikTuru.equals(Sabit.EMEKLILIKTURU_KISMI))
			return "K\u0131smi";
		else return "";
	}
	public void setEmeklilikTuruString(String emeklilikTuruString) {
		this.emeklilikTuruString = emeklilikTuruString;
	}
	public String getCinsiyetString() {
		if(cinsiyet.equals(Sabit.CINSIYET_ERKEK))
			return "Erkek";
		else if(cinsiyet.equals(Sabit.CINSIYET_KADIN))
			return "Kad\u0131n";
		else return "";
	}
	public void setCinsiyetString(String cinsiyetString) {
		this.cinsiyetString = cinsiyetString;
	}
	public String getMaluliyetVarmiString() {
		
		if(maluliyetVarmi != null && maluliyetVarmi.equals(String.valueOf(Sabit.EVET)))
			return "Evet";
		else return "Hay\u0131r";
	}
	public void setMaluliyetVarmiString(String maluliyetVarmiString) {
		this.maluliyetVarmiString = maluliyetVarmiString;
	}
	public String getMaluliyetDerecesiString() {
		if(maluliyetDerecesi!= null){
			if(maluliyetDerecesi.equals(Sabit.MALULIYET_40_49))
				return "40-49";
			else if(maluliyetDerecesi.equals(Sabit.MALULIYET_50_59))
				return "50-59";
			else if(maluliyetDerecesi.equals(Sabit.MALULIYET_60_100))
				return "60 ve \u00dczeri";
			else return "0";
		}
		else return "0";
	}
	public void setMaluliyetDerecesiString(String maluliyetDerecesiString) {
		this.maluliyetDerecesiString = maluliyetDerecesiString;
	}
	public String getErkenYaslanmaVarmiString() {
		if(erkenYaslanmaVarmi!=null && erkenYaslanmaVarmi.equals(String.valueOf(Sabit.EVET)))
			return "Evet";
		else return "Hay\u0131r";
	}
	public void setErkenYaslanmaVarmiString(String erkenYaslanmaVarmiString) {
		this.erkenYaslanmaVarmiString = erkenYaslanmaVarmiString;
	}
	public String getEmeklilikTuru() {
		return emeklilikTuru;
	}
	public void setEmeklilikTuru(String emeklilikTuru) {
		this.emeklilikTuru = emeklilikTuru;
	}
	public String getCinsiyet() {
		return cinsiyet;
	}
	public void setCinsiyet(String cinsiyet) {
		this.cinsiyet = cinsiyet;
	}
	public String getDogumTarihi() {
		return dogumTarihi;
	}
	public void setDogumTarihi(String dogumTarihi) {
		dogumTarihi=dogumTarihi.replace('.', '/');
		dogumTarihi=dogumTarihi.replace('-', '/');
		this.dogumTarihi = dogumTarihi;
	}
	public String getMaluliyetVarmi() {
		if(StringUtils.isBlank(maluliyetVarmi))
			return Sabit.HAYIR.toString();
		return maluliyetVarmi;
	}
	public void setMaluliyetVarmi(String maluliyetVarmi) {
		this.maluliyetVarmi = maluliyetVarmi;
	}
	public String getMaluliyetDerecesi() {
		return maluliyetDerecesi;
	}
	public void setMaluliyetDerecesi(String maluliyetDerecesi) {
		this.maluliyetDerecesi = maluliyetDerecesi;
	}
	public String getErkenYaslanmaVarmi() {
		if(StringUtils.isBlank(erkenYaslanmaVarmi))
			return Sabit.HAYIR.toString();
		return erkenYaslanmaVarmi;
	}
	public void setErkenYaslanmaVarmi(String erkenYaslanmaVarmi) {
		this.erkenYaslanmaVarmi = erkenYaslanmaVarmi;
	}
	public boolean getBakMuhCoc() {
		return bakMuhCoc;
	}
	public void setBakMuhCoc(boolean bakMuhCoc) {
		this.bakMuhCoc = bakMuhCoc;
	}
	public String getBakGunSayisi() {
		return bakGunSayisi;
	}
	public String getBakMuhCocString() {
		if(bakMuhCoc==true)
			return "Evet";
		else return "Hay\u0131r";
	}
	public void setBakGunSayisi(String bakGunSayisi) {
		this.bakGunSayisi = bakGunSayisi;
	}
	
	
	
}
