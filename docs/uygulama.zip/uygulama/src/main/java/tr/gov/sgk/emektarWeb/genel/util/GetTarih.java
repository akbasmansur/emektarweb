package tr.gov.sgk.emektarWeb.genel.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import org.apache.commons.httpclient.util.DateParseException;

public class GetTarih {

	public static final int DATE_TIME = 1;
	public static final int GUN_INDEX = 0;
	public static final int AY_INDEX = 1;
	public static final int YIL_INDEX = 2;
	public static final int DATE = 2;

	public static final int TIME = 3;
	public static final String INDEX_ERROR 		= "HATALI PARAMETRE!";
	public static final String arrMonthNames[] 	= { "Ocak", "�ubat", "Mart", "Nisan", "May�s", "Haziran", "Temmuz", "A�ustos", "Eyl�l", "Ekim", "Kas�m", "Aral�k" };
	public static final String arrDayNames[] 	= { "Pazar", "Pazartesi", "Sal�", "�ar�amba", "Per�embe", "Cuma", "Cumartesi" };
	
	public GetTarih() {

	} 
 
	/** 
	 * bugunun tarihini "06/09/2005" formatinda dondurur
	 * 
	 * 
	 * @author Anonim
	 * 
	 * @param
	 * @return
	 * @return
	 */
	public static String getTarihString() {
		Calendar today = Calendar.getInstance(); // get the current date.
		int day = today.get(Calendar.DAY_OF_MONTH);
		int year = today.get(Calendar.YEAR);
		int month = today.get(Calendar.MONTH) + 1;
		String dayString = Integer.toString(day);
		String monthString = Integer.toString(month);
		String yearString = Integer.toString(year);
		if (dayString.length() <= 1) {
			dayString = "0" + dayString;
		}
		if (monthString.length() <= 1) {
			monthString = "0" + monthString;
		}
		return dayString + "/" + monthString + "/" + yearString;
	}

	/**
	 * getTarih() metodu bugunun tarihinin milliSecond degerini dondurur
	 * 
	 * @author Anonim
	 * 
	 * @param
	 * @return
	 * @return
	 */
	public static long getTarih() {
		Calendar today = Calendar.getInstance(); // get the current date.
		return today.getTime().getTime();
	}
	/**
	 * author : oguner2 
	 * Last Updated Date : Oct 8, 2009  return type : Date
	 * bug�n�n tarihini Date tipinde geri d�ner 
	 */
	public static Date getBugununTarihi(){
		return convertStringToDate(getTarihString(),"");
	}

	/**
	 * formatTarih(Date date) metodu date nesnesi alir ve bu date nesnesinin
	 * icerdigi tarih degerini dd/MM/yyyy formatinda dondurur
	 * 
	 * 
	 * @author Anonim
	 * 
	 * @param
	 * @return
	 * @param date
	 * @return
	 */
	public static String formatTarih(Date date) {
		String dateString = "";
		if (date != null) {
			java.text.SimpleDateFormat df2 = new java.text.SimpleDateFormat(
					"dd/MM/yyyy");
			dateString = df2.format(date);
		}
		return dateString;
	}

	/**
	 * formatSaat(Date date) metodu date nesnesi alir ve bu date nesnesinin
	 * icerdigi saat degerini HH:mm (15:30 gibi) formatinda dondurur
	 * 
	 * @author Anonim
	 * @param
	 * @return
	 * @param date
	 * @return
	 */
	public static String formatSaat(Date date) {
		String dateString = "";
		if (date != null) {
			java.text.SimpleDateFormat df2 = new java.text.SimpleDateFormat(
					"HH:mm");
			dateString = df2.format(date);
		}
		return dateString;
	}

	/**
	 * formatTarihSaat(Date date) metodu date nesnesi alir ve bu date nesnesinin
	 * icerdigi tarih ve saat degerini "dd/MM/yyyy HH:mm" ("06/09/2005 15:30"
	 * gibi) formatinda dondurur
	 * 
	 * @author Anonim
	 * 
	 * @param
	 * @return
	 * @param date
	 * @return
	 */
	public static String formatTarihSaat(Date date) {
		String dateString = "";
		if (date != null) {
			java.text.SimpleDateFormat df2 = new java.text.SimpleDateFormat(
					"dd/MM/yyyy HH:mm");
			dateString = df2.format(date);
		}
		return dateString;
	}

	public static String formatTarihMiliSaniye(Date date) {
		String dateString = "";
		if (date != null) {
			java.text.SimpleDateFormat df2 = new java.text.SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss.SSS");
			dateString = df2.format(date);
		}
		return dateString;
	}
	/**
	 * getCurrentTime() metodu simdiki zaman degerini "15:30" formatinda
	 * dondurur
	 * 
	 * @author Anonim
	 * 
	 * @param
	 * @return
	 * @return
	 */
	public static String getCurrentTime() {
		Calendar cal = new GregorianCalendar();
		int hour24 = cal.get(Calendar.HOUR_OF_DAY); // 0..23
		int min = cal.get(Calendar.MINUTE); // 0..59
		StringBuffer time = new StringBuffer();

		if (hour24 < 10)
			time.append("0").append(hour24);
		else
			time.append(hour24);

		time.append(":");

		if (min < 10)
			time.append("0" + min);
		else
			time.append(min);

		return String.valueOf(time);
	}

	/**
	 * convertStringToDate(String date, String time) metodu dd/MM/yyyy
	 * (06/09/2005 gibi) formatinda tarih degeri, HH:mm (15:30 gibi) formatinda
	 * saat degeri alir ve java.util.Date tipinde deger dondurur. "time"
	 * parametresi null ya da bosluk ("") gonderilebilir.
	 * 
	 * @author Anonim
	 * 
	 * @param
	 * @return
	 * @param date
	 * @param time
	 * @return
	 */
	public static Date convertStringToDate(String date, String time) {
		Date d = null;
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
	
		if (date != null && !date.trim().equals("")) {
			
			try {
				if (time == null || time.trim().equals(""))
					d = formatter.parse(date);
				else
					d = formatter.parse(date + " " + time);
				
			} catch (Exception e) {
				//e.printStackTrace();
			}
		}		
	
		return d;
	}
	
	/**
	 * convertStringToDate(String date) metodu yyyyMMdd
	 * (20050905) formatinda tarih degeri ve java.util.Date tipinde deger dondurur. 
	 * @author Anonim
	 * @param
	 * @return
	 * @param date
	 * @param time
	 * @return
	 */
	public static Date convertStringToDate(String date) {
		Date d = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
	
		if (date != null && !date.trim().equals("")) {
			try {
					d = formatter.parse(date);
			} catch (Exception e) {
				//e.printStackTrace();
			}
		}
		
		return d;
	}
	
	public static Date convertStringToDate2(String date) {
		Date d = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
	
		if (date != null && !date.trim().equals("")) {
			try {
					d = formatter.parse(date);
			} catch (Exception e) {
				//e.printStackTrace();
			}
		}
		
		return d;
	}
	
	/**
	 * Date nesnesini yyyy/MM/dd format�nda d�nd�r�r.HQL i�in  
	 * 
	 * 
	 * @author Alper �zdamar
	 *
	 * @param date
	 * @return
	 */
	public static String convertDateToString(Object date) {
		String d = null;
		if (date!=null) {
			try {
					
					DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
					
					d=formatter.format(date);
																
			} catch (Exception e) {
				//e.printStackTrace();
			}
		}

		return d;
	}
	
	/**
	 * Date nesnesini yyyyMMdd format�nda bir integera d�nd�r�r.  
	 */
	public static Integer convertDateToInteger(Object date) {
		String d = null;
		Integer i = null;
		if (date!=null) {
			try {
					
					DateFormat formatter = new SimpleDateFormat("yyyyMMdd");
					
					d=formatter.format(date);
					i= new Integer(Integer.parseInt(d));
																
			} catch (Exception e) {
				//e.printStackTrace();
			}
		}
		return i;
	}
	
	/**
	 * Date nesnesini dd/MM/yyyy format�nda d�nd�r�r.  
	 * 
	 * 
	 * @author Alper �zdamar
	 *
	 * @param date
	 * @return
	 */
	public static String convertDateToStringDayMonthYear(Object date) {
		String d = null;
		if (date!=null) {
			try {
					
					DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
					
					d=formatter.format(date);
																
			} catch (Exception e) {
				//e.printStackTrace();
			}
		}

		return d;
	}

	public static String convertDateToStringTime(Object date) {
		String d = null;
		if (date!=null) {
			try {
					
					DateFormat formatter = new SimpleDateFormat("HH:mm");
					
					d=formatter.format(date);
																
			} catch (Exception e) {
				//e.printStackTrace();
			}
		}

		return d;
	}

	/**
	 * 
	 * convertStringToDateTime(String dateTime) metodu dd/MM/yyyy HH:mm
	 * (06/09/2005 15:30 gibi) formatinda tarih ve saat degeri alir ve
	 * java.util.Date tipinde deger dondurur.
	 * 
	 * @param
	 * @return
	 * @author Y�lmaz Balun
	 * @param dateTime
	 * @return
	 */

	public static Date convertStringToDateTime(String dateTime) {
		Date d = null;
		if (dateTime != null && !dateTime.trim().equals("")) {
			try {
				d = new SimpleDateFormat("dd/MM/yyyy HH:mm").parse(dateTime);
			} catch (Exception e) {
				//e.printStackTrace();
			}
		}

		return d;
	}
	
	/**
	 * 
	 * convertStringToDateTimeMiliSaniye(String dateTime) metodu dd/MM/yyyy HH:mm:ss.SSSSSS
	 * (06/09/2005 15:30:12.123456 gibi) formatinda tarih ve saat degeri alir ve
	 * java.util.Date tipinde deger dondurur.
	 * 
	 * @param
	 * @return
	 * @author Y�lmaz Balun
	 * @param dateTime
	 * @return
	 */

	public static Date convertStringToDateTimeMiliSaniye(String dateTime) {
		Date d = null;
		if (dateTime != null && !dateTime.trim().equals("")) {
			try {
				d = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").parse(dateTime);
			} catch (Exception e) {
				//e.printStackTrace();
			}
		}

		return d;
	}

	/**
	 * convertStringToSQLDate(String date, String time) metodu dd/MM/yyyy
	 * (06/09/2005 gibi) formatinda tarih degeri, HH:mm (15:30 gibi) formatinda
	 * saat degeri alir ve java.sql.Date tipinde deger dondurur. "time"
	 * parametresi null ya da bosluk ("") gonderilebilir.
	 * 
	 * @author Anonim
	 * 
	 * @param
	 * @return
	 * @param date
	 * @param time
	 * @return
	 */
	public static java.sql.Date convertStringToSQLDate(String date, String time) {
		if (date != null && date.length() == 10) {
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.YEAR, Integer.parseInt(date.substring(6)));
			cal.set(Calendar.MONTH, Integer.parseInt(date.substring(3, 5)) - 1);
			cal.set(Calendar.DATE, Integer.parseInt(date.substring(0, 2)));
			if (time != null && time.length() == 5) {
				cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(time.substring(
						0, 2)));
				cal.set(Calendar.MINUTE, Integer.parseInt(time.substring(3)));
			}

			return new java.sql.Date(cal.getTime().getTime());
		} else {
			return null;
		}
	}
	
	/*
	 * YYYYMMDD format�ndaki stringi sqldate'e �evirir
	 * */
	public static java.sql.Date convertStringYYYYMMDDToSQLDate(String date, String time) {
		if (date != null && date.length() == 8) {
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.YEAR, Integer.parseInt(date.substring(0,4)));
			cal.set(Calendar.MONTH, Integer.parseInt(date.substring(4, 6)) - 1);
			cal.set(Calendar.DATE, Integer.parseInt(date.substring(6,8)));
			if (time != null && time.length() == 5) {
				cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(time.substring(
						0, 2)));
				cal.set(Calendar.MINUTE, Integer.parseInt(time.substring(3)));
			}

			return new java.sql.Date(cal.getTime().getTime());
		} else {
			return null;
		}
	}
	
	public static java.sql.Timestamp convertStringToSQLTimeStamp(String date) {
	try {
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		java.util.Date parsedDate = dateFormat.parse(date);
		java.sql.Timestamp timestamp = new java.sql.Timestamp(parsedDate.getTime());
		return timestamp;
	} catch (Exception e) {
		//e.printStackTrace();
	}
		return null;
	}
	
	/**
	 * convertStringToLong(String date, String time) metodu dd/MM/yyyy
	 * (06/09/2005 gibi) formatinda tarih degeri, HH:mm (15:30 gibi) formatinda
	 * saat degeri alir ve bu degerlere karsilik gelen milliSecond degerini
	 * dondurur. "time" parametresi null ya da bosluk ("") gonderilebilir.
	 * 
	 * @author Anonim
	 * 
	 * @param
	 * @return
	 * @param date
	 * @param time
	 * @return
	 */
	public static long convertStringToLong(String date, String time) {
		if (date != null && !date.equals("") && date.length() == 10) {
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.YEAR, Integer.parseInt(date.substring(6)));
			cal.set(Calendar.MONTH, Integer.parseInt(date.substring(3, 5)) - 1);
			cal.set(Calendar.DATE, Integer.parseInt(date.substring(0, 2)));
			if (time != null && !time.equals("") && time.length() == 5) {
				cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(time.substring(
						0, 2)));
				cal.set(Calendar.MINUTE, Integer.parseInt(time.substring(3)));
				cal.set(Calendar.SECOND, 0);
				cal.set(Calendar.MILLISECOND, 0);
			} else {
				cal.set(Calendar.HOUR_OF_DAY, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				cal.set(Calendar.MILLISECOND, 0);
			}
			return cal.getTime().getTime();
		} else {
			return 0;
		}
	}

	/**
	 * convertLongToDateTime(long milliSeconds, int type) metodu milliSecond
	 * degere karsilik gelen tarihi "type" parametresine gore dondurur. type
	 * parametresi : GetTarih.DATE_TIME ise donen deger "06/09/2005 15:30"
	 * formatinda GetTarih.DATE ise donen deger "06/09/2005" formatinda
	 * GetTarih.TIME ise donen deger "15:30" formatindadir.
	 * 
	 * @author Anonim
	 * 
	 * @param
	 * @return
	 * @param milliSeconds
	 * @param type
	 * @return
	 */
	public static String convertLongToDateTime(long milliSeconds, int type) {
		if (milliSeconds > 0) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date(milliSeconds));
			String day = cal.get(Calendar.DATE) < 10 ? ("0" + String
					.valueOf(cal.get(Calendar.DATE))) : String.valueOf(cal
					.get(Calendar.DATE));
			String month = (cal.get(Calendar.MONTH) + 1) < 10 ? ("0" + String
					.valueOf((cal.get(Calendar.MONTH) + 1))) : String
					.valueOf((cal.get(Calendar.MONTH) + 1));
			String year = String.valueOf(cal.get(Calendar.YEAR));

			String date = day + "/" + month + "/" + year;
			String time = (cal.get(Calendar.HOUR_OF_DAY) < 10 ? ("0" + String
					.valueOf(cal.get(Calendar.HOUR_OF_DAY))) : String
					.valueOf(cal.get(Calendar.HOUR_OF_DAY)))
					+ ":"
					+ (cal.get(Calendar.MINUTE) < 10 ? ("0" + String
							.valueOf(cal.get(Calendar.MINUTE))) : String
							.valueOf(cal.get(Calendar.MINUTE)));

			if (type == GetTarih.DATE_TIME) {
				return date + " " + time;
			} else if (type == GetTarih.DATE) {
				return date;
			} else {
				return time;
			}
		} else {
			return "";
		}
	}
	
	/**
	 *  convertLongToStringDate(Long date) metodu veritaban�nda yyyyaadd
	 *  seklinde tutulan tarihi yyyy/aa/gg haline cevirir. (Formlarda kullanabilmek icin)
	 *  
	 * @author gokcem
	 * 
	 */
	public static String convertLongToStringDate(Integer date) {
		if((date==null ) || date.compareTo(Sabit.DEFAULT_INT)==0)
		return "";
		return date/10000+"/"+ ((date/100)-(date/10000)*100)+"/"+(date%100);
		
	}
	
	/**
	 *  convertLongToutilDate(Long date) metodu veritaban�nda yyyyaadd
	 *  seklinde tutulan tarihi java.util.Date haline cevirir. 
	 *  
	 * @author gokcem
	 * 
	 */
	public static Date convertLongToUtilDate(Integer date) {
		GregorianCalendar cal = new GregorianCalendar();
		cal.set(GregorianCalendar.HOUR_OF_DAY, 0);
		cal.set(GregorianCalendar.MINUTE, 0);
		cal.set(GregorianCalendar.SECOND, 0);
		if((date==null ) || date.compareTo(Sabit.DEFAULT_INT)==0)
		{
			//defalt tarih 01/01/1000
			cal.set(GregorianCalendar.YEAR, 1000);
			cal.set(GregorianCalendar.MONTH,0); // aylar 0 dan basliyor
			cal.set(GregorianCalendar.DATE,1);
			return cal.getTime();
		}
		else
		{

			//defalt tarih 01/01/1000
			cal.set(GregorianCalendar.YEAR,date/10000);
			cal.set(GregorianCalendar.MONTH,((date/100)-(date/10000)*100)-1 ); // aylar 0 dan basliyor
			cal.set(GregorianCalendar.DATE,(date%100));
			return cal.getTime();
		}
	}
	
	public static boolean ayniGunMu(Calendar cal1, Calendar cal2) {
		if ((cal1!=null) && (cal2!=null)) {
			int year1 = cal1.get(Calendar.YEAR);
			int year2 = cal2.get(Calendar.YEAR);
			if (year1 == year2) {
				int month1 = cal1.get(Calendar.MONTH)+1;
				int month2 = cal2.get(Calendar.MONTH)+1;
				if (month1 == month2) {
					int day1 = cal1.get(Calendar.DAY_OF_MONTH);
					int day2 = cal2.get(Calendar.DAY_OF_MONTH);
					if (day1== day2)
						return true; 
				} 
			}
		}
		return false;
	}
	
	public static boolean tarihAraliklariKesisiyormu (String bas1, String bit1, String bas2, String bit2) {
		
		Date r1start = convertStringToDate(bas1, "");
		Date r1end = convertStringToDate(bit1, "");
		Date r2start = convertStringToDate(bas2, "");
		Date r2end = convertStringToDate(bit2, "");
		
		Date sstart = r1start.after(r2start) ? r1start : r2start; // ba�lang��lar�n b�y���
		Date send = r1end.before(r2end) ? r1end : r2end; // biti�lerin k�����
		return sstart.before(send); // Bu iki de�er ayn� veya yeni bir tarih aral��� olu�turuyorsa kesi�iyorlar demektir.
		}
	
	public static java.util.Date birOncekiGun(java.util.Date gun){
		return (new java.util.Date(gun.getTime()- 1));
	}
	
	/** Get Current Date in format of '01 Ocak 2005' */
	public static String getCurrentDay_ddMMyyyy() {
		return getCurrentDay() + " " + getMonthNameTR(getCurrentMonth()) + " " + getCurrentYear();
	}
	
	/** Get Current Date in format of '01 Ocak 2005, Pazartesi' */
	public static String getCurrentDay_ddMMyyyyDDDD() {
		return getCurrentDay() + " " + getMonthNameTR(getCurrentMonth()) + " " + getCurrentYear() + ", " + getCurrentDayNameTR();
	}
	
	/** Get Current date in format of YYYYMMDD 20090901*/
	public static String getCurrentDay_YYYYMMDD() {
		return getCurrentYear() + getCurrentMonthTwoDigits() + getCurrentDay() ;
	}
	/** Get Current date in format of YYYYMMDD 20090901*/
	public static String getCurrentDay_DDMMYYYYwithSlash() {
		return getCurrentDay() + "/" + getCurrentMonthTwoDigits() + "/" +getCurrentYear()  ;
	}
		private static String getCurrentDay() {
		int iDay = Calendar.getInstance(new Locale("tr", "TR")).get(Calendar.DATE);
		return makeNDigit(iDay, 2);
	}
	
	public static String getCurrentMonthTwoDigits() {
		int iMonth 	= Calendar.getInstance(Sabit.LOCALE_TR).get(Calendar.MONTH) + 1;
		return makeNDigit(iMonth, 2);
	}
	
	private static String getMonthNameTR(String sMonth) {
		return getMonthNameTR(Integer.parseInt(sMonth));
	}
	
	private static String getMonthNameTR(int iMonth) {
		if (iMonth < 1 || iMonth > 12) 
			return INDEX_ERROR;
		return arrMonthNames[iMonth - 1];
	}
	
	private static String getCurrentDayNameTR() {
		int iDayOfWeek = Calendar.getInstance(Sabit.LOCALE_TR).get(Calendar.DAY_OF_WEEK);
		if (iDayOfWeek < 1 || iDayOfWeek > 7) 
			return INDEX_ERROR;
		return arrDayNames[iDayOfWeek - 1];
	}
	
	public static String getCurrentYear() {
		return String.valueOf(Calendar.getInstance(Sabit.LOCALE_TR).get(Calendar.YEAR));
	}
	public static int getCurrentYearInt() {
		return Calendar.getInstance(Sabit.LOCALE_TR).get(Calendar.YEAR);
	}
	public static String getCurrentMonth() {
		return String.valueOf(Calendar.getInstance(Sabit.LOCALE_TR).get(Calendar.MONTH)+1);
	}

	public static String getCurrentDayOfMonth() {
		return String.valueOf(Calendar.getInstance(new Locale("tr", "TR")).get(Calendar.DAY_OF_MONTH));
	}

	public static String makeNDigit(int iNumber, int iDigit) {
		if (iNumber > 0 || iDigit > 1) {
			StringBuffer sb = new StringBuffer();
			if (String.valueOf(iNumber).length() > 0 && String.valueOf(iNumber).length() < iDigit)
				//while(sb.length() < String.valueOf(iNumber).length())
				while(sb.length() < iDigit-String.valueOf(iNumber).length())
					sb.append("0");
				sb.append(iNumber);
			return sb.toString();
		}
		return null;
	}

	public static int getDateDifferenceInYears(String date1, String date2) {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date pDate1 = new Date();
		Date pDate2 = new Date();
		try {
			pDate1 = df.parse(date1);
			pDate2 = df.parse(date2);
		} catch (ParseException e) {
			//e.printStackTrace();
		}

		Calendar cal1 = Calendar.getInstance();
		Calendar cal2 = Calendar.getInstance();

		// Different date might have different offset
		cal1.setTime(pDate1);
		long ldate1 = pDate1.getTime() + cal1.get(Calendar.ZONE_OFFSET) + cal1.get(Calendar.DST_OFFSET);

		cal2.setTime(pDate2);
		long ldate2 = pDate2.getTime() + cal2.get(Calendar.ZONE_OFFSET) + cal2.get(Calendar.DST_OFFSET);

		// Using integer calculation, truncate the decimals
		int hr1 = (int) (ldate1 / 3600000); //60*60*1000
		int hr2 = (int) (ldate2 / 3600000);

		int days1 = (int) hr1 / 24;
		int days2 = (int) hr2 / 24;

		int dateDiff = days2 - days1;
		int weekOffset = (cal2.get(Calendar.DAY_OF_WEEK) - cal1.get(Calendar.DAY_OF_WEEK)) < 0 ? 1 : 0;
		int weekDiff = dateDiff / 7 + weekOffset;
		int yearDiff = cal2.get(Calendar.YEAR) - cal1.get(Calendar.YEAR);
		int monthDiff = yearDiff * 12 + cal2.get(Calendar.MONTH) - cal1.get(Calendar.MONTH);

		return yearDiff;
	}
	
	public static int getDateDifferenceInDate(String date1, String date2) {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date pDate1 = new Date();
		Date pDate2 = new Date();
		try {
			pDate1 = df.parse(date1);
			pDate2 = df.parse(date2);
		} catch (ParseException e) {
			//e.printStackTrace();
		}

		Calendar cal1 = Calendar.getInstance();
		Calendar cal2 = Calendar.getInstance();

		// Different date might have different offset
		cal1.setTime(pDate1);
		long ldate1 = pDate1.getTime() + cal1.get(Calendar.ZONE_OFFSET) + cal1.get(Calendar.DST_OFFSET);

		cal2.setTime(pDate2);
		long ldate2 = pDate2.getTime() + cal2.get(Calendar.ZONE_OFFSET) + cal2.get(Calendar.DST_OFFSET);

		// Using integer calculation, truncate the decimals
		int hr1 = (int) (ldate1 / 3600000); //60*60*1000
		int hr2 = (int) (ldate2 / 3600000);

		int days1 = (int) hr1 / 24;
		int days2 = (int) hr2 / 24;

		int dateDiff = days2 - days1;
		int weekOffset = (cal2.get(Calendar.DAY_OF_WEEK) - cal1.get(Calendar.DAY_OF_WEEK)) < 0 ? 1 : 0;
		int weekDiff = dateDiff / 7 + weekOffset;
		int yearDiff = cal2.get(Calendar.YEAR) - cal1.get(Calendar.YEAR);
		int monthDiff = yearDiff * 12 + cal2.get(Calendar.MONTH) - cal1.get(Calendar.MONTH);

		return dateDiff;
	}
	
	public static int getDateDifferenceForBagkur(String date1, String date2){
		Integer[] sure = getDateDifferenceInYilAyGun(date2, date1);
		
		return sure[2]+ sure[1]*30 + sure[0]*360;
	}
	
	public static int getDateDifferenceInMonth(String date1, String date2) {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		Date pDate1 = new Date();
		Date pDate2 = new Date();
		try {
			pDate1 = df.parse(date1);
			pDate2 = df.parse(date2);
		} catch (ParseException e) {
			//e.printStackTrace();
		}

		Calendar cal1 = Calendar.getInstance();
		Calendar cal2 = Calendar.getInstance();

		// Different date might have different offset
		cal1.setTime(pDate1);
		long ldate1 = pDate1.getTime() + cal1.get(Calendar.ZONE_OFFSET) + cal1.get(Calendar.DST_OFFSET);

		cal2.setTime(pDate2);
		long ldate2 = pDate2.getTime() + cal2.get(Calendar.ZONE_OFFSET) + cal2.get(Calendar.DST_OFFSET);

		// Using integer calculation, truncate the decimals
		int hr1 = (int) (ldate1 / 3600000); //60*60*1000
		int hr2 = (int) (ldate2 / 3600000);

		int days1 = (int) hr1 / 24;
		int days2 = (int) hr2 / 24;

		int dateDiff = days2 - days1;
		int weekOffset = (cal2.get(Calendar.DAY_OF_WEEK) - cal1.get(Calendar.DAY_OF_WEEK)) < 0 ? 1 : 0;
		int weekDiff = dateDiff / 7 + weekOffset;
		int yearDiff = cal2.get(Calendar.YEAR) - cal1.get(Calendar.YEAR);
		int monthDiff = yearDiff * 12 + cal2.get(Calendar.MONTH) - cal1.get(Calendar.MONTH);

		return monthDiff;
	}
	
	/**
	 * author : ggokce 
	 * Last Updated Date : Sep 28, 2009
	 *@param sure
	 *@param dt
	 *@return  return type : Date
	 * 	verilen tarihin uzerine yil ay gun icin gecen sureyi ekler ve yeni tarihi doner.
	 *  bir yil 360 gun 
	 *  bir ay 30 gundur
	 */
	public static Date tarihinUstuneYilAyGunEkle(Integer[] sure,Date dt)
	{
		Calendar cal = new GregorianCalendar();
		cal.setTime(dt);
		Integer yil = cal.get(GregorianCalendar.YEAR);
		Integer ay =  cal.get(GregorianCalendar.MONTH)+1;
		Integer gun = cal.get(GregorianCalendar.DATE);
		
		gun += sure[2];
		ay  += gun/30 + sure[1];
		gun = gun - (gun/30)*30;
		yil += ay/12+sure[0];
		ay = ay - (ay/12)*12;
		
		ay -=1;//calendara uymasi icin azaltildei
		cal.set(yil,ay,gun);
		return cal.getTime(); 
	}
	/**
	 * author: oguner2 
	 * Date Created: Dec 3, 2009
	 *@param sure
	 *@param dt
	 *@return  return type: Date
	 * ay ay geri d�nmek i�in yap�ld�
	 */
	public static Date tarihtenAyCikar(Integer sure,Date dt)
	{
		Calendar cal = new GregorianCalendar();
		cal.setTime(dt);
		Integer yil = cal.get(GregorianCalendar.YEAR);
		Integer ay =  cal.get(GregorianCalendar.MONTH)+1;
		Integer gun = cal.get(GregorianCalendar.DATE);
		
		if(ay==1){
			ay=12;
			yil -=1;
		}
		ay  -= sure;
		cal.set(yil,ay,gun);
		return cal.getTime(); 
	}
	
	public static Date tarihinUstuneYilEkle(Integer yil1,Date dt)
	{
		Calendar cal = new GregorianCalendar();
		cal.setTime(dt);
		Integer yil = cal.get(GregorianCalendar.YEAR);
		Integer ay =  cal.get(GregorianCalendar.MONTH);
		Integer gun = cal.get(GregorianCalendar.DATE);
		
		yil += yil1;
		cal.set(yil,ay,gun);
		return cal.getTime(); 
	}

	

	
	/**
	 * author : ggokce 
	 * Last Updated Date : Sep 28, 2009
	 *@param sure
	 *@param dt
	 *@return  return type : Date
	 * 	verilen tarihten belirtilen gun kadar sureyi cikartir yeni tarihi doner.
	 *  bir yil 360 gun 
	 *  bir ay 30 gundur
	 */
	public static Date tarihinUstuneYilAyGunCikart(Integer[] sure,Date dt)
	{
		Calendar cal = new GregorianCalendar();
		cal.setTime(dt);
		Integer yil = cal.get(GregorianCalendar.YEAR);
		Integer ay =  cal.get(GregorianCalendar.MONTH)+1;
		Integer gun = cal.get(GregorianCalendar.DATE);
		
		if(gun<=sure[2])
		{
			ay -=1;
			gun +=30;
		}
		gun = gun -sure[2];
		
		if(ay<=sure[1])
		{
			yil-=1;
			ay+=12;
		}
		
		ay -=sure[1];
		yil-=sure[0];

		ay -=1;//calendara uymasi icin azaltildei
		cal.set(yil,ay,gun);
		return cal.getTime(); 
	}
	
	/**
	 * author : oguner2 
	 * Last Updated Date : Sep 28, 2009
	 *@param date1
	 *@param date2
	 *@return  return type : Integer[]
	 * 2 string tarih aras�ndaki farki, y�l ay g�n olarak listeye koyarak d�ner
	 *  date1 - date2
	 *  tarihlerin dormati "31/12/1999" seklinde olmalidir
	 */
	public static Integer[] getDateDifferenceInYilAyGun(String date1, String date2){
		
		Integer[] list = new Integer[3];
		Integer yil1;
		Integer yil2;
		
		Integer ay1; 
		Integer ay2;
		
		Integer gun1;
		Integer gun2;
		
		yil1 =Integer.valueOf(getYil(date1));
		yil2 = Integer.valueOf(getYil(date2));
		ay1 = Integer.valueOf(getAy(date1));
		ay2 = Integer.valueOf(getAy(date2));
		gun1 = Integer.valueOf(getGun(date1));
		gun2 = Integer.valueOf(getGun(date2));
		
		if(gun1>30) gun1=30;
		if(gun2>30) gun2=30;
		
		if (gun1<gun2){
			ay1 -=1;
			gun1 +=30;
			if(ay1 ==0){
				ay1 = 12;
				yil1--;
			}
				
		}
		if(ay1<ay2){
			yil1-=1;
			ay1+=12;
		}
		list[2]= gun1-gun2;
		list[1]= ay1-ay2;
		list[0]= yil1-yil2;
		return list;
	}
	
	public static Integer[] getDateDifferenceInYilAyGun(Date date1, Date date2)
	{
		return getDateDifferenceInYilAyGun(GetTarih.convertDateToStringDayMonthYear(date1), GetTarih.convertDateToStringDayMonthYear(date2));
	}
	
	/**
	 * author : oguner2 
	 * Last Updated Date : Sep 28, 2009
	 *@param date1
	 *@param date2
	 *@return  return type : Integer[]
	 * 2 string tarih aras�ndaki fark� yil olarak (ay k�s�rat�n� da ekleyerek d�ner)
	 */
	public static Double getDateDifferenceInYil(String date1, String date2){
		Double yilFarki = 0.0;
		Integer[] list = {};
		list = getDateDifferenceInYilAyGun(date1, date2);
		if(list.length ==2){
			yilFarki = list[0].doubleValue() + list[1]/12;
		}
			
		return yilFarki;
	}
	/**
	 * author: oguner2 
	 * Date Created: Dec 2, 2009
	 *@param date1
	 *@param date2
	 *@return  return type: Double
	 *
	 */
	public static Integer getDateDifferenceInAy(String date1, String date2){
		Integer yilFarki = 0;
		Integer[] list = {};
		list = getDateDifferenceInYilAyGun(date1, date2);
		if(list.length ==3){
			yilFarki = list[0].intValue()*12 + list[1].intValue();
		}
			
		return yilFarki;
	}
	
	/**
	 * @param trFirst dd.mm.yyyy format�ndaki ilk tarih
	 * @param trSecond dd.mm.yyyy format�ndaki ikinci tarih
	 * @return ilk parametredeki tarih ikinci parametredeki tarihten sonra ise true d�ner, aksi halde false
	 * @throws NotADateException, e�er iki parametreden biri bir tarih belirtmiyorsa
	 */
	public static boolean isAfter(String trFirst, String trSecond) throws DateParseException{
		//Calendar firstCal, secondCal;

		int[] first = null;
		int[] second = null;
		try {
			first = parseDate_ddmmyyyy(trFirst);
			second = parseDate_ddmmyyyy(trSecond);
		} catch (DateParseException e) {
			throw new DateParseException();
		}
		if ( ! (isDate(first[GUN_INDEX], first[AY_INDEX], first[YIL_INDEX]) && isDate(second[GUN_INDEX], second[AY_INDEX], second[YIL_INDEX])))
			throw new DateParseException();

		if (first[YIL_INDEX] > second[YIL_INDEX])
			return true;
		else
			if (first[YIL_INDEX] < second[YIL_INDEX])
				return false;
		// demek ki y�llar e�it
		else
			if (first[AY_INDEX] > second[AY_INDEX])
				return true;
			else
				if (first[AY_INDEX] < second[AY_INDEX])
					return false;
		// demek ki aylar da e�it
		else
			if (first[GUN_INDEX] > second[GUN_INDEX])
				return true;
			else
				return false;
	}
	
	/**
	 * author: oguner2 
	 * Date Created: Dec 17, 2009
	 *@param trFirst
	 *@param trSecond
	 *@return
	 *@throws DateParseException  return type: boolean
	 * tarih ayn� ya da daha b�y�k tarih mi kontrol�n� yapar
	 */
	public static boolean isAfterOrEqualTo(String trFirst, String trSecond) throws DateParseException{
		//Calendar firstCal, secondCal;

		int[] first = null;
		int[] second = null;
		try {
			first = parseDate_ddmmyyyy(trFirst);
			second = parseDate_ddmmyyyy(trSecond);
		} catch (DateParseException e) {
			throw new DateParseException();
		}
		if ( ! (isDate(first[GUN_INDEX], first[AY_INDEX], first[YIL_INDEX]) && isDate(second[GUN_INDEX], second[AY_INDEX], second[YIL_INDEX])))
			throw new DateParseException();

		if (first[YIL_INDEX] > second[YIL_INDEX])
			return true;
		else
			if (first[YIL_INDEX] < second[YIL_INDEX])
				return false;
		// demek ki y�llar e�it
		else
			if (first[AY_INDEX] > second[AY_INDEX])
				return true;
			else
				if (first[AY_INDEX] < second[AY_INDEX])
					return false;
		// demek ki aylar da e�it
		else
			if (first[GUN_INDEX] >= second[GUN_INDEX])
				return true;
			else
				return false;
	}
	/**
	 * author: oguner2 
	 * Date Created: Dec 17, 2009
	 *@param trFirst
	 *@param trSecond
	 *@return
	 *@throws DateParseException  return type: boolean
	 * tarih ayn� ya da daha b�y�k tarih mi kontrol�n� yapar
	 */
	public static boolean isEqualTo(String trFirst, String trSecond) throws DateParseException{
		//Calendar firstCal, secondCal;

		int[] first = null;
		int[] second = null;
		try {
			first = parseDate_ddmmyyyy(trFirst);
			second = parseDate_ddmmyyyy(trSecond);
		} catch (DateParseException e) {
			throw new DateParseException();
		}
		if ( ! (isDate(first[GUN_INDEX], first[AY_INDEX], first[YIL_INDEX]) && isDate(second[GUN_INDEX], second[AY_INDEX], second[YIL_INDEX])))
			throw new DateParseException();

		if (first[YIL_INDEX] == second[YIL_INDEX] && first[AY_INDEX] == second[AY_INDEX] && first[GUN_INDEX] == second[GUN_INDEX])
			return true;
		else
				return false;
		
	}
	
	public static boolean isDate(int day, int month, int year) {
		month--;
		if ((month < 0) || (month > 11))
			return false;
		int[] months = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
		if (month == 1) {
			int febMax = 28;
			if (((year % 4) == 0) && ((year % 100) != 0) || ((year % 400) == 0))
				febMax = 29;

			if ((day < 0) || (day > febMax))
				return false;
		} else
			if ((day < 0) || (day > months[month]))
				return false;

		return true;
	}

	
	
	/* sBerk */
	// İki taris aras�nda m� kontrolu
	// controlDate beginDate ve endDate aras�nda  yer al�yorsa true, aksi halde false doner;
	
	public static boolean isTarihAraligindaMi(Date controlDate, Date begin ,Date end){
		
		return controlDate.after(begin) &&  controlDate.before(end);
	}
	

	
	/**
	 * İki tarih aras� g�n say�s�n� hesaplar, ayn� g�n i�in 1 d�ner 
	 */
	public final static int gunSayisiHesapla(java.util.Date ilkTarih, java.util.Date sonTarih) {
		long fark = sonTarih.getTime() - ilkTarih.getTime();
		return ((int) (1 + (fark / (3600 * 24 * 1000))));
	}
	/**
	 * 	author: oguner2 
	 * Date Created: Dec 14, 2009
	 *@param trDate
	 *@return
	 *@throws DateParseException  return type: int[]
	 * ayara� / ya da . olabilecek ve ay ve g�n = 01 ya da 1 olabiliecek �ekilde de�zltildi
	 *
	 */
		public static int[] parseDate_ddmmyyyy(String trDate) throws DateParseException {
			int[] arr = new int[3];
			int index = 0;
			Character seperator = ' ';
			try {
				if(trDate.contains("/"))
					seperator = '/';
				else if(trDate.contains("."))
					seperator = '.';
				else throw new DateParseException();
				
				index = trDate.indexOf(seperator);
				
				arr[GUN_INDEX] = Integer.parseInt(trDate.substring(0, index));
				arr[AY_INDEX] = Integer.parseInt(trDate.substring(index+1, trDate.lastIndexOf(seperator)));
				arr[YIL_INDEX] = Integer.parseInt(trDate.substring(trDate.lastIndexOf(seperator)+1));
			} catch (NumberFormatException nfe) {
				throw new DateParseException();
			} catch (StringIndexOutOfBoundsException sioobe) {
				throw new DateParseException();
			} catch (NullPointerException npe) {
				throw new DateParseException();
			}
			return arr;
		}

		// Tarih icinden gun'u cekmek 
		public static String getGun(String date) {
			if (date == null || date.equalsIgnoreCase(""))
				return null;
			int index = date.indexOf('/');

			return date.substring(0, index);
		}

		// Tarih icinden ay'� cekmek 
		public static String getAy(String date) {
			if (date == null || date.equalsIgnoreCase(""))
				return null;
			
			return date.substring(date.indexOf('/')+1, date.lastIndexOf('/'));
		}

		// Tarih icinden y�l'� cekmek 
		public static String getYil(String date) {
			if (date == null || date.equalsIgnoreCase(""))
				return null;
			int index = date.lastIndexOf('/');
			return date.substring(index+1);
		}
		
		/**
		 * ddmmyyy �eklinde bir tarih verildi�inde 
		 * yyyymm �eklinde bir string d�ner
		 *
		 * 09.�ub.2010
		 * eelgun
		 */
		public static String getDonem(String date){
			return getYil(date) + getAy(date);
		}
		
		public static String getCurrentDonem(){
			
			SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy");
			
			String today = sdf.format(new Date());
			
			return getYil(today) + getAy(today);
		}
	


}
