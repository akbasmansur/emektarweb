<%@page language="java" contentType="text/html; charset=ISO-8859-9"
	pageEncoding="ISO-8859-9"%>
<%@taglib prefix="bean" uri="/WEB-INF/config/tld/struts-bean.tld"%>
<%@taglib prefix="display" uri="/WEB-INF/config/tld/displaytag.tld"%>
<%@taglib prefix="tiles" uri="/WEB-INF/config/tld/struts-tiles.tld"%>
<%@taglib prefix="html" uri="/WEB-INF/config/tld/struts-html.tld"%>
<%@taglib prefix="logic" uri="/WEB-INF/config/tld/struts-logic.tld"%>
<%@taglib prefix="nested" uri="/WEB-INF/config/tld/struts-nested.tld"%>
<%@taglib prefix="emektar" uri="/WEB-INF/config/tld/emektar.tld"%>

<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td height="25" width="240"><html:img page="/img/topFrame/headLogoPart1.gif"/><html:img page="/img/topFrame/spacer.gif" width="5" height="5"/></td>
  	</tr>
	<tr> 
		<td height="56" width="240" background="<html:rewrite page="/img/topFrame/headBack.gif"/>"><html:img page="/img/topFrame/headLogoPart2.gif"/></td>
		<td height="56" background="<html:rewrite page="/img/topFrame/headBack.gif"/>" align="center">
		<!--<html:img page="/images/headTitle.gif"/>-->
		</td>
		<td height="56" width="240" align="right" background="<html:rewrite page="/img/topFrame/headBack.gif"/>"><html:img page="/img/topFrame/headAtaPart1.gif"/></td>
	</tr>
	<tr class="toolbarText"> 
		<td height="27" style="padding-left:5;" colspan="2" background="<html:rewrite page="/img/topFrame/headToolbarBack.gif"/>"></td>
		<td height="27" width="240" align="right" background="<html:rewrite page="/img/topFrame/headToolbarBack.gif"/>"><html:img page="/img/topFrame/headAtaPart2.gif"/></td>
	</tr>
</table>