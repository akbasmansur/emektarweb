<%@page language="java" contentType="text/html; charset=ISO-8859-9"
	pageEncoding="ISO-8859-9"%>
<%@taglib prefix="bean" uri="/WEB-INF/config/tld/struts-bean.tld"%>
<%@taglib prefix="display" uri="/WEB-INF/config/tld/displaytag.tld"%>
<%@taglib prefix="tiles" uri="/WEB-INF/config/tld/struts-tiles.tld"%>
<%@taglib prefix="html" uri="/WEB-INF/config/tld/struts-html.tld"%>
<%@taglib prefix="logic" uri="/WEB-INF/config/tld/struts-logic.tld"%>
<%@taglib prefix="nested" uri="/WEB-INF/config/tld/struts-nested.tld"%>
<%@taglib prefix="emektar" uri="/WEB-INF/config/tld/emektar.tld"%>
<logic:messagesPresent>
<div style="position: absolute: z-index: 1; width: 790px; overflow: auto;">
  <table style="border: 1px solid #DE2121;" width="100%" bgcolor="#FFEBE3" cellspacing="5" cellpadding="0">
    <tr style="color: #DE2121; padding-top: 10px; padding-bottom: 10px;">
      <td width="50" align="center" valign="top"><html:img page="/img/iconWarning.gif"/></td>
      <td class="message">
	    <html:messages id="error">
	      <li style="padding-top:2px; padding-bottom:2px;"><bean:write name="error" filter="false"/></li>
	    </html:messages>
	  </td>
    </tr>
  </table>
  <table cellpadding="0" cellspacing="0">
    <tr style="font-size:6px;"><td>&nbsp;</td></tr>
  </table>
  </div>
</logic:messagesPresent>

<logic:messagesPresent message="true">

  <table style="border: 1px solid #2C9C3B;" width="790px" bgcolor="#EFF6EA" cellspacing="5" cellpadding="0">
    <tr style="color: #2C9C3B; padding-top: 10px; padding-bottom: 10px;">
      <td width="50" align="center"><html:img page="/img/iconOk.gif"/></td>
	  <td class="message">
	    <html:messages id="message" message="true">
	      <li style="padding-top:2px; padding-bottom:2px;" ><bean:write name="message" filter="false" /></li>
	    </html:messages>
	  </td>
    </tr>
  </table>
  <table cellpadding="0" cellspacing="0">
    <tr style="font-size:6px;"><td>&nbsp;</td></tr>
  </table>

</logic:messagesPresent>