 function tutarDenetimi(alan) { 
	 var charCode = (event.which) ? event.which : event.keyCode;
		if(alan.length ==0 ){
		     if ( (charCode > 47 && charCode < 58)|| charCode==45 ) return true; 
		     else return false; 
		} else if(alan.substring(0,alan.length)=='-')	 {
		     if(charCode > 47 && charCode < 58)return true; 
		     else return false; 
		} else if( alan.indexOf(',')!= -1 ) {	
		     if(  (alan.toString().length)-(alan.indexOf(',')) <= 2){
		     			if(charCode > 47 && charCode < 58) return true; 
		    			else return false; 
		     }else{ return false; }
		} else {
		     if((charCode > 47 && charCode < 58)|| charCode==44) return true;
		     else return false;
		}
}	
 
 function tutarFormatla(num) {
	 
	 num = num.toString().replace(/\./g,'');
	 num = num.toString().replace(/\,/g,'.');
	 if(isNaN(num))
	 num = "0";
	 sign = (num == (num = Math.abs(num)));
	 num = Math.floor(num*100+0.50000000001);
	 kurus = num%100;
	 num = Math.floor(num/100).toString();
	 if(kurus<10)
	 kurus = "0" + kurus;
	 for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++){
	 num = num.substring(0,num.length-(4*i+3))+'.'+
	 num.substring(num.length-(4*i+3));
	 }
	 return (((sign)?'':'-') + num + ',' + kurus  );
	 }

 function integerDenetimi(alan) { 
	 var charCode = (event.which) ? event.which : event.keyCode;
	 	
//	 	alert(alan);
//	 	alert(charCode);
//	 	alert(alan.indexOf('-'));
	 	if(alan.indexOf('-')!= -1)//eksi varsa
	 	{	
	 		if(charCode > 47 && charCode < 58) return true;
	 		else return false;
	 		
	 	}
	 	else //eksi yoksa
	 		if((charCode > 47 && charCode < 58)|| charCode==45) return true;
	 		else return false;
	 		
	 	
		
}	


 
 function integerFormatla(num) {

	 if( num.indexOf('-')!= -1)
	 {
		 bas = num.substring(0,num.indexOf('-')); 
		 bit = num.substring(num.indexOf('-')+1,num.length);
		
		 num = '-'+bas+bit;
	 }
	 
	 return num;
 }
 
 function gercekDegereCevir(hedefAlan){
	 var deger=document.getElementById(hedefAlan).value;
	 deger=deger.toString().replace(/\./g,'');
	 deger=deger.toString().replace(/\,/g,'.');
	 return deger;
	 }
