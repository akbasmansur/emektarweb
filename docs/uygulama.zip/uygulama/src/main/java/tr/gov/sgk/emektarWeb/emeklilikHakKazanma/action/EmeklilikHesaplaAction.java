package tr.gov.sgk.emektarWeb.emeklilikHakKazanma.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm.EmeklilikBilgileriForm;
import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm.HakKazanmaSonucForm;
import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm.HizmetBilgileriForm;
import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.business.EmeklilikSartlari;
import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.business.HakKazanmaService;
import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.business.HizmetBilgileriService;
import tr.gov.sgk.emektarWeb.genel.util.GetTarih;
import tr.gov.sgk.emektarWeb.genel.util.Sabit;

public class EmeklilikHesaplaAction extends Action {

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
			    
		ArrayList<HizmetBilgileriForm> hizmetListesi = (ArrayList<HizmetBilgileriForm>)request.getSession().getAttribute(Sabit.SESSION_HIZMETLISTESI);
		EmeklilikBilgileriForm emeklilikBilgileriForm = (EmeklilikBilgileriForm)request.getSession().getAttribute(Sabit.SESSION_EMEKLILIKBILGILERI);
		HizmetBilgileriService hizmetService = new HizmetBilgileriService();
		ActionMessages messages = new ActionMessages();
		
		if(!((EmeklilikBilgileriForm)request.getSession().getAttribute(Sabit.SESSION_EMEKLILIKBILGILERI)).getSadece3201()){
			if(!hizmetService.bagkurHizmetiVarmi(hizmetListesi)){
				messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("error.hata","Ba\u011fkur hizmetinizi giriniz"));
				saveErrors(request, messages);
				return mapping.getInputForward();
			}

			if(!hizmetService.getSon7YilKurum(hizmetListesi, emeklilikBilgileriForm.getDogumTarihi(), emeklilikBilgileriForm.getSadece3201()).equals(Sabit.HIZMETTURU_BAGKUR)){
				if(hizmetService.getSBaslangicTarihi(hizmetListesi, emeklilikBilgileriForm.getDogumTarihi(), emeklilikBilgileriForm.getSadece3201()).after(GetTarih.convertStringToDate(Sabit.TARIH_30_04_2008,""))){
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("error.hata","Toplam hizmet s\u00fcresine g\u00f6re en fazla \u00e7al\u0131\u015f\u0131lan Kurum Ba\u011fkur olmad\u0131\u011f\u0131ndan 5510 SK. 4/b maddesine g\u00f6re emekli olamazs\u0131n\u0131z"));
				}else{
					messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("error.hata","Son 7 y\u0131ldaki fiili \u00e7al\u0131\u015fma s\u00fcresine g\u00f6re Ba\u011fkurdan emekli olamazs\u0131n\u0131z."));
				}
				saveErrors(request, messages);
				return mapping.getInputForward();
			}
		}

		HakKazanmaService hakKazanmaService = new HakKazanmaService();
		EmeklilikSartlari emeklilikSartlari = hakKazanmaService.hakKazanmaSorgula(emeklilikBilgileriForm, hizmetListesi);
		HakKazanmaSonucForm hakKazanmaSonucForm = new HakKazanmaSonucForm();
		hakKazanmaSonucForm = hakKazanmaService.getHakKazanmaSonuc(emeklilikSartlari, emeklilikBilgileriForm, hizmetListesi);
		
		request.setAttribute("HakKazanmaSonucForm", hakKazanmaSonucForm);

		return mapping.findForward(Sabit.SUCCESS);
	}
}