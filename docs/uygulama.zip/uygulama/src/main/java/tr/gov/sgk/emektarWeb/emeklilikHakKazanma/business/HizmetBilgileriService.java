package tr.gov.sgk.emektarWeb.emeklilikHakKazanma.business;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;
import org.apache.commons.httpclient.util.DateParseException;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm.HizmetBilgileriForm;
import tr.gov.sgk.emektarWeb.genel.util.GetTarih;
import tr.gov.sgk.emektarWeb.genel.util.Sabit;

public class HizmetBilgileriService {
	
	private static final Logger log = LoggerFactory.getLogger(HizmetBilgileriService.class);
	/**
	 * hizmetleri başlangıç tarihine göre sıralar
	 * @param list
	 */
	public void hizmetleriSirala(ArrayList< HizmetBilgileriForm> list){
		
		Collections.sort(list);
	}
	
	public Date getSBaslangicTarihi(ArrayList<HizmetBilgileriForm> list, String dogumTarihi, boolean sadece3201){
		hizmetleriSirala(list);
		Date sigortalilikBaslangicTarihi;
		int geriAlinacakSure = 0;
		String ilkGercekHizmetTarihi = "";
		
		for (int i =0 ;i<list.size();i++) {
			if(!sadece3201 && (list.get(i).getHizmetTuru().equals(Sabit.HIZMETTURU_ASKERLIKBORC) ||	list.get(i).getHizmetTuru().equals(Sabit.HIZMETTURU_YURTDISIBORC))){
				geriAlinacakSure += Integer.parseInt(list.get(i).getHizmetSuresi());
				ilkGercekHizmetTarihi = list.get(i).getBitisTarihi();
			}
			else{
				ilkGercekHizmetTarihi = list.get(i).getBaslangicTarihi();
				break;
			}
		}
		
		if(geriAlinacakSure == 0){
			sigortalilikBaslangicTarihi= GetTarih.convertStringToDate(ilkGercekHizmetTarihi,"");
		}else{
			sigortalilikBaslangicTarihi =  GetTarih.tarihinUstuneYilAyGunCikart(getYilAyGunArray(geriAlinacakSure), GetTarih.convertStringToDate(ilkGercekHizmetTarihi,""));
			hizmetDuzelt(list);
		}
		//EYT_XXX
//		if(sigortalilikBaslangicTarihi.before(GetTarih.tarihinUstuneYilAyGunEkle(new Integer[]{18,0,0}, GetTarih.convertStringToDate(dogumTarihi,"")))){ 
//			sigortalilikBaslangicTarihi = GetTarih.tarihinUstuneYilAyGunEkle(new Integer[]{18,0,0}, GetTarih.convertStringToDate(dogumTarihi,""));
//		}
	
		return sigortalilikBaslangicTarihi;		
	}
	
	//Askerlik ve yurtdısı hizmetleri ilk gerçek hizmet başlangıç tarihinden itibaren geriye götürülerek düzeltilir. 04.04.2011
	public void hizmetDuzelt(ArrayList<HizmetBilgileriForm> list) {
		Integer sira=-1;
		for (int i=0; i<list.size(); i++) {
			if(list.get(i).getHizmetTuru().equals(Sabit.HIZMETTURU_ASKERLIKBORC) || list.get(i).getHizmetTuru().equals(Sabit.HIZMETTURU_YURTDISIBORC)){
				sira=i;
			}else 
				break;
		}
		for (int i=sira; i>-1; i--) {
			list.get(i).setBitisTarihi((list.get(i+1).getBaslangicTarihi()));
			Date sBasTar =  GetTarih.tarihinUstuneYilAyGunCikart(getYilAyGunArray(Integer.valueOf(list.get(i).getHizmetSuresi())), GetTarih.convertStringToDate(list.get(i).getBitisTarihi(),""));
			list.get(i).setBaslangicTarihi(GetTarih.convertDateToString(sBasTar));
		}
	}
	
	public Date getSBitisTarihi(ArrayList<HizmetBilgileriForm> list){
		hizmetleriSirala(list);
		return GetTarih.convertStringToDate(((HizmetBilgileriForm)list.get(list.size()-1)).getBitisTarihi(), "");
	}
	
	public static Integer[] getYilAyGunArray(int a){
		Integer[] sure= new Integer[3];
		if(a >= 360){
			sure[0] = a/360;
			a = a- sure[0]*360;
		}else sure[0] = 0;
		if(a>=30){
			sure[1] = a/30;
			a = a- sure[1]*30;
		}else sure[1] = 0;
		
		sure [2] = a; 
		
		return sure;
	}
	
	public Date getSon7YilinBasladigiTarih(ArrayList<HizmetBilgileriForm> list){
		Date tarih=null;
		int geriAlinacakSure = 2520; //4447 sk.göre 7 yil
		for(int i=list.size()-1; i>=0 ;i--){
			int sure=Integer.parseInt(list.get(i).getHizmetSuresi());
			if(sure>=geriAlinacakSure){
				return GetTarih.tarihinUstuneYilAyGunCikart(getYilAyGunArray(geriAlinacakSure),GetTarih.convertStringToDate(list.get(i).getBitisTarihi(),""));
			}
			else{
				geriAlinacakSure = (geriAlinacakSure-sure < 0) ? 0 :(geriAlinacakSure-sure);
				tarih = GetTarih.convertStringToDate(list.get(i).getBaslangicTarihi(), "");
			}
		}		
		return tarih; //GetTarih.tarihinUstuneYilAyGunCikart(getYilAyGunArray(geriAlinacakSure),tarih);//tek hizmetlerde kurtarmak için
	}
	
	public Integer getSon7YilKurum(ArrayList<HizmetBilgileriForm> list,String dogumTarihi, boolean sadece3201){

		hizmetleriSirala(list);
		Integer[] son7YilKurumList = new Integer[list.size()];
		Integer son7YilKurum = 0; //Sabit.HIZMETTURU_BAGKUR;
		Integer maxSure=0;
		Date sigortalilikBaslangicTarihi = getSBaslangicTarihi(list, dogumTarihi, sadece3201);
		Date sigortalilikBitisTarihi = getSBitisTarihi(list);
		Date sbtEksi7 =null;
		if(sigortalilikBaslangicTarihi.after(GetTarih.convertStringToDate(Sabit.TARIH_30_04_2008,""))){
			sbtEksi7 = sigortalilikBaslangicTarihi; 	  //tüm hizmetlerde en fazla olan kurumdan aylık bağlanacak 5510 sk.
		}else{
			sbtEksi7 = getSon7YilinBasladigiTarih(list);  //son 7 yıl, fiili olarak çalıştığı süreler kadar geri götürülecek. 4447 sk.
//			sbtEksi7 = GetTarih.tarihinUstuneYilAyGunCikart(new Integer[]{7,0,0}, sigortalilikBitisTarihi); //Sigortalılık bitiş tarihinden önceki 7 yıl içinde en fazla hizmeti olan kurum 
		}

		TreeMap<Integer,Integer> hizmetMap = new TreeMap<Integer, Integer>();
		
		for(int i=list.size()-1; i>=0 ;i--){

			if(GetTarih.convertStringToDate(list.get(i).getBitisTarihi(), "").after(sbtEksi7)){
				Integer hizmetTuru=list.get(i).getHizmetTuru(); //son 7 yil kurumu bulmada yurt dışı sorulacak >SORULDU: BAGKUR OLARAK KABUL EDİLECEK.
				if(hizmetTuru.equals(Sabit.HIZMETTURU_ASKERLIKBORC) || 
						hizmetTuru.equals(Sabit.HIZMETTURU_YURTDISIBORC) || 
						hizmetTuru.equals(Sabit.HIZMETTURU_VERGIBORCLANMASI))
					hizmetTuru=Sabit.HIZMETTURU_BAGKUR;
		
				if(GetTarih.convertStringToDate(list.get(i).getBaslangicTarihi(), "").after(sbtEksi7)){
					if(hizmetMap.containsKey(hizmetTuru))
						hizmetMap.put(hizmetTuru, hizmetMap.get(hizmetTuru) + Integer.valueOf(list.get(i).getHizmetSuresi()));
					else 
						hizmetMap.put(hizmetTuru, Integer.valueOf(list.get(i).getHizmetSuresi()));
				} else {
					int hesapSure = Integer.valueOf(GetTarih.getDateDifferenceForBagkur(GetTarih.convertDateToString(sbtEksi7), list.get(i).getBitisTarihi()));
					if(hesapSure > Integer.valueOf(list.get(i).getHizmetSuresi()))
						hesapSure = Integer.valueOf(list.get(i).getHizmetSuresi());
					
					if(hizmetMap.containsKey(hizmetTuru))
						hizmetMap.put(hizmetTuru, hizmetMap.get(hizmetTuru) + hesapSure);
					else
						hizmetMap.put(hizmetTuru, hesapSure);
				}
				son7YilKurumList[i]=hizmetTuru;
			}
		}		
		for(Map.Entry<Integer, Integer> entry :hizmetMap.entrySet()){
			if(entry.getValue()> maxSure){
				maxSure = entry.getValue();
				son7YilKurum = entry.getKey();
			}else{
				if(entry.getValue().equals(maxSure)){
					for(int i=son7YilKurumList.length-1; i>=0; i--){ 
						if(son7YilKurum.equals(son7YilKurumList[i]) || entry.getKey().equals(son7YilKurumList[i])){
							son7YilKurum=son7YilKurumList[i];
							break;
						}
					}
				}
			}
		}
//		if(son7YilKurum.equals(Sabit.HIZMETTURU_BAGKUR))  //3,5 YIL 1260 GÜN kontrolü YAPILMAYACAK. MEVZUAT
//			if(maxSure<1260) son7YilKurum=0;
		return son7YilKurum;
	}
	
	public boolean bagkurHizmetiVarmi(ArrayList<HizmetBilgileriForm> list){
		
		for(HizmetBilgileriForm form : list){
			if(form.getHizmetTuru().equals(Sabit.HIZMETTURU_BAGKUR) || 
				form.getHizmetTuru().equals(Sabit.HIZMETTURU_VERGIBORCLANMASI))
				return true;
		}
		return false;
	}
	
	public Integer getToplamHizmet(ArrayList<HizmetBilgileriForm> hizmetListesi){
		
		Integer sure =0;
		for(HizmetBilgileriForm form : hizmetListesi){
			sure = sure + Integer.valueOf(form.getHizmetSuresi());
			if(StringUtils.isNotBlank(form.getFiiliHizmetSuresi()))
				sure = sure + Integer.valueOf(form.getFiiliHizmetSuresi());
		}

		return sure;
	}

}
