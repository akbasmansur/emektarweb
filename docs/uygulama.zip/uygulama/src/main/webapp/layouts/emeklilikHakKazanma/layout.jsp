<%@page language="java" contentType="text/html; charset=ISO-8859-9"
	pageEncoding="ISO-8859-9"%>
<%@taglib prefix="bean" uri="/WEB-INF/config/tld/struts-bean.tld"%>
<%@taglib prefix="display" uri="/WEB-INF/config/tld/displaytag.tld"%>
<%@taglib prefix="tiles" uri="/WEB-INF/config/tld/struts-tiles.tld"%>
<%@taglib prefix="html" uri="/WEB-INF/config/tld/struts-html.tld"%>
<%@taglib prefix="logic" uri="/WEB-INF/config/tld/struts-logic.tld"%>
<%@taglib prefix="nested" uri="/WEB-INF/config/tld/struts-nested.tld"%>
<%@taglib prefix="emektar" uri="/WEB-INF/config/tld/emektar.tld"%>

<tiles:useAttribute name="Links" scope="request"/>
<%@page import="tr.gov.sgk.emektarWeb.genel.util.Sabit"%>
<%@page import="java.util.ResourceBundle"%>
<%@page import="tr.gov.sgk.emektarWeb.genel.util.Arac"%>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9"></meta>
<meta http-equiv="Pragma" content="no-cache"></meta>
<meta http-equiv="Expires" content="-1"></meta>
<meta http-equiv="cache-control" content="no-cache"></meta>
	<title>Sosyal G�venlik Kurumu</title>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-9">
	
	<link type="text/css" rel="stylesheet" href="css/style.css" />
<link type="text/css" rel="stylesheet" href="css/displayTag.css" />
<script type="text/javascript" src="js/displayTag/tablo.js"></script>
<script type="text/javascript" src="js/PopUp.js"></script>
<script type="text/javascript" src="js/utils.js"></script>
<script type="text/javascript" src="js/window/windows.js"></script>
<script type="text/javascript" src="js/window/prototype.js"> </script>
<script type="text/javascript" src="js/window/effects.js"> </script>
<script type="text/javascript" src="js/window/window.js"> </script>
<script type="text/javascript" src="js/window/debug.js"> </script>
<link type="text/css" rel="stylesheet" href="css/window/alphacube.css">
<link type="text/css" rel="stylesheet" href="css/window/default.css">

<script type="text/javascript" src="js/calendar/date.js"></script>
<script type="text/javascript" src="js/calendar/dateFormat.js"></script>
<script> invalidDate = 'gecersiz tarih'; </script>
<script type="text/javascript" src="js/calendar/calendar.js"></script>
<script type="text/javascript" src="js/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="js/calendar/calendar-tr.js"></script>
<style> @import url("<%=Sabit.ANA_DIZIN%>css/calendar/calendar-system.css"); </style>

<script type='text/javascript' src="js/staticJavascript.js"></script>
	
	<script language="JavaScript">
		var maxExportKayitSayisi = <%= Sabit.MAX_EXPORT_SIZE %>;
		var maxExportUyarisi = ' ';
	
		function paintTheRow(row) {
			row.style.cursor='hand';
			row.style.background='#EAF4FF';
		}
		function resetTheRowColor(row) {
			row.style.background='#FFFFFF';
		}
		
		function browser(){
			if ((navigator.appName).indexOf("Microsoft")!=-1){  
				return true;
			}
			else{ 
				alert("Bu uygulama Microsoft Internet Explorer taray�c�s� ile uyumludur.");
				return false;
			}
	}
	
	</script>
	
<%
	ResourceBundle bundle = Arac.getResourceBundle(request);
%>

<script language="javascript">
	var secinizUyarisi = '<%=Arac.getBundleValue(bundle, "label.genel.kayitSeciniz")%>';
	var siliniyorUyarisi = '<%=Arac.getBundleValue(bundle, "label.genel.silinecek")%>';
	
</script>
</head>

<body onload="browser();"  bgcolor="#FFFFFF" text="#000000" leftmargin="2" topmargin="2" marginwidth="0" marginheight="0">
 <tiles:insert attribute="header"/>
	<table width="100%" border="0" cellspacing="0" cellpadding="0" height="450">
		<tr> 
			<td width="165" valign="top" style="padding-top:5; padding-left:5; padding-right:5; padding-bottom:5;" bgcolor="#EEEEEE"> 
		        <tiles:insert attribute="navigation"/>	
			</td>
			<td align="center" valign="top" style="padding:10 10 10 10;" class="paragraph"> 
				<tiles:insert attribute="messages"/>
				<tiles:insert attribute="content"/>	
			</td>
		</tr>
	</table>
 <tiles:insert attribute="footer"/>
</body>
</html>
