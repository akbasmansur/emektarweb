var emektarDegerListe;
var degerListesiAdi = 'Hizmet Listesi';

function openModalDialog() {
	var win = new Window('modal_window', {className: "dialog", title: degerListesiAdi,showEffect:Element.show, hideEffect: Element.hide,top:25, left:25,  width:730, height:410, zIndex:150, opacity:1, resizable: false, minimizable:false, maximizable:false});
	win.setContent("popUpDiv");
	win.setDestroyOnClose();
	win.setCloseCallback(canClose);
	win.show(true);	
}
  
function bilgiAc(url) {
  	var bilgiWindow = new Window('modal_window', {className: "dialog", showEffect:Element.show, hideEffect: Element.hide,top:50, left:50,  width:800, height:450, zIndex:150, opacity:1, resizable: false, minimizable:false, maximizable:false});
	bilgiWindow.setURL(url);
	bilgiWindow.setDestroyOnClose();
	bilgiWindow.setCloseCallback(canClose);
	bilgiWindow.show(true);	   
}

function canClose(win) {
		document.getElementById("popUpDiv").style.display = "none";
		return true;
}



var pKurumId;
var pKisiId;
var pHizmetListeAdi;

function HizmetGetir(kurumId,kisiId,hizmetListeAdi)
{	
	pKisiId=kisiId;
	pKurumId=kurumId;
	pHizmetListeAdi=hizmetListeAdi;
	
	if(pKisiId!=null && pKisiId!="" )		
	{	
		HizmetService.getKurumHizmetListDetay(pKurumId,pKisiId,HizmetForm);	
	}
	
}

function HizmetForm(hizmetData)
{
	
	if (hizmetData.length > 0 ) {
		emektarDegerListe = pHizmetListeAdi;
		fillHizmetTable(hizmetData);
	}
	else if (hizmetData.length == 0 ) {
		alert(hizmetBulunamadi);	
	}
}

		
var getKurum = function(hizmetData) { return hizmetData.sicilForm.kurumAdi };
var getBaslangicTarihi = function(hizmetData) { return hizmetData.baslangicTarihi };
var getBitisTarihi= function(hizmetData) { return hizmetData.bitisTarihi };
var getGun = function(hizmetData) { return hizmetData.gun };
var getKazanc = function(hizmetData) { return hizmetData.kazancTutari};
var getHizmetTipi = function(hizmetData) { return hizmetData.hizmetTipiForm.ad};
var getBorclanmaTarihi = function(hizmetData) { return hizmetData.borclanmaTalepTarihi};

   
function fillHizmetTable(hizmetData) {
       DWRUtil.removeAllRows("popUpTable");
       DWRUtil.addRows("popUpTable",hizmetData, [ getKurum,getHizmetTipi,getBaslangicTarihi,getBitisTarihi,getBorclanmaTarihi,getGun,getKazanc ],{
		       rowCreator:function(options) {
       var row = document.createElement("tr");
       if ( options.rowIndex % 2 == 0 ) 
		    row.className = "odd";
	   else 
		    row.className = "even";	
	   row.onmouseover=function(){rd(row);}; 	    
	   row.onmouseout=function(){er(row);}; 	
	   row.ondblclick=function(){Windows.closeAllModalWindows();}; 

       return row;}
       });
       var displayRow = document.getElementById('popUpRowHizmetBilgileri');
       displayRow.style.display = "block";
       var displayRow1 = document.getElementById('popUpRowSaglikRaporuBilgileri');
       displayRow1.style.display = "none";
       degerListesiAdi = "Hizmet Listesi";
       openModalDialog();    
   }

function navigateForm(){
	//theLayerTBody = document.getElementById("theLayerTBody");
	parameterForm = document.forms[0];
	inputFields = parameterForm.getElementsByTagName("input");
	for (var i=0; i < inputFields.length;i++){
		if ((inputFields[i].type == 'text' ||
               inputFields[i].type == 'textarea' ||
               inputFields[i].type == 'file' ||
               inputFields[i].type == 'checkbox' ||
               inputFields[i].type == 'select-one' ||
               inputFields[i].type == 'password' ||
               inputFields[i].type == 'select-multiple' ||
               inputFields[i].type == 'radio' ||
               inputFields[i].type == 'checkbox')&&
               inputFields[i].disabled == false){
           	inputFields[i].focus();
           	break;
           }
	}
}

var ilceId=function (ilceForm){return ilceForm.id;};
var ilceAdi=function (ilceForm){return ilceForm.ad;};
function updateIlceBilgisi(il){
	secim = il.options[il.selectedIndex].value;
	IlIlceService.getIlceByIlId(secim,updateIlceSelect);
}

function updateIlceSelect(ilceForm){
	if(ilceForm!=null){
		DWRUtil.removeAllOptions("ilceField");
		DWRUtil.addOptions("ilceField",ilceForm,ilceId,ilceAdi);
		}
}

var subeId=function (subeForm){return subeForm.id;};
var subeAdi=function (subeForm){return subeForm.ad;};
function updateSubeBilgisi(banka,il){
	secim1 = banka.options[banka.selectedIndex].value;
	secim2 = il.options[il.selectedIndex].value;
		BankaSubeService.getSubeByBankaIdAndIlId(secim1,secim2,updateSubeSelect);
}

function updateSubeSelect(subeForm){
	if(subeForm!=null){
		DWRUtil.removeAllOptions("subeField");
		DWRUtil.addOptions("subeField",subeForm,subeId,subeAdi);
		}
}





