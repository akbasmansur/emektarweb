package tr.gov.sgk.emektarWeb.genel.util;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;

public class Sabit {

	// ID_ 				: id olanların yazılması 
	// SESSION_ 		: session a atılanlar 
	// DEFAULT_ 		: default degerler
	// FORM_			: form sabitleri
	// TIP_				: Long, Integer 
	
	public static final String SUCCESS = "success";
	
	public static final String ortamProd = "PROD";
	public static final String ortamTest = "TEST";
	public static final String ortamLokal = "LOKAL"; 
	
	public static final String KPS_KULLANICIADI = "KPS_KULLANICIADI";
	public static final String KPS_SIFRE = "KPS_SIFRE";
	public static final String SEQUENCE_TAHSISNO = "TAHSISNO_SEQUENCE";
			
	public static final Integer DEFAULT_INT = new Integer(0);
	public static final Double DEFAULT_DOUBLE = new Double(0.00);
	public static final String DEFAULT_STRING = new String("");
	public static final Long DEFAULT_LONG = new Long(0);
	public static final BigDecimal DEFAULT_BIGDECIMAL = new BigDecimal(0);
	public static final String DEFAULT_DATE = "01/01/1000";
	public static final Boolean DEFAULT_BOOLEAN = new Boolean(true);
	
	//FORM_
	public static final String EKLEYEN = "ekleyen";
	public static final String EKLEME_TARIHI = "eklemeTarihi";
	public static final String GUNCELLEYEN = "guncelleyen";
	public static final String GUNCELLEME_TARIHI = "guncellemeTarihi";
	public static final String KULLANICIADI = "kullaniciAdi";
	public final static String ILETI = "_ILETI_";
	public static final String OTURUM_SAYFA = "sayfaSBT";

	public static final String ILK_GIRIS = "IlkGiris";
 
	// LISTELER 
	public final static String LISTE = "_LISTE_";
	public final static String LISTE2 = "_LISTE2_";
	public final static String HAKSAHIPLERILISTE = "_HAKSAHIPLERILISTE_";
	public final static String YABANCILARLISTE = "_YABANCILARLISTE_";

	public final static java.util.Locale LOCALE_TR = new java.util.Locale("TR","T\u00dcRK\u0130YE");

	public final static String YEREL = "_YEREL_";
	public final static String YEREL_TR = "_TR_";
	public final static String YEREL_EN = "_EN_";
	public final static String ANA_DIZIN = "/EMEKTARWEB/";

	public static final int MAX_EXPORT_SIZE = 1000;
	public static final String LISTE_SAYFA = "d-1340563-p";

	public final static String OTURUM_BILGILERI = "_OTURUM_BILGILERI_";
	public final static String HATA_MESAJ = "_HATA_MESAJ_";

	public final static SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	public final static SimpleDateFormat dateFormatFull = new SimpleDateFormat("dd/MM/yyyy HH:mm");
	public final static String dateFormatString = "dd/MM/yyyy";

	public static final String TARGET = "target";
	
	public static final Integer  TIP_INTEGER = 1;
	public static final Integer  TIP_STRING = 2;
	public static final Integer  TIP_LONG = 3;
	public static final Integer  TIP_BIGDECIMAL = 4;
	public static final Integer  TIP_DATE = 5;
	public static final Integer  TIP_DOUBLE = 6;
	public static final Integer  TIP_CLASS = 7;
	
	public final static Integer AKTIFMI = new Integer(1);
	public final static Integer PASIFMI = new Integer(0);

	public final static String KONTROL = "KONTROL";
	public final static String KONTROL2 = "KONTROL2";
	public final static String KONTROL3 = "KONTROL3";
	
	public static final String EKLE = "eklemeIslemi";
	public static final String GUNCELLE = "guncellemeIslemi";

	public static final String COMBO_ULKE = "ulkeList";

	public final static Integer AYLIK_DURUM_BIRINCIKARAR = 1;
	public final static Integer AYLIK_DURUM_DURDURULDU_EVLILIKODENEGI= 4;
	public final static Integer AYLIK_DURUM_DURDURULDU_HAREKETSIZ= 5;
	public final static Integer AYLIK_DURUM_DURDURULDU_OGRENIMBELGESI = 6;
	public final static Integer AYLIK_DURUM_DURDURULDU_EVLILIKDURUMU = 7;
	public final static Integer AYLIK_DURUM_DURDURULDU_CALISIYOR = 8;
	public final static Integer AYLIK_DURUM_DURDURULDU_SAGLIKRAPORU = 9;
	public final static Integer AYLIK_DURUM_DURDURULDU_OLUMEDEVIR = 10;
	public final static Integer AYLIK_DURUM_DURDURULDU_ECELLEOLUM = 11;
	public final static Integer AYLIK_DURUM_DURDURULDU_BILINMIYOR = 12;
	
	public final static Integer AYLIKNEVI_MALULIYET = 1;
	public final static Integer AYLIKNEVI_YASLILIK = 2;
	public final static Integer AYLIKNEVI_SUREKLIISGOREMEZLIK = 3;
	public final static Integer AYLIKNEVI_OLUM = 4;
	public final static Integer AYLIKNEVI_CENAZE = 5;
	
	public final static Integer KREDIDURUM_IL_SUBE_DEGISIR = 1;
	public final static Integer KREDIDURUM_BANKA_IL_SUBE_DEGISIR = 2;
	public final static Integer KREDIDURUM_DEGISIKLIK_YAPILAMAZ = 3;
	
	public final static Long HALKBANKASI = new Long(3354345);
	public final static Long ZIRAATBANKASI =	new Long(3354344);	
	
	public final static String SESSION_AYLIKGELIRBILGILERI = "AylikGelirForm";
	public final static String SESSION_HAKSAHIBIAYLIKGELIRBILGILERI = "HakSahibiAylikGelirForm";
	public final static String SESSION_LOGINBILGILERI = "BankaLoginForm";
	public final static String SESSION_ADRESBILGILERI = "AdresForm";
	public final static String SESSION_HESAPBILGILERI = "HesapForm";
	
	public final static Integer HAYIR = new Integer(1);	
	public final static Integer EVET = new Integer(2);
	
	// ISLEM KODLARI	
	public final static Integer ISLEM_BASARISIZGIRISDENEMESI = 1;
	public final static Integer ISLEM_SUBEDEGISIKLIGI = 2;
	public final static Integer ISLEM_BANKAVESUBEDEGISIKLIGI = 3;	
	
	// EMEKLİLİK TÜRLERİ
	public final static String EMEKLILIKTURU_TAM = new String("1");
	public final static String EMEKLILIKTURU_KISMI = new String("0");
	
	//CİNSİYET TÜRÜ
	public final static String CINSIYET_ERKEK = new String("1");
	public final static String CINSIYET_KADIN = new String("0");	

	//MALULİYET DERECESİ
	public final static String MALULIYET_40_49 = new String("1");
	public final static String MALULIYET_50_59 = new String("2");
	public final static String MALULIYET_60_100 = new String("3");
	
	public final static String SESSION_EMEKLILIKBILGILERI = "EmeklilikBilgileriForm";
	public final static String SESSION_HIZMETLISTESI = "hizmetListesi";
	
	// hizmet turleri
	public final static Integer HIZMETTURU_BAGKUR = 1;
	public final static Integer HIZMETTURU_SSK = 2;
	public final static Integer HIZMETTURU_ES = 3;
	public final static Integer HIZMETTURU_DS = 4;
	public final static Integer HIZMETTURU_YURTDISIBORC = 5;
	public final static Integer HIZMETTURU_ASKERLIKBORC = 6;
	public final static Integer HIZMETTURU_VERGIBORCLANMASI = 7;
	
	public final static String TARIH_01_06_2002 = new String("01/06/2002");
	public final static String TARIH_01_10_1999 = new String("01/10/1999");
	public final static String TARIH_08_09_1999 = new String("08/09/1999");
	public final static String TARIH_30_04_2008 = new String("30/04/2008");
	public final static String TARIH_01_04_1981 = new String("01/04/1981");
	public final static String TARIH_01_10_2008 = new String("01/10/2008");
	public final static String TARIH_04_05_1979 = new String("04/05/1979");
	public final static String TARIH_01_05_2008 = new String("01/05/2008");
	//public final static String TARIH_01_02_2023 = new String("01/02/2023"); //TODO 1.EYT_XXX  kanunun yururluk tarihi
	public final static String TARIH_03_03_2023 = new String("03/03/2023"); //TODO 1.EYT_XXX  kanunun yururluk tarihi
	
	public final static Integer HIZMET_25_YIL = 9000;
	public final static Integer HIZMET_20_YIL = 7200;
	public final static Integer HIZMET_15_YIL = 5400;
	
	public final static Integer EYT_TIP1 = 1; //1.EYT ??.??.???? yururluk tarihi itibariyle
//	public final static Integer EYT_TIP2 = 2; //1.EYT ??.??.???? yururluk tarihi itibariyle
	
}
	