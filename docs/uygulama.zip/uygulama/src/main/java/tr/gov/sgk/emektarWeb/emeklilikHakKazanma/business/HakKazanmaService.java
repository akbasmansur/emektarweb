package tr.gov.sgk.emektarWeb.emeklilikHakKazanma.business;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm.EmeklilikBilgileriForm;
import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm.HakKazanmaSonucForm;
import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm.HizmetBilgileriForm;
import tr.gov.sgk.emektarWeb.genel.util.GetTarih;
import tr.gov.sgk.emektarWeb.genel.util.Sabit;

public class HakKazanmaService {
	
	private static final Logger log = LoggerFactory.getLogger(HakKazanmaService.class);
	
	public EmeklilikSartlari hakKazanmaSorgula(EmeklilikBilgileriForm emeklilikBilgileriForm, ArrayList<HizmetBilgileriForm> hizmetListesi){
		
		HizmetBilgileriService hizmetBilgileriService= new HizmetBilgileriService();
		String cinsiyet = emeklilikBilgileriForm.getCinsiyet();
		String emeklilikTuru = emeklilikBilgileriForm.getEmeklilikTuru();
		Integer Yas18OncesiHizmet = getYas18OncesiHizmet(emeklilikBilgileriForm, hizmetListesi, false); //18 oncesi hizmet hakkazanmada düşülecek 18.01.2012
		//kanun öncesi hizmette fiili hizmetler dahil edilmeyecek 18.01.2012
		//2013-26 sayılı genelge ile fiili hizmetler dahil edildi. 09.07.2013
		Integer kanunOncesiHizmet = getKanunOncesiHizmet(emeklilikTuru, hizmetListesi, true); 
		kanunOncesiHizmet = (kanunOncesiHizmet-Yas18OncesiHizmet)<0 ? 0 : (kanunOncesiHizmet-Yas18OncesiHizmet) ;
		Date sigBasTar = hizmetBilgileriService.getSBaslangicTarihi(hizmetListesi, emeklilikBilgileriForm.getDogumTarihi(), emeklilikBilgileriForm.getSadece3201());
		Date sigBitTar = hizmetBilgileriService.getSBitisTarihi(hizmetListesi);
		Integer yas_01101999_Gun = get_01_10_1999_YasiGunOlarak(emeklilikBilgileriForm.getDogumTarihi());
		Integer maluliyetVarmi = Integer.valueOf(emeklilikBilgileriForm.getMaluliyetVarmi());
		String maluliyetDerecesi = emeklilikBilgileriForm.getMaluliyetDerecesi();
		Integer erkenYaslanmaVarmi = Integer.valueOf(emeklilikBilgileriForm.getErkenYaslanmaVarmi());
		Boolean ilkGercekHizmetMi = true; //ilkGercekHizmetMi(hizmetListesi); //2013-26 sayılı genelgeye göre kontrol kaldırıldı.
		
		EmeklilikSartlari emeklilikSartlari = new EmeklilikSartlari(cinsiyet,kanunOncesiHizmet,emeklilikTuru,sigBasTar,sigBitTar,yas_01101999_Gun, maluliyetVarmi,maluliyetDerecesi,erkenYaslanmaVarmi,ilkGercekHizmetMi,emeklilikBilgileriForm.getDogumTarihi());
		return emeklilikSartlari;
	}
	
	// Askerlik ve Vergi borclanması hizmetleri için 01101999 öncesi gerçek hizmet kaydı yoksa 4447 SK şartları uygulanması için
	// 2013-26 sayılı genelgeye göre kontrol kaldırıldı
	public Boolean ilkGercekHizmetMi(ArrayList<HizmetBilgileriForm> hizmetListesi){
		Boolean kontrol=true;

		for (HizmetBilgileriForm form : hizmetListesi) {
			if(GetTarih.convertStringToDate(form.getBaslangicTarihi(),"").before(GetTarih.convertStringToDate(Sabit.TARIH_01_10_1999,""))){
				if(form.getHizmetTuru().equals(Sabit.HIZMETTURU_ASKERLIKBORC) || form.getHizmetTuru().equals(Sabit.HIZMETTURU_VERGIBORCLANMASI)){
					kontrol=false;
				}else{
					return true;
				}
			}
		}		
		return kontrol;
	}
	
	public Integer getKanunOncesiHizmet(String emeklilikTuru,ArrayList<HizmetBilgileriForm> hizmetListesi, Boolean fiiliHizmetEkle){
		Integer sure=0;
		for(HizmetBilgileriForm form: hizmetListesi){
			if(emeklilikTuru.equals(Sabit.EMEKLILIKTURU_TAM)){
				if(!GetTarih.convertStringToDate(form.getBitisTarihi(),"").after(GetTarih.convertStringToDate(Sabit.TARIH_01_06_2002,""))){
					sure = sure + Integer.valueOf(form.getHizmetSuresi());
					if(StringUtils.isNotBlank(form.getFiiliHizmetSuresi()) && fiiliHizmetEkle)
						sure  = sure + Integer.valueOf(form.getFiiliHizmetSuresi());
				}
					//fiili hizmet dikkate alınmayacak 18.01.2012?
					//fiili hizmet eklendi 09.07.2013
				else if(GetTarih.convertStringToDate(form.getBaslangicTarihi(),"").before(GetTarih.convertStringToDate(Sabit.TARIH_01_06_2002,"")) 
					&& GetTarih.convertStringToDate(form.getBitisTarihi(),"").after(GetTarih.convertStringToDate(Sabit.TARIH_01_06_2002,""))){
						sure = sure + GetTarih.getDateDifferenceForBagkur(form.getBaslangicTarihi(), Sabit.TARIH_01_06_2002);
						if(StringUtils.isNotBlank(form.getFiiliHizmetSuresi()) && fiiliHizmetEkle)
							sure  = sure + Integer.valueOf(form.getFiiliHizmetSuresi());
					}
			}
			if(emeklilikTuru.equals(Sabit.EMEKLILIKTURU_KISMI)){
				if(!GetTarih.convertStringToDate(form.getBitisTarihi(),"").after(GetTarih.convertStringToDate(Sabit.TARIH_01_10_1999,""))){
					sure = sure + Integer.valueOf(form.getHizmetSuresi());
					if(StringUtils.isNotBlank(form.getFiiliHizmetSuresi()) && fiiliHizmetEkle)
						sure  = sure + Integer.valueOf(form.getFiiliHizmetSuresi());
				}
				//fiili hizmet dikkate alınmayacak 18.01.2012?
				//fiili hizmet eklendi 09.07.2013
				else if(GetTarih.convertStringToDate(form.getBaslangicTarihi(),"").before(GetTarih.convertStringToDate(Sabit.TARIH_01_10_1999,"")) 
					&& GetTarih.convertStringToDate(form.getBitisTarihi(),"").after(GetTarih.convertStringToDate(Sabit.TARIH_01_10_1999,""))){
						sure = sure + GetTarih.getDateDifferenceForBagkur(form.getBaslangicTarihi(), Sabit.TARIH_01_10_1999);
						if(StringUtils.isNotBlank(form.getFiiliHizmetSuresi()) && fiiliHizmetEkle)
							sure  = sure + Integer.valueOf(form.getFiiliHizmetSuresi());
					}
			}
		}
		return sure;
	}
		
	public Integer getYas18OncesiHizmet(EmeklilikBilgileriForm emeklilikBilgileriForm, ArrayList<HizmetBilgileriForm> hizmetListesi, Boolean fiiliHizmetEkle){
		// 01.04.1981 oncesi ilk hizmet SSK olup, 18 yasindan once SSK'li olanlar;
		// 04.05.1979 oncesi ilk hizmet BAGKUR olup, 18 yasindan once BAGKUR'lu olanlar; 02.01.2013
		// - 18 yasalt� hizmet suresi toplam hizmete eklenecek.
		// - Sigortalilik baslangic tarihi yine 18 yasini dolduruldugu tarih olacak.
		// - Kanun oncesi (1.10.1999 veya 1.6.2002) YAS HESABINDA 18 yaS alti hizmet+fiili sureleri  DIKKATE ALINACAK!!! 2010	
		// - Kanun oncesi (1.10.1999 veya 1.6.2002) YAS HESABINDA 18 yaS alti hizmet+fiili sureleri  DIKKATE ALINMAYACAK 18.01.2011	

		int sure=0;
		Date yas18 = GetTarih.tarihinUstuneYilAyGunEkle(new Integer[]{18,0,0}, GetTarih.convertStringToDate(emeklilikBilgileriForm.getDogumTarihi(), ""));
		
		for(HizmetBilgileriForm form: hizmetListesi){
			if((form.getHizmetTuru().equals(Sabit.HIZMETTURU_SSK) &&	
					GetTarih.convertStringToDate(form.getBaslangicTarihi(),"").before(GetTarih.convertStringToDate(Sabit.TARIH_01_04_1981,""))) ||
				(form.getHizmetTuru().equals(Sabit.HIZMETTURU_BAGKUR) && 
					GetTarih.convertStringToDate(form.getBaslangicTarihi(),"").before(GetTarih.convertStringToDate(Sabit.TARIH_04_05_1979,"")))){
				if(GetTarih.convertStringToDate(form.getBaslangicTarihi(),"").before(yas18)){
					sure=sure+Integer.valueOf(form.getHizmetSuresi());
					if(StringUtils.isNotBlank(form.getFiiliHizmetSuresi()) && fiiliHizmetEkle)
						sure  = sure + Integer.valueOf(form.getFiiliHizmetSuresi());
				}
			}
		}
		return sure;
	}

	
	public Integer get_01_10_1999_YasiGunOlarak(String dogumTarihi){
		
		return GetTarih.getDateDifferenceForBagkur(dogumTarihi, Sabit.TARIH_01_10_1999);
	}
	
	public HakKazanmaSonucForm getHakKazanmaSonuc(EmeklilikSartlari emeklilikSartlari, EmeklilikBilgileriForm emeklilikBilgileriForm, ArrayList<HizmetBilgileriForm> hizmetListesi){
		HakKazanmaSonucForm hakKazanmaSonucForm = new HakKazanmaSonucForm();
		HizmetBilgileriService hizmetBilgileriService = new HizmetBilgileriService();
		hakKazanmaSonucForm.setEmeklilikSartlari(emeklilikSartlari);
		hakKazanmaSonucForm.setYasiniz(getSigortaliYas(emeklilikBilgileriForm.getDogumTarihi(), hizmetBilgileriService.getSBitisTarihi(hizmetListesi)));
		hakKazanmaSonucForm.setSigortalilikSureniz(getSigortalilikSuresi(hizmetBilgileriService.getSBaslangicTarihi(hizmetListesi, emeklilikBilgileriForm.getDogumTarihi(), emeklilikBilgileriForm.getSadece3201()), hizmetBilgileriService.getSBitisTarihi(hizmetListesi)));
		hakKazanmaSonucForm.setHizmetSureniz(hizmetBilgileriService.getToplamHizmet(hizmetListesi));
		emeklilikSartlariKarsilastir(hakKazanmaSonucForm,emeklilikBilgileriForm);
		emeklilikTarihiHesapla(hakKazanmaSonucForm, emeklilikBilgileriForm, hizmetListesi);
		if(emeklilikBilgileriForm.getBakMuhCoc()== true)
			bakimaMuhtacCocukHizmetiDus(hakKazanmaSonucForm, emeklilikBilgileriForm);

		return hakKazanmaSonucForm;
		
	}
	
	public Integer getSigortaliYas(String dogumTarihi, Date sigBitTar){
	  if(sigBitTar.after(new Date()))
			return GetTarih.getDateDifferenceForBagkur(dogumTarihi, GetTarih.convertDateToString(sigBitTar));
		else
			return GetTarih.getDateDifferenceForBagkur(dogumTarihi, GetTarih.getTarihString()); 
		
//		return GetTarih.getDateDifferenceForBagkur(dogumTarihi, GetTarih.convertDateToString(sigBitTar));
	}
	
	public Integer getSigortalilikSuresi(Date sigBasTar, Date sigBitTar){
		Integer sure=0;
		if(sigBitTar.after(new Date()))
			sure= GetTarih.getDateDifferenceForBagkur(GetTarih.convertDateToString(sigBasTar), GetTarih.convertDateToString(sigBitTar));
		else
			sure= GetTarih.getDateDifferenceForBagkur(GetTarih.convertDateToString(sigBasTar), GetTarih.getTarihString());
		
		if((new Date()).after(GetTarih.convertStringToDate(Sabit.TARIH_01_10_2008, "")))
			sure=sure+1;
//		Integer sure=GetTarih.getDateDifferenceForBagkur(GetTarih.convertDateToString(sigBasTar), GetTarih.convertDateToString(sigBitTar));	
		return sure; 
	}
	
	public void emeklilikSartlariKarsilastir(HakKazanmaSonucForm form, EmeklilikBilgileriForm emeklilikBilgileriForm){

		if(form.getEmeklilikSartlari().isEytKapsamindaMi()) {
			if(form.getEmeklilikSartlari().getEytTip()!=null && form.getEmeklilikSartlari().getEytTip().compareTo(Sabit.EYT_TIP1)==0 &&
					form.getEmeklilikSartlari().getYas()!=null && form.getEmeklilikSartlari().getYas_eyt()!=null &&  
					form.getEmeklilikSartlari().getYas()>0 && form.getEmeklilikSartlari().getYas().compareTo(form.getEmeklilikSartlari().getYas_eyt())!=0)
			{
				Date yasETarih = GetTarih.tarihinUstuneYilAyGunEkle(new Integer[]{form.getEmeklilikSartlari().getYas(),0,0}, GetTarih.convertStringToDate(emeklilikBilgileriForm.getDogumTarihi(),null));
				if(yasETarih.compareTo(GetTarih.convertStringToDate(Sabit.TARIH_03_03_2023, null))>=0){
					form.getEmeklilikSartlari().setYas(form.getEmeklilikSartlari().getYas_eyt());
					form.getEmeklilikSartlari().setEytUygulandi(true);
				}
			}
		}

		form.setKalanYasiniz(form.getEmeklilikSartlari().getYas()*360 - form.getYasiniz()<= 0 ? 0:form.getEmeklilikSartlari().getYas()*360 - form.getYasiniz());
		form.setKalanSigortalilikSureniz(form.getEmeklilikSartlari().getSigortalilikSuresi()- form.getSigortalilikSureniz() <= 0 ? 0: form.getEmeklilikSartlari().getSigortalilikSuresi()- form.getSigortalilikSureniz());
		form.setKalanHizmetSureniz(form.getEmeklilikSartlari().getHizmetSuresi()-form.getHizmetSureniz() <=0 ? 0 :form.getEmeklilikSartlari().getHizmetSuresi()-form.getHizmetSureniz());
		
	}
	

	public void emeklilikTarihiHesapla(HakKazanmaSonucForm form, EmeklilikBilgileriForm emeklilikBilgileriForm, ArrayList<HizmetBilgileriForm> hizmetListesi){

		HizmetBilgileriService hizmetBilgileriService = new HizmetBilgileriService();
		Date sigBitTar = hizmetBilgileriService.getSBitisTarihi(hizmetListesi);
		Date sigBasTar = hizmetBilgileriService.getSBaslangicTarihi(hizmetListesi, emeklilikBilgileriForm.getDogumTarihi(), emeklilikBilgileriForm.getSadece3201());
		
		Date yasETarih = sigBitTar;
		Date sigortalilikETarih = sigBitTar; 
		Date hizmetETarih = sigBitTar;  
		Date emeklilikTarihi = sigBitTar;
		
		if(form.getEmeklilikSartlari().getYas()!=null && form.getEmeklilikSartlari().getYas()>0){
			yasETarih = GetTarih.tarihinUstuneYilAyGunEkle(new Integer[]{form.getEmeklilikSartlari().getYas(),0,0}, GetTarih.convertStringToDate(emeklilikBilgileriForm.getDogumTarihi(),null));
			if(yasETarih.after(sigBitTar)){
				emeklilikTarihi = yasETarih;
			}
		}		
		if(form.getEmeklilikSartlari().getSigortalilikSuresi()!=null && form.getEmeklilikSartlari().getSigortalilikSuresi()>0){
			sigortalilikETarih = GetTarih.tarihinUstuneYilAyGunEkle(new Integer[]{0,0,form.getEmeklilikSartlari().getSigortalilikSuresi()}, sigBasTar);
			if(sigortalilikETarih.after(emeklilikTarihi)){
				emeklilikTarihi = sigortalilikETarih;
			}
		}
		if(form.getEmeklilikSartlari().getHizmetSuresi()!=null && form.getEmeklilikSartlari().getHizmetSuresi()>0){
			hizmetETarih = GetTarih.tarihinUstuneYilAyGunEkle(new Integer[]{0,0,form.getEmeklilikSartlari().getHizmetSuresi()}, sigBasTar);
			if(hizmetETarih.after(emeklilikTarihi)){
				emeklilikTarihi = hizmetETarih;
			}
		}

		if(form.getKalanHizmetSureniz()>0){
			if(sigBitTar.after(new Date()))
				hizmetETarih = GetTarih.tarihinUstuneYilAyGunEkle(new Integer[]{0,0,form.getKalanHizmetSureniz()}, sigBitTar);
			else
				hizmetETarih = GetTarih.tarihinUstuneYilAyGunEkle(new Integer[]{0,0,form.getKalanHizmetSureniz()}, GetTarih.getBugununTarihi());
			if(hizmetETarih.after(emeklilikTarihi)){
				emeklilikTarihi = hizmetETarih;
			}
		}

		boolean eytKanunTarihi_EmeklilikTarihiOlarakUygulandi = false;
		if(form.getEmeklilikSartlari().isEytUygulandi()) {
			if(form.getEmeklilikSartlari().getEytTip()!=null && form.getEmeklilikSartlari().getEytTip().compareTo(Sabit.EYT_TIP1)==0 &&
				form.getEmeklilikSartlari().getYas_eytOncesi()!=null && form.getEmeklilikSartlari().getYas_eytOncesi()>0){
				Date yasETarih2 = GetTarih.tarihinUstuneYilAyGunEkle(new Integer[]{form.getEmeklilikSartlari().getYas_eytOncesi(),0,0}, GetTarih.convertStringToDate(emeklilikBilgileriForm.getDogumTarihi(),null));
				if(yasETarih2.after(emeklilikTarihi) && emeklilikTarihi.before(GetTarih.convertStringToDate(Sabit.TARIH_03_03_2023, null))){
					emeklilikTarihi = GetTarih.convertStringToDate(Sabit.TARIH_03_03_2023, null);
					eytKanunTarihi_EmeklilikTarihiOlarakUygulandi = true;
				}
			} 
		}
		
		if(emeklilikBilgileriForm.getBakMuhCoc()== true && emeklilikBilgileriForm.getCinsiyet().equals(Sabit.CINSIYET_KADIN)){
			if(!eytKanunTarihi_EmeklilikTarihiOlarakUygulandi) {
				emeklilikTarihi = GetTarih.tarihinUstuneYilAyGunCikart(new Integer[]{0,0,(Integer.valueOf(emeklilikBilgileriForm.getBakGunSayisi())/4)}, emeklilikTarihi);
			}
		}
		if(emeklilikTarihi.before(sigBitTar))
			emeklilikTarihi = sigBitTar;
		
		if(emeklilikTarihi.equals(sigBitTar)){  // sigBitTar emeklilik tarihi ise emeklilik tarihi 1 gün sonrayı hesaplıyoruz..
			emeklilikTarihi = GetTarih.tarihinUstuneYilAyGunEkle(new Integer[]{0,0,1}, sigBitTar);
		}

		form.setEmeklilikTarihi(GetTarih.convertDateToString(emeklilikTarihi));
		
	}

	public void bakimaMuhtacCocukHizmetiDus(HakKazanmaSonucForm form, EmeklilikBilgileriForm emeklilikBilgileriForm){
		if(emeklilikBilgileriForm.getCinsiyet().equals(Sabit.CINSIYET_KADIN)){
			form.setKalanYasiniz(form.getKalanYasiniz()- Integer.valueOf(emeklilikBilgileriForm.getBakGunSayisi())/4);
			form.setKalanSigortalilikSureniz(form.getKalanSigortalilikSureniz() - Integer.valueOf(emeklilikBilgileriForm.getBakGunSayisi())/4 );
			form.setKalanHizmetSureniz(form.getKalanHizmetSureniz() - Integer.valueOf(emeklilikBilgileriForm.getBakGunSayisi())/4);
			form.setDusulenSure(Integer.valueOf(emeklilikBilgileriForm.getBakGunSayisi())/4);
		}
	}

}
