package tr.gov.sgk.emektarWeb.emeklilikHakKazanma.action;

import java.net.InetAddress;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm.EmeklilikBilgileriForm;
import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm.HizmetBilgileriForm;
import tr.gov.sgk.emektarWeb.genel.util.Arac;
import tr.gov.sgk.emektarWeb.genel.util.KarakterKontrolleri;
import tr.gov.sgk.emektarWeb.genel.util.Sabit;
import tr.gov.sgk.emektarWeb.genel.util.SabitLokal;

public class EmeklilikBilgileriAction extends Action {

	private static final Logger log = LoggerFactory.getLogger(EmeklilikBilgileriAction.class);

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
			    		
		EmeklilikBilgileriForm emeklilikBilgileriForm = (EmeklilikBilgileriForm)form;
		
		request.getSession().setAttribute(Sabit.SESSION_EMEKLILIKBILGILERI, emeklilikBilgileriForm);
		ArrayList<HizmetBilgileriForm> hizmetList = new ArrayList<HizmetBilgileriForm>();
		
		request.getSession().setAttribute(Sabit.SESSION_HIZMETLISTESI, hizmetList);
 
    //  InetAddress thisIp = InetAddress.getLocalHost(); 
        String thisIp = Arac.getClientIpAddress((HttpServletRequest)request);
        
        log.info("EMEKTARWEB >> ORTAM   : " + KarakterKontrolleri.KarakterKontrolleriYarat(100, true).getGuvenlikKontrolLog2(SabitLokal.ortam));
        log.warn("EMEKTARWEB >> VERSION : " + KarakterKontrolleri.KarakterKontrolleriYarat(100, true).getGuvenlikKontrolLog2(SabitLokal.version));
        log.error("EMEKTARWEB >> IP      : " + KarakterKontrolleri.KarakterKontrolleriYarat(100, true).getGuvenlikKontrolLog2(thisIp));
        
  //    System.out.println("EMEKTARWEB >> IP: " + thisIp.getHostAddress());
  //    System.out.println("EMEKTARWEB >> RemAdr: " + request.getRemoteAddr());
  //    System.out.println("EMEKTARWEB >> Host: " + request.getRemoteHost());
        
  //  	new IstatistikServise().veriTabaniTest();
    	
		return mapping.findForward(Sabit.SUCCESS); 
	}
		
}