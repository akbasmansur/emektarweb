<table width="100%" border="0" cellspacing="0" cellpadding="0" height="23" bgcolor="#333333" style="margin-top:1px;">
  <tr> 
    <td align="center" class="footerText">Sosyal G�venlik Kurumu &copy; 2010</td>
  </tr>
</table>