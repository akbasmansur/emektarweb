package tr.gov.sgk.emektarWeb.emeklilikHakKazanma.business;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import tr.gov.sgk.emektarWeb.genel.util.GetTarih;
import tr.gov.sgk.emektarWeb.genel.util.Sabit;
import tr.gov.sgk.emektarWeb.genel.util.SabitLokal;

public class EmeklilikSartlari {
	
	private static final Logger log = LoggerFactory.getLogger(EmeklilikSartlari.class);
	
	private Integer yas;
	private Integer yas_eyt;
	private Integer yas_eytOncesi;
	private Integer hizmetSuresi;
	private Integer sigortalilikSuresi;
	private Integer eytTip;
	private boolean eytKapsamindaMi;
	private boolean eytUygulandi;


	public EmeklilikSartlari(String cinsiyet, Integer kanunOncesiHizmet, String emeklilikTuru, Date sigBasTar, Date sigBitTar, Integer yasi_01101999_Gun, Integer maluliyetVarmi, String maluliyetDerecesi, Integer erkenYaslanmaVarmi, Boolean ilkGercekHizmetMi, String dogumTarihi){

		Date tarih_08_09_1999 = GetTarih.convertStringToDate(Sabit.TARIH_08_09_1999,"");
		Date tarih_01_05_2008 = GetTarih.convertStringToDate(Sabit.TARIH_01_05_2008,"");

		if(maluliyetVarmi.equals(Sabit.HAYIR)){
			if(emeklilikTuru.equals(Sabit.EMEKLILIKTURU_TAM)){
				//if(sigBasTar.before(tarih_08_09_1999) && ilkGercekHizmetMi){
				if(sigBasTar.compareTo(tarih_08_09_1999)<=0 && ilkGercekHizmetMi){
					if(cinsiyet.equals(Sabit.CINSIYET_ERKEK)){
						hizmetSuresi = Sabit.HIZMET_25_YIL;
					} else {
						hizmetSuresi = Sabit.HIZMET_20_YIL;
					}
					if(hizmetSuresi - kanunOncesiHizmet>720){
						Integer kalanHizmet = hizmetSuresi - kanunOncesiHizmet;
						tamEmeklilikGecis4447(kalanHizmet, cinsiyet);
						if(cinsiyet.equals(Sabit.CINSIYET_ERKEK) && yas.compareTo(58)>0){
							yas=58;
						}
						if(cinsiyet.equals(Sabit.CINSIYET_KADIN) && yas.compareTo(56)>0){
							yas=56;
						}
					}else{
						yas=0; //TODO yaşa bugünkü yaşı atanmalı mı?
					}
					//if(SabitLokal.ortam.compareTo(Sabit.ortamTest)==0) { //TODO 1.EYT_XXX yasa cikinca ve testler bitince kaldirilacak!!! 
						if(yas>0) { //1.EYT 22.02.2023
							if(!erkenYaslanmaVarmi.equals(Sabit.EVET)) {
								Date yasTarih = GetTarih.tarihinUstuneYilAyGunEkle(new Integer[]{yas,0,0}, GetTarih.convertStringToDate(dogumTarihi,null));
								if(yasTarih.compareTo(GetTarih.convertStringToDate(Sabit.TARIH_03_03_2023, null))>=0){
									yas_eyt = 0;
									yas_eytOncesi = yas;
									eytKapsamindaMi = true;
									eytTip = Sabit.EYT_TIP1;
								}
							}
						}
					//}

				} else if(sigBasTar.before(tarih_01_05_2008)){
					hizmetSuresi = Sabit.HIZMET_25_YIL;
					if(cinsiyet.equals(Sabit.CINSIYET_ERKEK)) 
						yas = 60;
					else 
						yas = 58;
				}
				else {
					hizmetSuresi = Sabit.HIZMET_25_YIL;
					if(cinsiyet.equals(Sabit.CINSIYET_ERKEK)) 
						yas = 60;
					else 
						yas = 58;
					tamEmeklilikGecis5510(sigBitTar, cinsiyet);
				}
			}
			if(emeklilikTuru.equals(Sabit.EMEKLILIKTURU_KISMI)){
				if(sigBasTar.before(tarih_08_09_1999) && ilkGercekHizmetMi){
					hizmetSuresi = Sabit.HIZMET_15_YIL;
					if(cinsiyet.equals(Sabit.CINSIYET_ERKEK)) 
						yas = 55;
					else 
						yas = 50;

					//if(hizmetSuresi - kanunOncesiHizmet>720){
					if(yas>0){
						Integer kalanHizmet = hizmetSuresi - kanunOncesiHizmet;
						kismiEmeklilikGecis4447(kalanHizmet, cinsiyet, yasi_01101999_Gun);
					}else{
						yas=0; //TODO yaşa bugünkü yaşı atanmalı mı?
					}

				} else if(sigBasTar.before(tarih_01_05_2008)){
					hizmetSuresi = Sabit.HIZMET_15_YIL;
					if(cinsiyet.equals(Sabit.CINSIYET_ERKEK)) 
						yas = 62;
					else 
						yas = 60;
				}
				else {
					hizmetSuresi = Sabit.HIZMET_15_YIL;
					if(cinsiyet.equals(Sabit.CINSIYET_ERKEK)) 
						yas = 62;
					else 
						yas = 60;
					kismiEmeklilikGecis5510(sigBitTar, cinsiyet);
				}
			}
			sigortalilikSuresi = hizmetSuresi;
		} else if(maluliyetVarmi.equals(Sabit.EVET)) {
			if(maluliyetDerecesi.equals(Sabit.MALULIYET_40_49)){
				sigortalilikSuresi = 18*360;
				hizmetSuresi=4680;
			} else if(maluliyetDerecesi.equals(Sabit.MALULIYET_50_59)){
				sigortalilikSuresi=16*360;
				hizmetSuresi= 4320;
			} else {
				sigortalilikSuresi= 15*360;
				hizmetSuresi = 3960;
			}
			yas =0;
		}

		if(erkenYaslanmaVarmi.equals(Sabit.EVET)){
			if(yas>55) yas = 55;
			hizmetSuresi = Sabit.HIZMET_15_YIL;
			sigortalilikSuresi = hizmetSuresi;
		}
	}

	private void tamEmeklilikGecis4447(Integer kalanHizmet, String cinsiyet){

		if(cinsiyet.equals(Sabit.CINSIYET_KADIN)) {
			//			TODO : birinci koşul sorulacak...
			if(kalanHizmet<=720 )                     yas=40 ;	//2  yil ve az
			if(kalanHizmet>720  && kalanHizmet<=1080) yas=41 ;	//2  yildan fazla ve  3 yil tamdan az 
			if(kalanHizmet>1080 && kalanHizmet<=1440) yas=42 ;	//3  yildan fazla ve  4 yil tamdan az 
			if(kalanHizmet>1440 && kalanHizmet<=1800) yas=43 ;	//4  yildan fazla ve  5 yil tamdan az
			if(kalanHizmet>1800 && kalanHizmet<=2160) yas=44 ;	//5  yildan fazla ve  6 yil tamdan az
			if(kalanHizmet>2160 && kalanHizmet<=2520) yas=45 ;	//6  yildan fazla ve  7 yil tamdan az
			if(kalanHizmet>2520 && kalanHizmet<=2880) yas=46 ;	//7  yildan fazla ve  8 yil tamdan az
			if(kalanHizmet>2880 && kalanHizmet<=3240) yas=47 ;	//8  yildan fazla ve  9 yil tamdan az
			if(kalanHizmet>3240 && kalanHizmet<=3600) yas=48 ;	//9  yildan fazla ve  10 yil tamdan az
			if(kalanHizmet>3600 && kalanHizmet<=3960) yas=49 ;	//10 yildan fazla ve  11 yil tamdan az
			if(kalanHizmet>3960 && kalanHizmet<=4320) yas=50 ;	//11 yildan fazla ve  12 yil tamdan az
			if(kalanHizmet>4320 && kalanHizmet<=4680) yas=51 ;	//12 yildan fazla ve  13 yil tamdan az
			if(kalanHizmet>4680 && kalanHizmet<=5040) yas=52 ;	//13 yildan fazla ve  14 yil tamdan az
			if(kalanHizmet>5040 && kalanHizmet<=5400) yas=53 ;	//14 yildan fazla ve  15 yil tamdan az
			if(kalanHizmet>5400 && kalanHizmet<=5760) yas=54 ;	//15 yildan fazla ve  16 yil tamdan az
			if(kalanHizmet>5760 && kalanHizmet<=6120) yas=55 ;	//16 yildan fazla ve  17 yil tamdan az
			if(kalanHizmet>6120) 				      yas=58 ;	//17 yildan fazla 
		}else{//ERKEK
			if(kalanHizmet<=720 )                     yas=44 ;	//2  yil ve daha  az
			if(kalanHizmet>720  && kalanHizmet<=1260) yas=45 ;	//2  yildan fazla ve    3  yil 6 ay tamdan az 
			if(kalanHizmet>1260 && kalanHizmet<=1800) yas=46 ;	//3  yil 6 aydan fazla  5  yil tamdan az 
			if(kalanHizmet>1800 && kalanHizmet<=2340) yas=47 ;	//5  yildan fazla ve    6  yil 6 ay tamdan az 
			if(kalanHizmet>2340 && kalanHizmet<=2880) yas=48 ;	//6  yil 6 aydan fazla ve 8 yil tamdan az 
			if(kalanHizmet>2880 && kalanHizmet<=3420) yas=49 ;	//8  yildan fazla ve    9  yil 6 ay tamdan az 
			if(kalanHizmet>3420 && kalanHizmet<=3960) yas=50 ;	//9  yil 6 aydan fazla ve 11 yil tamdan az 
			if(kalanHizmet>3960 && kalanHizmet<=4500) yas=51 ;	//11 yildan fazla ve    12 yil 6 ay tamdan az 
			if(kalanHizmet>4500 && kalanHizmet<=5040) yas=52 ;	//12 yil 6 aydan fazla ve 14 yil tamdan az 
			if(kalanHizmet>5040 && kalanHizmet<=5580) yas=53 ;	//14 yildan fazla ve    15 yil 6 ay tamdan az 
			if(kalanHizmet>5580 && kalanHizmet<=6120) yas=54 ;	//15 yil 6 aydan fazla ve 17 yil tamdan az 
			if(kalanHizmet>6120 && kalanHizmet<=6660) yas=55 ;	//17 yildan fazla ve    18 yil 6 ay tamdan az 
			if(kalanHizmet>6660 && kalanHizmet<=7200) yas=56 ;	//18 yil 6 aydan fazla ve 20 yil tamdan az 
			if(kalanHizmet>7200 && kalanHizmet<=7740) yas=57 ;	//20 yildan fazla ve    21 yil 6 ay tamdan az 
			if(kalanHizmet>7740 && kalanHizmet<=7920) yas=58 ;	//21 yil 6 aydan fazla ve 22 yil tamdan az 
			if(kalanHizmet>7920)				      yas=60 ;	//22 yildan fazla  
		}
	}

	private void kismiEmeklilikGecis4447(Integer kalanHizmet, String cinsiyet, Integer yasi_01101999_Gun){

		int kalanYas = cinsiyet.equals(Sabit.CINSIYET_KADIN) ? 18000-yasi_01101999_Gun : 19800-yasi_01101999_Gun ; //01.10.1999 de,50-55 yasini doldurmaya kalan süre
		int kalanSure = kalanHizmet>kalanYas ? kalanHizmet : kalanYas ;

		//	TODO : birinci koşul sorulacak...			

		if(kalanSure<=720)                    yas=0; 
	  //if(kalanSure<=720)                    yas=cinsiyet.equals(Sabit.CINSIYET_KADIN) ? 50 : 55 ;	//2  yil ve az
		if(kalanSure>720  && kalanSure<=1440) yas=cinsiyet.equals(Sabit.CINSIYET_KADIN) ? 51 : 56 ;	//2  yildan fazla ve  4 yil tamdan az 
		if(kalanSure>1440 && kalanSure<=2160) yas=cinsiyet.equals(Sabit.CINSIYET_KADIN) ? 52 : 56 ;	//4  yildan fazla ve  6 yil tamdan az
		if(kalanSure>2160 && kalanSure<=2880) yas=cinsiyet.equals(Sabit.CINSIYET_KADIN) ? 53 : 57 ;	//6  yildan fazla ve  8 yil tamdan az
		if(kalanSure>2880 && kalanSure<=3600) yas=cinsiyet.equals(Sabit.CINSIYET_KADIN) ? 54 : 57 ;	//8  yildan fazla ve  10 yil tamdan az
		if(kalanSure>3600) 				      yas=cinsiyet.equals(Sabit.CINSIYET_KADIN) ? 56 : 58 ;	//10  yildan fazla

	}
	private void tamEmeklilikGecis5510(Date sigBitTar, String cinsiyet){

		Date tarih_01_01_2036 = GetTarih.convertStringToDate("01/01/2036","");
		Date tarih_01_01_2038 = GetTarih.convertStringToDate("01/01/2038","");
		Date tarih_01_01_2040 = GetTarih.convertStringToDate("01/01/2040","");
		Date tarih_01_01_2042 = GetTarih.convertStringToDate("01/01/2042","");
		Date tarih_01_01_2044 = GetTarih.convertStringToDate("01/01/2044","");
		Date tarih_01_01_2046 = GetTarih.convertStringToDate("01/01/2046","");
		Date tarih_01_01_2048 = GetTarih.convertStringToDate("01/01/2048","");
		Date tarih_31_12_2047 = GetTarih.convertStringToDate("31/12/2047","");

		if(sigBitTar.before(tarih_01_01_2036))
			yas = cinsiyet.equals(Sabit.CINSIYET_ERKEK) ? 60 : 58;
		else if(sigBitTar.before(tarih_01_01_2038))
			yas = cinsiyet.equals(Sabit.CINSIYET_ERKEK) ? 61 : 59;
		else if(sigBitTar.before(tarih_01_01_2040))
			yas = cinsiyet.equals(Sabit.CINSIYET_ERKEK) ? 62 : 60;
		else if(sigBitTar.before(tarih_01_01_2042))
			yas = cinsiyet.equals(Sabit.CINSIYET_ERKEK) ? 63 : 61;
		else if(sigBitTar.before(tarih_01_01_2044))
			yas = cinsiyet.equals(Sabit.CINSIYET_ERKEK) ? 64 : 62;
		else if(sigBitTar.before(tarih_01_01_2046))
			yas = cinsiyet.equals(Sabit.CINSIYET_ERKEK) ? 65 : 63;
		else if(sigBitTar.before(tarih_01_01_2048))
			yas = cinsiyet.equals(Sabit.CINSIYET_ERKEK) ? 65 : 64;
		else if(sigBitTar.after(tarih_31_12_2047))
			yas = 65;
	}

	private void kismiEmeklilikGecis5510(Date sigBitTar, String cinsiyet){

		Date tarih_01_01_2036 = GetTarih.convertStringToDate("01/01/2036","");
		Date tarih_01_01_2038 = GetTarih.convertStringToDate("01/01/2038","");
		Date tarih_01_01_2040 = GetTarih.convertStringToDate("01/01/2040","");
		Date tarih_01_01_2042 = GetTarih.convertStringToDate("01/01/2042","");
		Date tarih_01_01_2044 = GetTarih.convertStringToDate("01/01/2044","");
		Date tarih_01_01_2046 = GetTarih.convertStringToDate("01/01/2046","");
		Date tarih_01_01_2048 = GetTarih.convertStringToDate("01/01/2048","");
		Date tarih_31_12_2047 = GetTarih.convertStringToDate("31/12/2047","");

		if(sigBitTar.before(tarih_01_01_2036))
			yas = cinsiyet.equals(Sabit.CINSIYET_ERKEK) ? 63 : 61;
		else if(sigBitTar.before(tarih_01_01_2038))
			yas = cinsiyet.equals(Sabit.CINSIYET_ERKEK) ? 64 : 62;
		else if(sigBitTar.before(tarih_01_01_2040))
			yas = cinsiyet.equals(Sabit.CINSIYET_ERKEK) ? 65 : 63;
		else if(sigBitTar.before(tarih_01_01_2042))
			yas = cinsiyet.equals(Sabit.CINSIYET_ERKEK) ? 65 : 64;
		else if(sigBitTar.before(tarih_01_01_2044))
			yas = cinsiyet.equals(Sabit.CINSIYET_ERKEK) ? 65 : 65;
		else if(sigBitTar.before(tarih_01_01_2046))
			yas = cinsiyet.equals(Sabit.CINSIYET_ERKEK) ? 65 : 65;
		else if(sigBitTar.before(tarih_01_01_2048))
			yas = cinsiyet.equals(Sabit.CINSIYET_ERKEK) ? 65 : 65;
		else if(sigBitTar.after(tarih_31_12_2047))
			yas = 65;
	}

	public Integer getYas() {
		return yas;
	}

	public void setYas(Integer yas) {
		this.yas = yas;
	}

	public Integer getHizmetSuresi() {
		return hizmetSuresi;
	}

	public void setHizmetSuresi(Integer hizmetSuresi) {
		this.hizmetSuresi = hizmetSuresi;
	}

	public Integer getSigortalilikSuresi() {
		return sigortalilikSuresi;
	}

	public void setSigortalilikSuresi(Integer sigortalilikSuresi) {
		this.sigortalilikSuresi = sigortalilikSuresi;
	}

	public Integer getYas_eyt() {
		return yas_eyt;
	}

	public void setYas_eyt(Integer yas_eyt) {
		this.yas_eyt = yas_eyt;
	}

	public Integer getYas_eytOncesi() {
		return yas_eytOncesi;
	}

	public void setYas_eytOncesi(Integer yas_eytOncesi) {
		this.yas_eytOncesi = yas_eytOncesi;
	}

	public boolean isEytKapsamindaMi() {
		return eytKapsamindaMi;
	}

	public void setEytKapsamindaMi(boolean eytKapsamindaMi) {
		this.eytKapsamindaMi = eytKapsamindaMi;
	}

	public boolean isEytUygulandi() {
		return eytUygulandi;
	}

	public void setEytUygulandi(boolean eytUygulandi) {
		this.eytUygulandi = eytUygulandi;
	}

	public Integer getEytTip() {
		return eytTip;
	}

	public void setEytTip(Integer eytTip) {
		this.eytTip = eytTip;
	}

	public String getYasString() {
		return String.valueOf(yas) + " yıl ";
	}
	
	public String getYasEytString() {
		String eytString = "";
		if(eytUygulandi && yas_eytOncesi!=null && yas_eytOncesi>0) {
			eytString ="(EYT \u00f6ncesi ya\u015f \u015fart\u0131:" +String.valueOf(yas_eytOncesi).trim() + ")"; 
		}
		return eytString;
	}


	public String getHizmetSuresiString() {
		return String.valueOf(hizmetSuresi) +" gün ";
	}
	public String getSigortalilikSuresiString() {
		return String.valueOf(sigortalilikSuresi) + " gün ";
	}
	public String getSigortalilikSuresiYil(){
		return sigortalilikSuresi/360 + " yıl ";
	}
	public String getSigortalilikSuresiAy(){
		return (sigortalilikSuresi % 360 > 0 ? (sigortalilikSuresi % 360)/30 : 0 ) + " ay " ;
	}
	public String getSigortalilikSuresiGun(){
		return (sigortalilikSuresi % 360) % 30 + " gün ";
	}

}
