package tr.gov.sgk.emektarWeb.genel.taglib;


import java.util.Date;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;

import org.apache.struts.taglib.html.BaseInputTag;
import org.apache.struts.taglib.html.Constants;
import org.apache.struts.taglib.tiles.util.TagUtils;

import tr.gov.sgk.emektarWeb.genel.decorator.DateDecorator;

public class IntegerTag extends BaseInputTag {

	private static final long serialVersionUID = 1L;

	private String property = null;

	private String size = null;

	private String onblur = null;

	private String onkeydown = null;

	private String onkeyup = null;
	private String readOnly = null;

	private String maxlength=null;
	
	public String getReadOnly() {
		return readOnly;
	}

	public void setReadOnly(String readOnly) {
		this.readOnly = readOnly;
	}

	public String getMaxlength() {
		return maxlength;
	}

	public void setMaxlength(String maxlength) {
		this.maxlength = maxlength;
	}

	public String getOnblur() {
		return onblur;
	}

	public void setOnblur(String onblur) {
		this.onblur = onblur;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	private String getHtml() {

		String html = "";
		html += "<input type=\"hidden\" id=\"" + property + "\" name=\"" + property + "\" value= \""+getPropertyValue(property)+"\" />";
		html += "<input class=\"metinSayisal\" type=\"text\" id=\"" + property + "_f\" name=\"" + property + "_f\" value= \""+getPropertyValue(property)+"\" ";
		html += " onkeypress=\"return integerDenetimi(this.value);\" ";
		html+=" onchange=\"this.value=integerFormatla(this.value);this.form."+property+".value = this.form."+property+"_f.value;\"  ";


		if (onblur != null && !"".equals(onblur))
			html += " onblur=\"" + onblur + "\" ";
		if (onkeydown != null && !"".equals(onkeydown))
			html += " onkeydown =\"" + onkeydown + "\" ";
		if (onkeyup != null && !"".equals(onkeyup))
			html += " onkeyup =\"" + onkeyup + "\" ";
		if (size != null && !"".equals(size))
			html += " size=\"" + size + "\" id=\"" + id + "\" ";
		if (readOnly != null && !"".equals(readOnly))
			html += " readOnly=\"" + readOnly + "\" ";
		if (fieldDolumu(getMaxlength())) 
			html += " maxlength=\"" + getMaxlength() + "\" ";
		html += ">";

		return html;
	}

	public boolean fieldDolumu(Object field) {
		return (field!=null && !"".equals(field));
	}
		
	public String getPropertyValue(String property) {
		Object value = null;
		if (property != null) {
			try {
				value = TagUtils.getRealValueFromBean(Constants.BEAN_KEY, property, null, pageContext);
			} catch (Exception ex) {
				value = "";
			}
		}
		if (value == null) {
			return "";
		} else if (value instanceof Date) {
			return DateDecorator.formatDate(value);
		} else {
			return value.toString();
		}
	}
	
	
	public int doStartTag() throws JspException {

		try {
			JspWriter out = pageContext.getOut();

			out.print(getHtml());
		} catch (Exception ex) {
			throw new JspException(ex.getMessage());
		} finally {
			this.release();
		}
		return SKIP_BODY;
	}

	public void release() {
		super.release();
		property = null;
		size = null;
		onblur = null;
		onkeyup = null;
		onkeydown = null;
	}

	public String getOnkeydown() {
		return onkeydown;
	}

	public void setOnkeydown(String onkeydown) {
		this.onkeydown = onkeydown;
	}

	public String getOnkeyup() {
		return onkeyup;
	}

	public void setOnkeyup(String onkeyup) {
		this.onkeyup = onkeyup;
	}

	

}
