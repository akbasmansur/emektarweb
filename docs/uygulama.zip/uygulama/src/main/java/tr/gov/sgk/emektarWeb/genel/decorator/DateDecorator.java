/**
 * 
 */
package tr.gov.sgk.emektarWeb.genel.decorator;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.jsp.PageContext;

import org.displaytag.decorator.DisplaytagColumnDecorator;
import org.displaytag.exception.DecoratorException;
import org.displaytag.properties.MediaTypeEnum;

import tr.gov.sgk.emektarWeb.genel.util.Sabit;


public class DateDecorator implements DisplaytagColumnDecorator
{
    /**
     * SimpleDateFormat used to format the date object.
     */
    private SimpleDateFormat dateFormat = Sabit.dateFormat;

	/* (non-Javadoc)
	 * @see org.displaytag.decorator.DisplaytagColumnDecorator#decorate(java.lang.Object, javax.servlet.jsp.PageContext, org.displaytag.properties.MediaTypeEnum)
	 */
	public Object decorate(Object columnValue, PageContext pageContext, MediaTypeEnum media) throws DecoratorException {
		
		try {
			if( columnValue != null){	
				Date date = (Date) columnValue;
			    return this.dateFormat.format(date);
			}
				return "";
		} 
		catch (Exception e) {
			
		//	e.printStackTrace();
		}
		return null;
        	
	}

	public static String getToday(){
		SimpleDateFormat dateFormat = Sabit.dateFormat;
		Date date = new Date();
		return dateFormat.format(date);
	}
	
	public static String formatDate(Object columnValue){
		String result="";
		if (columnValue != null) {
			SimpleDateFormat dateFormat = Sabit.dateFormat;
			Date date = (Date) columnValue;
			result=dateFormat.format(date);
		}
		
		return result;
	}
	
}
