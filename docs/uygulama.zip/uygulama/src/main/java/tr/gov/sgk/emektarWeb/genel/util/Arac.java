package tr.gov.sgk.emektarWeb.genel.util;

import java.math.BigDecimal;
import java.text.Collator;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.PageContext;


import org.apache.struts.config.ConfigHelper;
import org.apache.struts.util.MessageResources;




public class Arac {
	/**
	 * Logger for this class
	 */
	

	private static Hashtable yereller = new Hashtable();
	static {
		yereller.put(Sabit.YEREL_TR, new Locale("tr", "TR"));
		yereller.put(Sabit.YEREL_EN, new Locale("en", "US"));
		yereller.put("default", yereller.get(Sabit.YEREL_TR));
	}

	public static Locale getYerel(String yerelAdi) {
		Locale val = (Locale) yereller.get(yerelAdi);
		if (val == null) {
			val = (Locale) yereller.get("default");
		}
		return val;
	}

	private static String messagesPath = "tr.gov.sgk.emektarWeb.genel.resource";
	private static String defaultMessagesFile = "tr.gov.sgk.emektarWeb.genel.resource.Mesajlar";

	public static String getMessageResourcesConfig(HttpServletRequest request) {

		ConfigHelper configHelper = new ConfigHelper(request.getSession()
				.getServletContext(), request, null);
		MessageResources mr = (MessageResources) configHelper
				.getMessageResources();

		return mr.getConfig();

	}

	public static ResourceBundle getResourceBundle(Locale locale) {
		ResourceBundle bundle = null;
		try {
			if (locale != null) {
				bundle = ResourceBundle.getBundle(defaultMessagesFile, locale);
			} else {
				bundle = ResourceBundle.getBundle(defaultMessagesFile, Arac
						.getYerel(Sabit.YEREL_TR));
			}
		} catch (Exception e) {
			//e.printStackTrace();
		}
		return bundle;
	}

	public static ResourceBundle getResourceBundle(HttpServletRequest request) {

		ResourceBundle bundle = null;
		String fileName = getMessageResourcesConfig(request);

		if (fileName != null) {

			try {
				bundle = ResourceBundle
						.getBundle(fileName, request.getLocale());
			} catch (Exception e) {
				try {
					bundle = ResourceBundle.getBundle(fileName);
				} catch (Exception ex) {
					try {
						bundle = ResourceBundle.getBundle(defaultMessagesFile,
								request.getLocale());
					} catch (Exception exp) {
						bundle = ResourceBundle.getBundle(defaultMessagesFile);
					}
				}
			}
		} else {
			try {
				bundle = ResourceBundle.getBundle(defaultMessagesFile, request
						.getLocale());
			} catch (Exception exp) {
				bundle = ResourceBundle.getBundle(defaultMessagesFile);
			}
		}

		return bundle;
	}

	public static ResourceBundle getResourceBundle(HttpServletRequest request,
			String resourceName) {

		ResourceBundle bundle = null;
		try {
			bundle = ResourceBundle.getBundle(
					messagesPath + "." + resourceName, request.getLocale());
		} catch (Exception e) {
			try {
				bundle = ResourceBundle.getBundle(messagesPath + "."
						+ resourceName);
			} catch (Exception ex) {
				bundle = getResourceBundle(request);
			}
		}

		return bundle;
	}

	public static String getBundleValue(ResourceBundle bundle, String key) {

		String value = key;
		if (bundle != null) {
			try {
				value = bundle.getString(key);
			} catch (Exception e) {
				return value;
			}
		}
		return value;
	}

	private static Comparator comparator = Collator.getInstance(new Locale(
			"tr", "TR"));

	public static String pageContextGetMessageKey(PageContext pageContext,
			String deger) {
		String sonuc = deger;
		if (deger != null && !"".equals(deger)) {
			try {
				sonuc = ((org.apache.struts.util.PropertyMessageResources) pageContext
						.getServletContext().getAttribute(
								"org.apache.struts.action.MESSAGE"))
						.getMessage(deger);
			} catch (Exception ex) {
			}
		}
		if (sonuc == null) {
			return deger;
		}
		return sonuc;
	}

	// null ya da default değer değilse true döner
	public static boolean checkValueForObject(Object value, Integer type) {

	
		switch (type) {
		case 1:// Integer
			if (((Integer) value) != null
					&& !((Integer) value).equals(Sabit.DEFAULT_INT))
				return true;
			break;
		case 2:// String
			if (((String) value) != null
					&& !(((String) value)).trim().equals(Sabit.DEFAULT_STRING))
				return true;
			break;
		case 3:// Long
			if (((Long) value) != null
					&& !((Long) value).equals(Sabit.DEFAULT_LONG))
				return true;
			break;
		case 4:// BigDecimal
			if (((BigDecimal) value) != null
					&& !((BigDecimal) value).equals(Sabit.DEFAULT_BIGDECIMAL))
				return true;
			break;
		case 5:// Date
			if (((String) value) != null
					&& !((String) value).equals(Sabit.DEFAULT_DATE))
				return true;
			break;
		case 6:// Double
			if (((Double) value) != null
					&& !((Double) value).equals(Sabit.DEFAULT_DOUBLE))
				return true;
			break;
		case 7:// Class
			if (value != null)
				return true;
			break;
		}
		return false;
	}



	// sadece gun ay yil olarak iki tarihi karsilastiriri
	// birinci buyukse 1
	// esitse 0
	// ikinci buyukse -1 doner
	public static int gunAyYilKarsilastir(Date dt1, Date dt2) {
		Calendar cal1 = GregorianCalendar.getInstance();
		Calendar cal2 = GregorianCalendar.getInstance();
		cal1.setTime(dt1);
		cal2.setTime(dt2);
		if (cal1.get(GregorianCalendar.YEAR) > cal2.get(GregorianCalendar.YEAR)) {
			return 1;
		}
		if (cal1.get(GregorianCalendar.YEAR) < cal2.get(GregorianCalendar.YEAR)) {
			return -1;
		}
		if (cal1.get(GregorianCalendar.YEAR) == cal2
				.get(GregorianCalendar.YEAR)) {

			if (cal1.get(GregorianCalendar.MONTH) > cal2
					.get(GregorianCalendar.MONTH)) {
				return 1;
			}
			if (cal1.get(GregorianCalendar.MONTH) < cal2
					.get(GregorianCalendar.MONTH)) {
				return -1;
			}
			if (cal1.get(GregorianCalendar.MONTH) == cal2
					.get(GregorianCalendar.MONTH)) {

				if (cal1.get(GregorianCalendar.DATE) > cal2
						.get(GregorianCalendar.DATE)) {
					return 1;
				}
				if (cal1.get(GregorianCalendar.DATE) < cal2
						.get(GregorianCalendar.DATE)) {
					return -1;
				}
				if (cal1.get(GregorianCalendar.DATE) == cal2
						.get(GregorianCalendar.DATE)) {
					return 0;

				}

			}
		}
		return 0;
	}
	
	private static final String[] HEADERS_TO_TRY = { 
			"X-Forwarded-For",
		    "Proxy-Client-IP",
		    "WL-Proxy-Client-IP",
		    "HTTP_X_FORWARDED_FOR",
		    "HTTP_X_FORWARDED",
		    "HTTP_X_CLUSTER_CLIENT_IP",
		    "HTTP_CLIENT_IP",
		    "HTTP_FORWARDED_FOR",
		    "HTTP_FORWARDED",
		    "HTTP_VIA",
		    "REMOTE_ADDR" };

	public static String getClientIpAddress(HttpServletRequest request) {
		for (String header : HEADERS_TO_TRY) {
			String ip = request.getHeader(header);
		//	System.out.println(header +":"+ip);
			if (ip != null && ip.length() != 0 && !"unknown".equalsIgnoreCase(ip)) {
				return ip;
			}
		}
		return request.getRemoteAddr();
	}

}