package tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm;

import org.apache.struts.action.ActionForm;

import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.business.EmeklilikSartlari;

public class HakKazanmaSonucForm extends ActionForm{
	
	private static final long serialVersionUID = -2051264169167825744L;
	private Integer yasiniz;
	private Integer hizmetSureniz;
	private Integer sigortalilikSureniz;
	private EmeklilikSartlari emeklilikSartlari;
	private Integer kalanYasiniz;
	private Integer kalanHizmetSureniz;
	private Integer kalanSigortalilikSureniz;
	private String emeklilikTarihi;
	private Integer dusulenSure; // bakima muhtac cocuk nedeniyle dusulen sure
	
	
	public String getYasinizYil(){
		return yasiniz/360 + " y\u0131l ";
	}
	public String getYasinizAy(){
		return (yasiniz % 360 > 0 ? (yasiniz % 360)/30 : 0 ) + " ay " ;
	}
	public String getYasinizGun(){
		return (yasiniz % 360) % 30 + " g\u00fcn ";
	}
	
	public String getSigortalilikSurenizYil(){
		return sigortalilikSureniz/360 + " y\u0131l ";
	}
	public String getSigortalilikSurenizAy(){
		return (sigortalilikSureniz % 360 > 0 ? (sigortalilikSureniz % 360)/30 : 0 ) + " ay " ;
	}
	public String getSigortalilikSurenizGun(){
		return (sigortalilikSureniz % 360) % 30 + " g\u00fcn ";
	}
	
	public Integer getHizmetSureniz(){
		return hizmetSureniz;
	}
	public String getHizmetSurenizString(){
		return hizmetSureniz + " g\u00fcn ";
	}
	public void setYasiniz(Integer yasiniz) {
		this.yasiniz = yasiniz;
	}
	public void setHizmetSureniz(Integer hizmetSureniz) {
		this.hizmetSureniz = hizmetSureniz;
	}
	public void setSigortalilikSureniz(Integer sigortalilikSureniz) {
		this.sigortalilikSureniz = sigortalilikSureniz;
	}
	public EmeklilikSartlari getEmeklilikSartlari() {
		return emeklilikSartlari;
	}
	public void setEmeklilikSartlari(EmeklilikSartlari emeklilikSartlari) {
		this.emeklilikSartlari = emeklilikSartlari;
	}
	
	public String getKalanYasinizYil(){
		return (kalanYasiniz / 360 > 0 ? (kalanYasiniz / 360) : 0 ) + " y\u0131l " ;
	}
	public String getKalanYasinizAy(){
		return (kalanYasiniz % 360 > 0 ? (kalanYasiniz % 360)/30 : 0 ) + " ay " ;
	}
	public String getKalanYasinizGun(){
		return ((kalanYasiniz % 360) % 30 > 0 ? (kalanYasiniz % 360) % 30 : 0 ) + " g\u00fcn ";
	}
	public String getKalanSigortalilikSurenizYil(){
		return (kalanSigortalilikSureniz / 360 > 0 ? (kalanSigortalilikSureniz / 360) : 0 ) + " y\u0131l " ;
	}
	public String getKalanSigortalilikSurenizAy(){
		return (kalanSigortalilikSureniz % 360 > 0 ? (kalanSigortalilikSureniz % 360)/30 : 0 ) + " ay " ;
	}
	public String getKalanSigortalilikSurenizGun(){
		return ((kalanSigortalilikSureniz % 360) % 30 > 0 ? (kalanSigortalilikSureniz % 360) % 30 : 0) + " g\u00fcn ";
	}
	public String getKalanHizmetSurenizString(){
		if(kalanHizmetSureniz>0)
			return kalanHizmetSureniz + " g\u00fcn ";
		else
			return "0" + " g\u00fcn ";
	}
	public Integer getKalanHizmetSureniz(){
		return kalanHizmetSureniz;
	}
	public void setKalanYasiniz(Integer kalanYasiniz) {
		this.kalanYasiniz = kalanYasiniz;
	}
	public void setKalanHizmetSureniz(Integer kalanHizmetSureniz) {
		this.kalanHizmetSureniz = kalanHizmetSureniz;
	}
	public void setKalanSigortalilikSureniz(Integer kalanSigortalilikSureniz) {
		this.kalanSigortalilikSureniz = kalanSigortalilikSureniz;
	}
	public Integer getYasiniz() {
		return yasiniz;
	}
	public Integer getSigortalilikSureniz() {
		return sigortalilikSureniz;
	}
	public Integer getKalanYasiniz() {
		return kalanYasiniz;
	}
	public Integer getKalanSigortalilikSureniz() {
		return kalanSigortalilikSureniz;
	}
	public String getEmeklilikTarihi() {
		return emeklilikTarihi + " tarihinde emekli olabilirsiniz.";
	}
	public Integer getDusulenSure() {
		return dusulenSure;
	}
	public void setDusulenSure(Integer dusulenSure) {
		this.dusulenSure = dusulenSure;
	}
	public void setEmeklilikTarihi(String emeklilikTarihi) {
		this.emeklilikTarihi = emeklilikTarihi;
	}
}
