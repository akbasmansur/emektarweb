<%@ page language="java" contentType="text/html; charset=UTF-8"%>
<%@taglib prefix="bean" uri="/WEB-INF/config/tld/struts-bean.tld"%>
<%@taglib prefix="display" uri="/WEB-INF/config/tld/displaytag.tld"%>
<%@taglib prefix="tiles" uri="/WEB-INF/config/tld/struts-tiles.tld"%>
<%@taglib prefix="html" uri="/WEB-INF/config/tld/struts-html.tld"%>
<%@taglib prefix="logic" uri="/WEB-INF/config/tld/struts-logic.tld"%>
<%@taglib prefix="nested" uri="/WEB-INF/config/tld/struts-nested.tld"%>
<%@taglib prefix="emektar" uri="/WEB-INF/config/tld/emektar.tld"%>


<logic:redirect forward="welcome"></logic:redirect>


