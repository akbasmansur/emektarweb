
   /*$RCSfile: staticJavascriptField.js,v $ $Revision: 1.1.1.1 $ $Date: 2007/07/18 18:57:54 $ */
    /**
    * Check to see if fields are in a valid float range.
    * Fields are not checked if they are disabled.
    * <p>
    * @param form The form validation is taking place on.
    */
    function validateFieldFloatRange(field, min, max) {
        var isValid = true;

        if ((field.type == 'hidden' ||
            field.type == 'text' || field.type == 'textarea') &&
            (field.value.length > 0)  &&
             field.disabled == false) {
    
            var fMin = parseFloat(pMin);
            var fMax = parseFloat(pMax);
            var fValue = parseFloat(field.value);
            if (!(fValue >= fMin && fValue <= fMax)) {
                isValid = false;
            }
        }

        field.focus();

        return isValid;
    }

    /*$RCSfile: staticJavascriptField.js,v $ $Revision: 1.1.1.1 $ $Date: 2007/07/18 18:57:54 $ */

  /**
  * This is a place holder for common utilities used across the javascript validation
  *
  **/


    /*$RCSfile: staticJavascriptField.js,v $ $Revision: 1.1.1.1 $ $Date: 2007/07/18 18:57:54 $ */
    /**
    * Check to see if fields are a valid byte.
    * Fields are not checked if they are disabled.
    * <p>
    * @param form The form validation is taking place on.
    */
    function validateFieldByte(field) {
        var bValid = true;

        if ((field.type == 'hidden' ||
            field.type == 'text' ||
            field.type == 'textarea' ||
            field.type == 'select-one' ||
            field.type == 'radio')  &&
            field.disabled == false) {

            var value = '';
            // get field's value
            if (field.type == "select-one") {
                var si = field.selectedIndex;
                if (si >= 0) {
                    value = field.options[si].value;
                }
            } else {
                value = field.value;
            }

            if (value.length > 0) {
                if (!isAllDigits(value)) {
                    bValid = false;

                } else {

                    var iValue = parseInt(value);
                    if (isNaN(iValue) || !(iValue >= -128 && iValue <= 127)) {
                        bValid = false;
                    }
                }
            }

        }
        
        field.focus();

        return bValid;
    }


    /*$RCSfile: staticJavascriptField.js,v $ $Revision: 1.1.1.1 $ $Date: 2007/07/18 18:57:54 $ */
    /**
    * A field is considered valid if less than the specified maximum.
    * Fields are not checked if they are disabled.
    * <p>
    * <strong>Caution:</strong> Using <code>validateMaxLength</code> on a password field in a 
    *  login page gives unnecessary information away to hackers. While it only slightly
    *  weakens security, we suggest using it only when modifying a password.</p>
    * @param form The form validation is taking place on.
    */
    function validateFieldMaxLength(field,iMax) {
        var isValid = true;

        if ((field.type == 'hidden' ||
            field.type == 'text' ||
            field.type == 'password' ||
            field.type == 'textarea') &&
            field.disabled == false) {

            if (field.value.length > iMax) {
                isValid = false;
            }
        }
       field.focus();

        return isValid;
    }


    /*$RCSfile: staticJavascriptField.js,v $ $Revision: 1.1.1.1 $ $Date: 2007/07/18 18:57:54 $ */
    /**
    *  Check to see if fields must contain a value.
    * Fields are not checked if they are disabled.
    * <p>
    * @param form The form validation is taking place on.
    */

    function validateFieldRequired(field) {
        var isValid = true;

            if ((field.type == 'hidden' ||
                field.type == 'text' ||
                field.type == 'textarea' ||
                field.type == 'file' ||
                field.type == 'checkbox' ||
                field.type == 'select-one' ||
                field.type == 'password') &&
                field.disabled == false) {

                var value = '';
                // get field's value
                if (field.type == "select-one") {
                    var si = field.selectedIndex;
                    if (si >= 0) {
                        value = field.options[si].value;
                    }
                } else if (field.type == 'checkbox') {
                    if (field.checked) {
                        value = field.value;
                    }
                } else {
                    value = field.value;
                }

                if (trim(value).length == 0) {
                    isValid = false;
                }
            } else if (field.type == "select-multiple") { 
                var numOptions = field.options.length;
                lastSelected=-1;
                for(loop=numOptions-1;loop>=0;loop--) {
                    if(field.options[loop].selected) {
                        lastSelected = loop;
                        value = field.options[loop].value;
                        break;
                    }
                }
                if(lastSelected < 0 || trim(value).length == 0) {
                    isValid=false;
                }
            } else if ((field.length > 0) && (field[0].type == 'radio' || field[0].type == 'checkbox')) {
                isChecked=-1;
                for (loop=0;loop < field.length;loop++) {
                    if (field[loop].checked) {
                        isChecked=loop;
                        break; // only one needs to be checked
                    }
                }
                if (isChecked < 0) {
                    isValid=false;
                }
            }
		field.focus();

        return isValid;
    }
    
    // Trim whitespace from left and right sides of s.
    function trim(s) {
        return s.replace( /^\s*/, "" ).replace( /\s*$/, "" );
    }


    /*$RCSfile: staticJavascriptField.js,v $ $Revision: 1.1.1.1 $ $Date: 2007/07/18 18:57:54 $ */
    /**
    * Check to see if fields are a valid creditcard number based on Luhn checksum.
    * Fields are not checked if they are disabled.
    * <p>
    * @param form The form validation is taking place on.
    */
    function validateFieldCreditCard(field) {
        var bValid = true;

        if ((field == 'text' ||
             field == 'textarea') &&
            (field.value.length > 0)  &&
             field.disabled == false) {
            if (!luhnCheck(field.value)) {
                bValid = false;
            }
        }
        field.focus();

        return bValid;
    }

    /**
     * Checks whether a given credit card number has a valid Luhn checksum.
     * This allows you to spot most randomly made-up or garbled credit card numbers immediately.
     * Reference: http://www.speech.cs.cmu.edu/~sburke/pub/luhn_lib.html
     */
    function luhnCheck(cardNumber) {
        if (isLuhnNum(cardNumber)) {
            var no_digit = cardNumber.length;
            var oddoeven = no_digit & 1;
            var sum = 0;
            for (var count = 0; count < no_digit; count++) {
                var digit = parseInt(cardNumber.charAt(count));
                if (!((count & 1) ^ oddoeven)) {
                    digit *= 2;
                    if (digit > 9) digit -= 9;
                };
                sum += digit;
            };
            if (sum == 0) return false;
            if (sum % 10 == 0) return true;
        };
        return false;
    }

    function isLuhnNum(argvalue) {
        argvalue = argvalue.toString();
        if (argvalue.length == 0) {
            return false;
        }
        for (var n = 0; n < argvalue.length; n++) {
            if ((argvalue.substring(n, n+1) < "0") ||
                (argvalue.substring(n,n+1) > "9")) {
                return false;
            }
        }
        return true;
    }


   /*$RCSfile: staticJavascriptField.js,v $ $Revision: 1.1.1.1 $ $Date: 2007/07/18 18:57:54 $ */
    /**
    * Check to see if fields are a valid date.
    * Fields are not checked if they are disabled.
    * <p>
    * @param form The form validation is taking place on.
    */
    function validateFieldDate(field) {
       var bValid = true;
           var value = field.value;
           var datePattern = "dd/MM/yyyy";
           // try loose pattern
           if ((field.type == 'hidden' ||
                field.type == 'text' ||
                field.type == 'textarea') &&
               (value.length > 0) && (datePattern.length > 0) &&
                field.disabled == false) {
                 var MONTH = "MM";
                 var DAY = "dd";
                 var YEAR = "yyyy";
                 var orderMonth = datePattern.indexOf(MONTH);
                 var orderDay = datePattern.indexOf(DAY);
                 var orderYear = datePattern.indexOf(YEAR);
                 if ((orderDay < orderYear && orderDay > orderMonth)) {
                     var iDelim1 = orderMonth + MONTH.length;
                     var iDelim2 = orderDay + DAY.length;
                     var delim1 = datePattern.substring(iDelim1, iDelim1 + 1);
                     var delim2 = datePattern.substring(iDelim2, iDelim2 + 1);
                     if (iDelim1 == orderDay && iDelim2 == orderYear) {
                        dateRegexp = new RegExp("^(\\d{2})(\\d{2})(\\d{4})$");
                     } else if (iDelim1 == orderDay) {
                        dateRegexp = new RegExp("^(\\d{2})(\\d{2})[" + delim2 + "](\\d{4})$");
                     } else if (iDelim2 == orderYear) {
                        dateRegexp = new RegExp("^(\\d{2})[" + delim1 + "](\\d{2})(\\d{4})$");
                     } else {
                        dateRegexp = new RegExp("^(\\d{2})[" + delim1 + "](\\d{2})[" + delim2 + "](\\d{4})$");
                     }
                     var matched = dateRegexp.exec(value);
                     if(matched != null) {
                        if (!isValidDate(matched[2], matched[1], matched[3])) {
                           bValid =  false;
                        }
                     } else {
                        bValid =  false;
                     }
                 } else if ((orderMonth < orderYear && orderMonth > orderDay)) {
                     var iDelim1 = orderDay + DAY.length;
                     var iDelim2 = orderMonth + MONTH.length;
                     var delim1 = datePattern.substring(iDelim1, iDelim1 + 1);
                     var delim2 = datePattern.substring(iDelim2, iDelim2 + 1);
                     if (iDelim1 == orderMonth && iDelim2 == orderYear) {
                         dateRegexp = new RegExp("^(\\d{2})(\\d{2})(\\d{4})$");
                     } else if (iDelim1 == orderMonth) {
                         dateRegexp = new RegExp("^(\\d{2})(\\d{2})[" + delim2 + "](\\d{4})$");
                     } else if (iDelim2 == orderYear) {
                         dateRegexp = new RegExp("^(\\d{2})[" + delim1 + "](\\d{2})(\\d{4})$");
                     } else {
                         dateRegexp = new RegExp("^(\\d{2})[" + delim1 + "](\\d{2})[" + delim2 + "](\\d{4})$");
                     }
                     var matched = dateRegexp.exec(value);
                     if(matched != null) {
                         if (!isValidDate(matched[1], matched[2], matched[3])) {
                             bValid =  false;
                          }
                     } else {
                         bValid =  false;
                     }
                 } else if ((orderMonth > orderYear && orderMonth < orderDay)) {
                     var iDelim1 = orderYear + YEAR.length;
                     var iDelim2 = orderMonth + MONTH.length;
                     var delim1 = datePattern.substring(iDelim1, iDelim1 + 1);
                     var delim2 = datePattern.substring(iDelim2, iDelim2 + 1);
                     if (iDelim1 == orderMonth && iDelim2 == orderDay) {
                         dateRegexp = new RegExp("^(\\d{4})(\\d{2})(\\d{2})$");
                     } else if (iDelim1 == orderMonth) {
                         dateRegexp = new RegExp("^(\\d{4})(\\d{2})[" + delim2 + "](\\d{2})$");
                     } else if (iDelim2 == orderDay) {
                         dateRegexp = new RegExp("^(\\d{4})[" + delim1 + "](\\d{2})(\\d{2})$");
                     } else {
                         dateRegexp = new RegExp("^(\\d{4})[" + delim1 + "](\\d{2})[" + delim2 + "](\\d{2})$");
                     }
                     var matched = dateRegexp.exec(value);
                     if(matched != null) {
                         if (!isValidDate(matched[3], matched[2], matched[1])) {
                             bValid =  false;
                         }
                     } else {
                          bValid =  false;
                     }
                 } else {
                     bValid =  false;
                 }
          }

       field.focus();

       return bValid;
    }
    
    function isValidDate(day, month, year) {
	    if (month < 1 || month > 12) {
            return false;
        }
        if (day < 1 || day > 31) {
            return false;
        }
        if ((month == 4 || month == 6 || month == 9 || month == 11) &&
            (day == 31)) {
            return false;
        }
        if (month == 2) {
            var leap = (year % 4 == 0 &&
               (year % 100 != 0 || year % 400 == 0));
            if (day>29 || (day == 29 && !leap)) {
                return false;
            }
        }
        return true;
    }


    /*$RCSfile: staticJavascriptField.js,v $ $Revision: 1.1.1.1 $ $Date: 2007/07/18 18:57:54 $ */
    /**
    *  Check to see if fields are a valid short.
    * Fields are not checked if they are disabled.
    * <p>
    * @param form The form validation is taking place on.
    */
    function validateFieldShort(field) {
        var bValid = true;

        if ((field.type == 'hidden' ||
            field.type == 'text' ||
            field.type == 'textarea' ||
            field.type == 'select-one' ||
            field.type == 'radio')  &&
            field.disabled == false) {

            var value = '';
            // get field's value
            if (field.type == "select-one") {
                var si = field.selectedIndex;
                if (si >= 0) {
                    value = field.options[si].value;
                }
            } else {
                value = field.value;
            }

            if (value.length > 0) {
                if (!isAllDigits(value)) {
                    bValid = false;

                } else {

                    var iValue = parseInt(value);
                    if (isNaN(iValue) || !(iValue >= -32768 && iValue <= 32767)) {
                        bValid = false;
                    }
               }
           }
        }

        field.focus();

        return bValid;
    }


    /*$RCSfile: staticJavascriptField.js,v $ $Revision: 1.1.1.1 $ $Date: 2007/07/18 18:57:54 $ */
    /**
    * Check to see if fields are a valid float.
    * Fields are not checked if they are disabled.
    * <p>
    * @param form The form validation is taking place on.
    */
    function validateFieldFloat(field) {
        var bValid = true;
        	
        if ((field.type == 'hidden' ||
            field.type == 'text' ||
            field.type == 'textarea' ||
            field.type == 'select-one' ||
            field.type == 'radio') &&
            field.disabled == false) {
    
        	var value = '';
            // get field's value
            if (field.type == "select-one") {
                var si = field.selectedIndex;
                if (si >= 0) {
                    value = field.options[si].value;
                }
            } else {
                value = field.value;
            }
    
            if (value.length > 0) {
                // remove '.' before checking digits
                var tempArray = value.split('.');
                //Strip off leading '0'
                var zeroIndex = 0;
                var joinedString= tempArray.join('');
                while (joinedString.charAt(zeroIndex) == '0') {
                    zeroIndex++;
                }
                var noZeroString = joinedString.substring(zeroIndex,joinedString.length);

                if (!isAllDigits(noZeroString)) {
                    bValid = false;

                } else {
                var iValue = parseFloat(value);
                if (isNaN(iValue)) {
                    bValid = false;
                }
                }
            }
        }

        field.focus();

        return bValid;
    }


   /*$RCSfile: staticJavascriptField.js,v $ $Revision: 1.1.1.1 $ $Date: 2007/07/18 18:57:54 $ */
    /**
    * Check to see if fields are a valid email address.
    * Fields are not checked if they are disabled.
    * <p>
    * @param form The form validation is taking place on.
    */
    function validateFieldEmail(field) {
        var bValid = true;
            if ((field.type == 'hidden' || 
                 field.type == 'text' ||
                 field.type == 'textarea') &&
                (field.value.length > 0) &&
                field.disabled == false) {
                if (!checkEmail(field.value)) {
                    bValid = false;
                }
            }
        field.focus();

        return bValid;
    }

    /**
     * Reference: Sandeep V. Tamhankar (stamhankar@hotmail.com),
     * http://javascript.internet.com
     */
    function checkEmail(emailStr) {
       if (emailStr.length == 0) {
           return true;
       }
       var emailPat=/^(.+)@(.+)$/;
       var specialChars="\\(\\)<>@,;:\\\\\\\"\\.\\[\\]";
       var validChars="\[^\\s" + specialChars + "\]";
       var quotedUser="(\"[^\"]*\")";
       var ipDomainPat=/^(\d{1,3})[.](\d{1,3})[.](\d{1,3})[.](\d{1,3})$/;
       var atom=validChars + '+';
       var word="(" + atom + "|" + quotedUser + ")";
       var userPat=new RegExp("^" + word + "(\\." + word + ")*$");
       var domainPat=new RegExp("^" + atom + "(\\." + atom + ")*$");
       var matchArray=emailStr.match(emailPat);
       if (matchArray == null) {
           return false;
       }
       var user=matchArray[1];
       var domain=matchArray[2];
       if (user.match(userPat) == null) {
           return false;
       }
       var IPArray = domain.match(ipDomainPat);
       if (IPArray != null) {
           for (var i = 1; i <= 4; i++) {
              if (IPArray[i] > 255) {
                 return false;
              }
           }
           return true;
       }
       var domainArray=domain.match(domainPat);
       if (domainArray == null) {
           return false;
       }
       var atomPat=new RegExp(atom,"g");
       var domArr=domain.match(atomPat);
       var len=domArr.length;
       if ((domArr[domArr.length-1].length < 2) ||
           (domArr[domArr.length-1].length > 3)) {
           return false;
       }
       if (len < 2) {
           return false;
       }
       return true;
    }

  


    /*$RCSfile: staticJavascriptField.js,v $ $Revision: 1.1.1.1 $ $Date: 2007/07/18 18:57:54 $ */
    /**
    * Check to see if fields are a valid using a regular expression.
    * Fields are not checked if they are disabled.
    * <p>
    * @param form The form validation is taking place on.
    */
    function validateFieldMask(field, mask) {
        var isValid = true;

            if ((field.type == 'hidden' ||
                field.type == 'text' ||
                 field.type == 'textarea' ||
				 field.type == 'file') &&
                 (field.value.length > 0) &&
                 field.disabled == false) {

                if (!matchPattern(field.value, mask)) {
                    isValid = false;
                }
            }
        field.focus();

        return isValid;
    }

    function matchPattern(value, mask) {
       return mask.exec(value);
    }


    /*$RCSfile: staticJavascriptField.js,v $ $Revision: 1.1.1.1 $ $Date: 2007/07/18 18:57:54 $ */
    /**
    * A field is considered valid if greater than the specified minimum.
    * Fields are not checked if they are disabled.
    * <p>
    * <strong>Caution:</strong> Using <code>validateMinLength</code> on a password field in a 
    *  login page gives unnecessary information away to hackers. While it only slightly
    *  weakens security, we suggest using it only when modifying a password.</p>
    * @param form The form validation is taking place on.
    */
    function validateFieldMinLength(field) {
        var isValid = true;

            if ((field.type == 'hidden' ||
                field.type == 'text' ||
                field.type == 'password' ||
                field.type == 'textarea') &&
                field.disabled == false) {

                var iMin = parseInt(oMinLength[x][2]("minlength"));
                if ((trim(field.value).length > 0) && (field.value.length < iMin)) {
                    if (i == 0) {
                        focusField = field;
                    }
                    fields[i++] = oMinLength[x][1];
                    isValid = false;
                }
            }
        field.focus();

        return isValid;
    }

    /*$RCSfile: staticJavascriptField.js,v $ $Rev: 367268 $ $Date: 2007/07/18 18:57:54 $ */
    /**
    * Check to see if fields are a valid integer.
    * Fields are not checked if they are disabled.
    * <p>
    * @param form The form validation is taking place on.
    */
    function validateFieldInteger(field) {
        var bValid = true;

        if ((field.type == 'hidden' ||
            field.type == 'text' ||
            field.type == 'textarea' ||
            field.type == 'select-one' ||
            field.type == 'radio') &&
            field.disabled == false) {

            var value = '';
            // get field's value
            if (field.type == "select-one") {
                var si = field.selectedIndex;
                if (si >= 0) {
                    value = field.options[si].value;
                }
            } else {
                value = field.value;
            }

            if (value.length > 0) {

                if (!isDecimalDigits(value)) {
                    bValid = false;

                } else {
                    var iValue = parseInt(value, 10);
                    if (isNaN(iValue) || !(iValue >= -2147483648 && iValue <= 2147483647)) {
                        bValid = false;
                   }
               }
           }
        }
            
        field.focus();
        return bValid;
    }

	  /**
	   * Check a value only contains valid decimal digits
	   * @param argvalue The value to check.
	   */
	  function isDecimalDigits(argvalue) {
	      argvalue = argvalue.toString();
	      var validChars = "0123456789";
	
	      var startFrom = 0;
	      if (argvalue.charAt(0) == "-") {
	          startFrom = 1;
	      }
	
	      for (var n = startFrom; n < argvalue.length; n++) {
	          if (validChars.indexOf(argvalue.substring(n, n+1)) == -1) return false;
	      }
	      return true;
	  }

	  /**
	   * Checks whether the field is present on the form.
	   * @param field The form field.
	   */
	  function isFieldPresent(field) {
	      return !(field == null || field == undefined);
	  }
	
	  /**
	   * Check a value only contains valid numeric digits
	   * @param argvalue The value to check.
	   */
	  function isAllDigits(argvalue) {
	      argvalue = argvalue.toString();
	      var validChars = "0123456789";
	      var startFrom = 0;
	      if (argvalue.substring(0, 2) == "0x") {
	         validChars = "0123456789abcdefABCDEF";
	         startFrom = 2;
	      } else if (argvalue.charAt(0) == "0") {
	         validChars = "01234567";
	         startFrom = 1;
	      } else if (argvalue.charAt(0) == "-") {
	          startFrom = 1;
	      }
	
	      for (var n = startFrom; n < argvalue.length; n++) {
	          if (validChars.indexOf(argvalue.substring(n, n+1)) == -1) return false;
	      }
	      return true;
	  }

    /*$RCSfile: staticJavascriptField.js,v $ $Rev: 367268 $ $Date: 2007/07/18 18:57:54 $ */
    /**
    * Check to see if fields is in a valid integer range.
    * Fields are not checked if they are disabled.
    * <p>
    * @param form The form validation is taking place on.
    */
    function validateFieldIntRange(field,pMin,pMax) {
        var isValid = true;

        if (field.disabled == false)  {
            var value = '';
            if (field.type == 'hidden' ||
                field.type == 'text' || field.type == 'textarea' ||
                field.type == 'radio' ) {
                value = field.value;
            }
            if (field.type == 'select-one') {
                var si = field.selectedIndex;
                if (si >= 0) {
                    value = field.options[si].value;
                }
            }
            if (value.length > 0) {
                var iMin = parseInt(pMin);
                var iMax = parseInt(pMax);
                var iValue = parseInt(value, 10);
                if (!(iValue >= iMin && iValue <= iMax)) {
                    isValid = false;
                }
            }
        }
		field.focus();
		
        return isValid;
    }

	function validateFieldLong(field) {
        var bValid = true;

        if (field.type == 'text' ||
            field.type == 'textarea' ||
            field.type == 'select-one' ||
            field.type == 'radio') {

            var value = '';
            // get field's value
            if (field.type == "select-one") {
                var si = field.selectedIndex;
                if (si >= 0) {
                    value = trim( field.options[si].value );
                }
            } else {
                value = trim( field.value );
            }

            if (value.length > 0) {

                if (!isAllDigits(value)) {
                    bValid = false;
                } else {
                    var longValue = parseFloat(value);
                    if (isNaN(longValue) || !(longValue >= 0 && longValue <= 9223372036854775807)) {
                        bValid = false;
                   }
               }
           	}
        }
		
		field.focus();
       if (ffield.type == 'text' ||
            field.type == 'textarea' ||
            field.type == 'password') 
       {
           field.select();
       }
       
       return bValid;
	}

	function validateFieldDouble(field) { 
		var bValid = true; 

		if (field.type == 'text' ||
			field.type == 'textarea' ||
			field.type == 'select-one' ||
			field.type == 'radio') { 
			var value = ''; // get field's value 
			if (field.type == "select-one") { 
				var si = field.selectedIndex; 
				if (si >= 0) { 
					value = field.options[si].value; 
				} 
			} else { 
				value = field.value; 
			} 
			if (value.length > 0) { 
				if (value.substring(value.length-1) == '.' ||
					new Number(value).toString() == 'NaN') { 
					bValid = false; 
				} 
			} 
		} 
		
		field.focus(); 

		return bValid; 
	}	  
	
	function validateFieldBigDecimal(field) { 
		var bValid = true; 
		if ((field.type == 'text' || field.type == 'textarea') && 
			(field.value.length > 0)) { 
			if (!isNaN(field.value)) { 
				bValid = false; 
			} 
		} 
		field.focus();	

		return bValid; 
	} 
	
	