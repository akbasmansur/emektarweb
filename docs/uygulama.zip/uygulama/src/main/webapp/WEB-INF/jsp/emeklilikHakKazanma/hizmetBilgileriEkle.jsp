<%@page language="java" contentType="text/html; charset=ISO-8859-9"
	pageEncoding="ISO-8859-9"%>
<%@taglib prefix="bean" uri="/WEB-INF/config/tld/struts-bean.tld"%>
<%@taglib prefix="display" uri="/WEB-INF/config/tld/displaytag.tld"%>
<%@taglib prefix="tiles" uri="/WEB-INF/config/tld/struts-tiles.tld"%>
<%@taglib prefix="html" uri="/WEB-INF/config/tld/struts-html.tld"%>
<%@taglib prefix="logic" uri="/WEB-INF/config/tld/struts-logic.tld"%>
<%@taglib prefix="nested" uri="/WEB-INF/config/tld/struts-nested.tld"%>
<%@taglib prefix="emektar" uri="/WEB-INF/config/tld/emektar.tld"%>

<%@page import="tr.gov.sgk.emektarWeb.genel.util.Sabit"%>
<script>
function fiiliHizmetKontrolu(){

if(document.forms[0].hizmetTuru.value==<%=Sabit.HIZMETTURU_ASKERLIKBORC.toString()%> || 
   document.forms[0].hizmetTuru.value==<%=Sabit.HIZMETTURU_YURTDISIBORC.toString()%> ||
   document.forms[0].hizmetTuru.value==<%=Sabit.HIZMETTURU_VERGIBORCLANMASI.toString()%> ){
	document.forms[0].fiiliHizmetSuresi.disabled = true;
	document.forms[0].fiiliHizmetSuresi.value = "";
}
	else document.forms[0].fiiliHizmetSuresi.disabled = false;
}

function gunFarkiniBul(){
    var date1 = document.forms[0].baslangicTarihi.value;
    var date2 = document.forms[0].bitisTarihi.value;
    
	if(date1 != "" && date2 != ""){
	   	var bas= parseDate(date1);
	   	var bit= parseDate(date2);
	   	
	   	if(bit[0]>30){bit[0]=30;}
	    if(bas[0]>30){bas[0]=30;}
	    
	   	if(bit[0]< bas[0]){
	   		bit[0] = bit[0] + 30;
	   		bit[1] = bit[1] - 1;
	   		if(bit[1] == 0){
	   			bit[1]=12;
	   			bit[2] = bit[2]-1;
	   		}
	   	}
	   	if(bit[1]< bas[1]){
	   		bit[1] = bit[1] + 12;
	   		bit[2] = bit[2] - 1;
	   	}
	   	
	    document.forms[0].hizmetSuresi.value= Math.abs((bit[0]- bas[0]) + (bit[1]- bas[1])*30 + (bit[2]- bas[2])*360);
	    
	    if(parseInt(date2.substring(6)+date2.substring(3,5)+date2.substring(0,2),10) >= 20081001)
	    	document.forms[0].hizmetSuresi.value = parseInt(document.forms[0].hizmetSuresi.value,10)+1;
	  
	}
}
function  parseDate(date){
	var dateArray = [];
	dateArray[0] = parseInt(date.substring(0,2),10);
	dateArray[1] = parseInt(date.substring(3,5),10);
	dateArray[2] = parseInt(date.substring(6),10);
	return dateArray;
}
function dateSetup(){
		var errorMessage = "Ge�ersiz tarih!";
		var dateBaslangicTarihi = new DateMask("dd/MM/yyyy", "baslangicTarihi");
		var dateBitisTarihi = new DateMask("dd/MM/yyyy", "bitisTarihi");
       	dateBaslangicTarihi.validationMessage = errorMessage;
       	dateBitisTarihi.validationMessage = errorMessage;     	
}
function dateSetup2(){
		var errorMessage = "Ge�ersiz tarih!";
		var dateBitisTarihi2 = new DateMask("dd/MM/yyyy", "bitisTarihi");
       	dateBitisTarihi2.validationMessage = errorMessage;     	
}	
</script>

<html:form action="/HizmetBilgileriEkleAction.do">

<table class="formTablo" style="border: none" style="width=65%">
		<tr>
			<td class="formBaslikOrtali" colspan="2"><bean:message
				key="baslik.hakKazanma.hizmetBilgileriEkle"/></td>
		</tr>
		<logic:equal  property="sadece3201" value="false" name="EmeklilikBilgileriForm" scope="session">
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.hizmetTuru"/></div>
			</td>
			<td class="formKolonText" >
			<div align="left">
			<html:select property="hizmetTuru" style="metin" styleClass="metin" onchange="fiiliHizmetKontrolu()">
				<html:option value="<%=Sabit.HIZMETTURU_BAGKUR.toString() %>">Ba�kur</html:option>
				<html:option value="<%=Sabit.HIZMETTURU_SSK.toString() %>">SSK</html:option>
				<html:option value="<%=Sabit.HIZMETTURU_ES.toString() %>">Emekli Sand���</html:option>
				<html:option value="<%=Sabit.HIZMETTURU_DS.toString() %>">Di�er Sand�klar</html:option>
				<html:option value="<%=Sabit.HIZMETTURU_YURTDISIBORC.toString() %>">Yurt d��� bor�lanmas�</html:option>
				<html:option value="<%=Sabit.HIZMETTURU_ASKERLIKBORC.toString() %>">Askerlik bor�lanmas�</html:option>
				<html:option value="<%=Sabit.HIZMETTURU_VERGIBORCLANMASI.toString() %>">Vergi bor�lanmas�</html:option>
			</html:select>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.baslangicTarihi"/></div>
			</td>
			<td class="formKolonText" >
			<div align="left">
				<html:text property="baslangicTarihi" styleClass="metin" onblur="gunFarkiniBul();"/>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.bitisTarihi"/></div>
			</td>
			<td class="formKolonText">
			<div align="left">
				<html:text property="bitisTarihi" styleClass="metin" onblur="gunFarkiniBul();"/>
			</div>
			</td>
		
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.hizmetSuresi"/></div>
			</td>
			<td class="formKolonText">
			<div align="left">
				<html:text property="hizmetSuresi" styleClass="metin" ></html:text>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.fiiliHizmetSuresi"/></div>
			</td>
			<td class="formKolonText" colspan="3">
			<div align="left">
				<html:text property="fiiliHizmetSuresi" styleClass="metin"></html:text>
			</div>
			</td>
		</tr>
		<script>dateSetup();</script>
	</logic:equal>
	<logic:equal name="EmeklilikBilgileriForm"  property="sadece3201" value="true" scope="session">
	<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.hizmetTuru"/></div>
			</td>
			<td class="formKolonText" >
			<div align="left">
			Yurt d��� bor�lanmas�
			<html:hidden property="hizmetTuru" value="<%=Sabit.HIZMETTURU_YURTDISIBORC.toString()%>"/>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.odemeTarihi"/></div>
			</td>
			<td class="formKolonText">
			<div align="left">
				<html:hidden property="baslangicTarihi" value="01/01/1900"/>
				<html:text property="bitisTarihi" styleClass="metin"/>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.borclanilanSure"/></div>
			</td>
			<td class="formKolonText" colspan="3">
			<div align="left">
				<html:text property="hizmetSuresi" styleClass="metin"></html:text>
			</div>
			</td>
		</tr>
		<tr style="display: false">
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.fiiliHizmetSuresi"/></div>
			</td>
			<td class="formKolonText" colspan="3">
			<div align="left">
				<html:text property="fiiliHizmetSuresi" styleClass="metin"></html:text>
			</div>
			</td>
		</tr>
		<script>dateSetup2();</script>
	</logic:equal>
</table>
<div align="center">
<html:submit styleClass="buton"><bean:message key="buton.hakKazanma.kaydet"/></html:submit>
<emektar:AddButton  actionName="HizmetBilgileriListeleAction" valueKey="buton.hakKazanma.listeyeDon"/>
</div>
</html:form>

<BR><BR>
<div align="center" style="color:red;font-size: 12px;font-family: Verdana,arial;"> 
	UYARI: S�zle�meli ayl�klarda, yurtd���nda �al���lan s�relerin ba�lang�� ve biti� tarihleri 'BA�KUR' hizmeti olarak girilmelidir. 
</div>

<script>
fiiliHizmetKontrolu();
</script>