package tr.gov.sgk.emektarWeb.genel.taglib;

import java.util.StringTokenizer;

import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;

import tr.gov.sgk.emektarWeb.genel.util.KarakterKontrolleri;
import tr.gov.sgk.emektarWeb.genel.util.KarakterKontrolleri.KontrolType;

public class EditButtonTag extends TagSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String value = null;

	private String id = null;

	private String dispatcherMethod = null;

	private String actionName = null;

	private String preFunction = null;
	
	private String addParameters = null;

	private String valueKey = null;
	private String width = null;

	public String getValueKey() {
		return valueKey;
	}

	public void setValueKey(String valueKey) {
		this.valueKey = valueKey;
	}

	public void setPreFunction(String preFunction) {
		this.preFunction = preFunction;
	}


	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public void setDispatcherMethod(String dispatcherMethod) {
		this.dispatcherMethod = dispatcherMethod;
	}

	public void setId(String id) {
		this.id = id;
	}

	private String getButton() {
		
		KarakterKontrolleri karakterKontrolleri = KarakterKontrolleri.KarakterKontrolleriYarat(KontrolType.KONTROLTYPE_ALPHA_AND_NUMERIC_AND_NOKTALAMA, 10000,true);

		String html = "";
		String parantezKapat = "";
		html += "<INPUT type='button' class='buton' ";
		if (valueKey != null && !"".equals(valueKey))
			html += " value='"
					+ baslikGetir(valueKey) + "' ";
		else
			html += " value='" + value + "' ";
		if(width != null && !"".equals(width)){
			html += " style=\"width:"+width+";\"  ";
		}else {
			int valueLength = baslikGetir(valueKey).toString().length();
			if(valueLength > 9)
				html += " style=\"width:auto;\"  ";
			else 
				html += " style=\"width:75;\"  ";
		}
		html += " onClick=\"  ";
		if (preFunction != null && !"".equals(preFunction)) {
			html += "if("+preFunction + "){\r\n";
			parantezKapat = "}";
		}
		String parameters ="";
		if (addParameters != null && !"".equals(addParameters)) {
			StringTokenizer tokenizer = new StringTokenizer(addParameters, ";,.-");
			while (tokenizer.hasMoreTokens()) {
				String token = "";
				token = tokenizer.nextToken();
				if(pageContext.getRequest().getParameter(token) != null && !"".equals(pageContext.getRequest().getParameter(token)))
					parameters += "&" +token+"="+ karakterKontrolleri.getGuvenlikKontrol(pageContext.getRequest().getParameter(token));
				else if (pageContext.getRequest().getAttribute(token)!= null)
					parameters += "&" +token+"="+ karakterKontrolleri.getGuvenlikKontrol(pageContext.getRequest().getAttribute(token).toString());
			}
		} 

		html += " submitjs('"+actionName+".do?dispatch=" + dispatcherMethod+parameters+"', false, true)" + parantezKapat + "\" >";
				
		return html;
	}
	
	
	public String baslikGetir(String deger) {
		String sonuc = "";
		if (deger != null && !"".equals(deger)) {
			try {
				sonuc = ((org.apache.struts.util.PropertyMessageResources) pageContext.getServletContext().getAttribute(
						"org.apache.struts.action.MESSAGE")).getMessage(deger);
			} catch (Exception ex) {
				sonuc = "";
			}
		}
		if (sonuc == null) {
			return "";
		} else {
			return sonuc;
		}

	}

	public int doStartTag() throws JspException {

		try {
			JspWriter out = pageContext.getOut();

			out.print(getButton());
		} catch (Exception ex) {
			throw new JspException(ex.getMessage());
		} finally {
			this.release();
		}
		return SKIP_BODY;
	}

	/**
	 * Release any acquired resources.
	 */
	public void release() {
		super.release();
		value = null;
		id = null;
		dispatcherMethod = null;
		actionName = null;
		preFunction = null;
		addParameters = null;
		width = null;
	}

	public String getActionName() {
		return actionName;
	}

	public String getId() {
		return id;
	}

	public String getDispatcherMethod() {
		return dispatcherMethod;
	}

	public String getPreFunction() {
		return preFunction;
	}

	public String getValue() {
		return value;
	}

	public String getAddParameters() {
		return addParameters;
	}

	public void setAddParameters(String addParameters) {
		this.addParameters = addParameters;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

}
