<%@page language="java" contentType="text/html; charset=ISO-8859-9"
	pageEncoding="ISO-8859-9"%>

<table width="100%" bgcolor="#FFFFFF">
<tr>
<td width="140px" align="right" valign="top" class="messageuyari"></td>
<td align="center" style="padding:10 10 10 10;" class="paragraph"> 
	<p> </p>
	<p>&nbsp;</p>
	<p>&nbsp;</p>
</td>
<td width="140px" align="right" valign="bottom"></td>
</tr>
</table>
