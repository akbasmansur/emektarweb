package tr.gov.sgk.emektarWeb.emeklilikHakKazanma.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm.HizmetBilgileriForm;
import tr.gov.sgk.emektarWeb.genel.util.Sabit;

public class HizmetBilgileriGuncelleSayfaAction extends Action {

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		ArrayList<HizmetBilgileriForm> sessionHizmetBilgileri = (ArrayList<HizmetBilgileriForm>) request.getSession().getAttribute(Sabit.SESSION_HIZMETLISTESI);
		
		String siraNo = request.getParameter("siraNo");
		for(HizmetBilgileriForm hizmetForm: sessionHizmetBilgileri){
			if(hizmetForm.getSiraNo().equals(Integer.valueOf(siraNo))){
				request.setAttribute("HizmetBilgileriForm", hizmetForm);
				break;
			}
		}

		return mapping.findForward(Sabit.SUCCESS);
	}
}