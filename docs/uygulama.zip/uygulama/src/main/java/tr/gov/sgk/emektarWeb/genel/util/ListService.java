package tr.gov.sgk.emektarWeb.genel.util;

public class ListService {

}