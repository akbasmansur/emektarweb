<%@page language="java" contentType="text/html; charset=ISO-8859-9"
	pageEncoding="ISO-8859-9"%>
<%@taglib prefix="bean" uri="/WEB-INF/config/tld/struts-bean.tld"%>
<%@taglib prefix="display" uri="/WEB-INF/config/tld/displaytag.tld"%>
<%@taglib prefix="tiles" uri="/WEB-INF/config/tld/struts-tiles.tld"%>
<%@taglib prefix="html" uri="/WEB-INF/config/tld/struts-html.tld"%>
<%@taglib prefix="logic" uri="/WEB-INF/config/tld/struts-logic.tld"%>
<%@taglib prefix="nested" uri="/WEB-INF/config/tld/struts-nested.tld"%>
<%@taglib prefix="emektar" uri="/WEB-INF/config/tld/emektar.tld"%>

<%@page import="tr.gov.sgk.emektarWeb.genel.util.Sabit"%>
<table class="formTablo" style="border: dotted; width:99%; " >
		<tr>
			<td class="formBaslikOrtali" colspan="2"><bean:message
				key="baslik.hakKazanma.emeklilikBilgileri"/></td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.emeklilikTuru"/></div>
			</td>
			<td class="formKolonText" >
			<div align="left">
			<bean:write name="EmeklilikBilgileriForm" property="emeklilikTuruString"/>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.cinsiyet"/></div>
			</td>
			<td class="formKolonText" >
			<div align="left">
				<bean:write name="EmeklilikBilgileriForm" property="cinsiyetString"/>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.dogumTarihi" /></div>
			</td>
			<td class="formKolonText">
			<div align="left">
				<bean:write name="EmeklilikBilgileriForm" property="dogumTarihi"/>
			</div>
			</td>
		
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.maluliyetVarmi"/></div>
			</td>
			<td class="formKolonText">
			<div align="left">
				<bean:write name="EmeklilikBilgileriForm" property="maluliyetVarmiString"/>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.maluliyetDerecesi" /></div>
			</td>
			<td class="formKolonText" >
			<div align="left">
				<bean:write name="EmeklilikBilgileriForm" property="maluliyetDerecesiString"/>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message key="label.hakKazanma.erkenYaslanmaVarmi" /></div>
			</td>

			<td class="formKolonText">
			<div align="left">
				<bean:write name="EmeklilikBilgileriForm" property="erkenYaslanmaVarmiString"/>
			</div>
			</td>
 
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message key="label.hakKazanma.sadece3201" /></div>
			</td>

			<td class="formKolonText">
			<div align="left">
				<bean:write name="EmeklilikBilgileriForm" property="sadece3201String"/>
			</div>
			</td>
 
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message key="label.hakKazanma.bakMuhCocuk" /></div>
			</td>

			<td class="formKolonText">
			<div align="left">
				<bean:write name="EmeklilikBilgileriForm" property="bakMuhCocString"/>
			</div>
			</td>
 
		</tr>
		<logic:equal name="EmeklilikBilgileriForm" property="bakMuhCoc" value="true">
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message key="label.hakKazanma.bakGunSayisi" /></div>
			</td>

			<td class="formKolonText">
			<div align="left">
				<bean:write name="EmeklilikBilgileriForm" property="bakGunSayisi"/>
			</div>
			</td>
 
		</tr></logic:equal>
		
</table>

<br/>
<table class="formTablo" style="border: none; width:99%;">
<logic:notEmpty name="<%=Sabit.SESSION_HIZMETLISTESI %>" scope="session"> 
<tr>
		<td class="formBaslikOrtali" colspan="2"><bean:message
			key="baslik.hakKazanma.hizmetBilgileri"/>
		</td>
</tr>
</logic:notEmpty>
<logic:empty name="<%=Sabit.SESSION_HIZMETLISTESI %>" scope="session"> 
<tr>
		<td class="formBaslikOrtali" colspan="2"><bean:message
			key="baslik.hakKazanma.tumHizmetBilgileriEkle"/>
		</td>
</tr>
</logic:empty>
<tr>
<td align="center" colspan="2">
<display:table name="<%=Sabit.LISTE%>" class="listTable"
			export="false" id="tableId" trClick="true" pagesize="30"
			requestURI="HizmetBilgileriListeleAction.do" trClickParams="siraNo"
			scrollTable="true" defaultsort="2">

			<display:column titleKey="label.hakKazanma.hizmetTuru" property="hizmetTuru" decorator="tr.gov.sgk.emektarWeb.genel.decorator.HizmetTuruDecorator"/>
			
			<display:column titleKey="label.hakKazanma.baslangicTarihi" property="baslangicTarihi" headerClass="sortable" comparator="tr.gov.sgk.emektarWeb.genel.comparator.DateComparator" style="text-align:center"/>
			
			<display:column titleKey="label.hakKazanma.bitisTarihi" property="bitisTarihi" headerClass="sortable" style="text-align:center"/>
			
			<display:column titleKey="label.hakKazanma.hizmetSuresi" property="hizmetSuresi" headerClass="sortable" style="text-align:center"/>
			
			<display:column titleKey="label.hakKazanma.fiiliHizmetSuresi" property="fiiliHizmetSuresi" headerClass="sortable" style="text-align:center"/>
		</display:table>
		
		<emektar:AddButton actionName="HizmetBilgileriEkleSayfaAction" valueKey="buton.hakKazanma.ekle" />
		<emektar:EditButton actionName="HizmetBilgileriGuncelleSayfaAction" valueKey="buton.hakKazanma.guncelle" />
		<emektar:DeleteButton actionName="HizmetBilgileriSilAction"  valueKey="buton.hakKazanma.sil" />

</td>
</tr>
</table>
<div align="center">
	<logic:notEmpty name="<%=Sabit.SESSION_HIZMETLISTESI %>" scope="session"> 
		<emektar:AddButton actionName="EmeklilikHesaplaAction" valueKey="buton.hakKazanma.emeklilikHesapla"/>
	</logic:notEmpty>
</div>
<br/>

<br/>
<logic:present name="HakKazanmaSonucForm" >
	<table class="formTablo" style="border: none; width:99%;">
		<tr>
			<td class="formBaslikOrtali" colspan="2"><bean:message
				key="baslik.hakKazanma.sigortaliBilgileri"/></td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.yasiniz"/></div>
			</td>
			<td class="formKolonText2" >
			<div align="left">
			<bean:write name="HakKazanmaSonucForm" property="yasinizYil"/>
			<bean:write name="HakKazanmaSonucForm" property="yasinizAy"/>
			<bean:write name="HakKazanmaSonucForm" property="yasinizGun"/>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.sigortalilikSureniz" /></div>
			</td>
			<td class="formKolonText2">
			<div align="left">
				<bean:write name="HakKazanmaSonucForm" property="sigortalilikSurenizYil"/>
				<bean:write name="HakKazanmaSonucForm" property="sigortalilikSurenizAy"/>
				<bean:write name="HakKazanmaSonucForm" property="sigortalilikSurenizGun"/>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.hizmetSureniz"/></div>
			</td>
			<td class="formKolonText2" >
			<div align="left">
				<bean:write name="HakKazanmaSonucForm" property="hizmetSurenizString"/>
			</div>
			</td>
		</tr>	
	</table>
	
	<table class="formTablo" style="border: none; width:99%;">
		<tr>
			<td class="formBaslikOrtali" colspan="2"><bean:message
				key="baslik.hakKazanma.emeklilikSartlariniz"/></td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.yas"/></div>
			</td>
			<td class="formKolonText2" >
			<div align="left">
			<bean:write name="HakKazanmaSonucForm" property="emeklilikSartlari.yasString"/>  &nbsp; &nbsp; &nbsp; <bean:write name="HakKazanmaSonucForm" property="emeklilikSartlari.yasEytString"/>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.sigortalilikSuresi"/></div>
			</td>
			<td class="formKolonText2" >
			<div align="left">
				<bean:write name="HakKazanmaSonucForm" property="emeklilikSartlari.sigortalilikSuresiYil"/>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.hizmetSuresi" /></div>
			</td>
			<td class="formKolonText2">
			<div align="left">
				<bean:write name="HakKazanmaSonucForm" property="emeklilikSartlari.hizmetSuresiString"/>
			</div>
			</td>
		</tr>
	</table>
	
	<logic:equal  name="EmeklilikBilgileriForm" property="bakMuhCoc" value="true">
		<table class="formTablo" style="border: none; width:99%;">
			<tr>
				<td class="formBaslikOrtali" colspan="2"><bean:message
					key="baslik.hakKazanma.ozelKosul"/></td>
			</tr>
			<tr>
				<td class="formKolonBaslik" align="left">
					<bean:message key="label.hakKazanma.bakMuhCocukDusulenSure"/>
				</td>
				<td class="formKolonText2" align="left">
					<bean:write name="HakKazanmaSonucForm" property="dusulenSure"/>&nbsp;g�n
				</td>
			</tr>
		</table>
	</logic:equal>
	
	<table class="formTablo" style="border: none; width:99%;">
		<tr>
			<td class="formBaslikOrtali" colspan="2"><bean:message
				key="baslik.hakKazanma.hakKazanmaSonuc"/></td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.kalanYas"/></div>
			</td>
			<td class="formKolonText2" >
			<div align="left">
			<bean:write name="HakKazanmaSonucForm" property="kalanYasinizYil"/>
			<bean:write name="HakKazanmaSonucForm" property="kalanYasinizAy"/>
			<bean:write name="HakKazanmaSonucForm" property="kalanYasinizGun"/>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.kalanSigortalilikSuresi"/></div>
			</td>
			<td class="formKolonText2" >
			<div align="left">
				<bean:write name="HakKazanmaSonucForm" property="kalanSigortalilikSurenizYil"/>
				<bean:write name="HakKazanmaSonucForm" property="kalanSigortalilikSurenizAy"/>
				<bean:write name="HakKazanmaSonucForm" property="kalanSigortalilikSurenizGun"/>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.kalanHizmetSuresi" /></div>
			</td>
			<td class="formKolonText2">
			<div align="left">
				<bean:write name="HakKazanmaSonucForm" property="kalanHizmetSurenizString"/>
			</div>
			</td>
		</tr>
		<tr>
	</table>
	
	<table  class="formTablo" style="border: none; width:99%;">
	   <tr>
			<td class="formKolonText2">
				<div align="center" style="color:red;font-size: 12px;font-weight: bold;font-family: Verdana">
				<bean:write name="HakKazanmaSonucForm" property="emeklilikTarihi"/>
				</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonText2" >
				<div align="center" style="color:red;font-size: 11px;font-family: Verdana" >
				Yaz�l� talepte bulundu�u tarih itibariyle genel sa�l�k sigortas� primi dahil kendi
				sigortal�l��� nedeniyle prim ve prime ili�kin <br> her t�rl� borcunun olmamas� zorunludur.
				</div>
			</td>
		
		</tr>
	</table>
		
	<table style="border: none; width:99%;">
		<tr >
			<td class="metin">
				<div align="center" style="color:blue;font-size: 11px;font-family: Verdana">
				Bu sonu�lar girdi�iniz verilerin sonucudur. Emeklilik i�lemlerinizde Kurum kay�tlar� esast�r.
				<br> Bilgilendirme ama�l�d�r. Resmi i�lemlerde kullan�lamaz. 
				</div>
			</td>
		</tr>
	</table>
	
</logic:present>
