package tr.gov.sgk.emektarWeb.emeklilikHakKazanma.action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionMessages;

import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.baseForm.HizmetBilgileriForm;
import tr.gov.sgk.emektarWeb.genel.util.Sabit;

public class HizmetBilgileriGuncelleAction extends Action {

	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {

		HizmetBilgileriForm hizmetBilgileriForm = (HizmetBilgileriForm)form;
		
		ArrayList<HizmetBilgileriForm> sessionHizmetBilgileri = (ArrayList<HizmetBilgileriForm>) request.getSession().getAttribute(Sabit.SESSION_HIZMETLISTESI);
		
		for(HizmetBilgileriForm hizmetForm: sessionHizmetBilgileri){
			if(hizmetForm.getSiraNo().equals(Integer.valueOf(hizmetBilgileriForm.getSiraNo()))){
				sessionHizmetBilgileri.remove(hizmetForm);
				break;
			}
		}
		sessionHizmetBilgileri.add(hizmetBilgileriForm);
		request.getSession().setAttribute(Sabit.SESSION_HIZMETLISTESI, sessionHizmetBilgileri);
		
		ActionMessages messages = new ActionMessages();
		messages.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("mesaj.hakKazanma.hizmetGuncellendi"));
		saveMessages(request, messages);

		return mapping.findForward(Sabit.SUCCESS);
	}
}