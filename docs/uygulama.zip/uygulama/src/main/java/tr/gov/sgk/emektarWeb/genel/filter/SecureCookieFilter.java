package tr.gov.sgk.emektarWeb.genel.filter;

import javax.servlet.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import tr.gov.sgk.emektarWeb.emeklilikHakKazanma.business.HakKazanmaService;
import tr.gov.sgk.emektarWeb.genel.util.KarakterKontrolleri;
import tr.gov.sgk.emektarWeb.genel.util.SabitLokal;

import java.io.IOException;
 public class SecureCookieFilter implements Filter {

		private static final Logger log = LoggerFactory.getLogger(SecureCookieFilter.class);
		
    	/*    @Override
    	    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
    	            throws IOException, ServletException {

    	        if (response instanceof ServletResponse || response instanceof HttpServletResponse ) {
    	            HttpServletResponse httpResponse = (HttpServletResponse) response;
    	            HttpServletRequest httpRequest = (HttpServletRequest) request;
    	            HttpSession session = httpRequest.getSession(true);
    	           
    	            if(session!=null) {
	    	            // Cookie eklemeleri filtreye özel yapılmalı
	    	            Cookie secureCookie = new Cookie("JSESSIONID", session.getId());
	    	            secureCookie.setPath("/EMEKTARWEB");
	    	            secureCookie.setDomain("uyg.sgk.gov.tr"); // test için testgrp3.sgk.gov.tr yazılabilir.
	    	            secureCookie.setMaxAge(1800);
	    	            secureCookie.setHttpOnly(true);
	    	            secureCookie.setSecure(true);
	    	            // SameSite için WebSphere Cookie API desteklemiyorsa header ile ekle
	    	            httpResponse.addHeader("Set-Cookie",
	    	                    secureCookie.getName() + "=" + secureCookie.getValue() +
	    	                    "; Path=" + secureCookie.getPath() +
	    	                    "; Domain=" + secureCookie.getDomain() +
	    	                    "; Max-Age=" + secureCookie.getMaxAge() +
	    	                    "; HttpOnly; Secure; SameSite=Strict"
	    	            );
    	            }
    	        }

    	        chain.doFilter(request, response);
    	    }*/
		
		
		@Override
		public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
		        throws IOException, ServletException {

		    HttpServletRequest req = (HttpServletRequest) request;
		    HttpServletResponse res = (HttpServletResponse) response;
		    HttpSession session = req.getSession(true);

		    if (session != null) {
		        String sessionId = session.getId();

		        // Yeni cookie değerini header olarak oluştur
		        StringBuilder cookieValue = new StringBuilder();
		       // cookieValue.append("JSESSIONID=").append(sessionId)
		        cookieValue.append("; Path=/EMEKTARWEB")
		                   .append("; Domain=uyg.sgk.gov.tr")
		                   .append("; Max-Age=1800")
		                   .append("; HttpOnly")
		                   .append("; Secure")
		                   .append("; SameSite=Strict");

		        res.setHeader("Set-Cookie", cookieValue.toString());
		    }

		    chain.doFilter(request, response);
		}

    	    @Override
    	    public void init(FilterConfig filterConfig) {}

    	    @Override
    	    public void destroy() {}
    	}


