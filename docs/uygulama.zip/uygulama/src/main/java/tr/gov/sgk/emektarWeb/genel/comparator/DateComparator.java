/**
 * 
 */
package tr.gov.sgk.emektarWeb.genel.comparator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;

public class DateComparator implements Comparator {
	public int compare(Object object1, Object object2) {
		int returnValue=3;
		SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
		try {
			Date date1 = format.parse((String) object1);
			Date date2 = format.parse((String) object2);
			if (date1.equals(date2))
				returnValue = 0;
			else if (date1.after(date2))
				returnValue = 1;
			else
				returnValue = -1;

		} catch (ParseException e) {
			//e.printStackTrace(); 
		
		}

		return returnValue;

	}

}
