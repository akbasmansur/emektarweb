package tr.gov.sgk.emektarWeb.genel.taglib;

import java.util.StringTokenizer;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.commons.lang.StringUtils;

import tr.gov.sgk.emektarWeb.genel.util.KarakterKontrolleri;
import tr.gov.sgk.emektarWeb.genel.util.KarakterKontrolleri.KontrolType;


public class SubmitButtonTag extends TagSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String value = null;

	private String id = null;

	private String dispatcherMethod = null;

	private String actionName = null;

	private String formName = null;

	private String validation = null;

	private String preFunction = null;

	private String valueKey = null;

	private String addParameters = null;
	private String width= null;

	public String getAddParameters() {
		return addParameters;
	}

	public void setAddParameters(String addParameters) {
		this.addParameters = addParameters;
	}

	public String getValueKey() {
		return valueKey;
	}

	public void setValueKey(String valueKey) {
		this.valueKey = valueKey;
	}

	public void setPreFunction(String preFunction) {
		this.preFunction = preFunction;
	}

	public void setValidation(String validation) {
		this.validation = validation;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public void setDispatcherMethod(String dispatcherMethod) {
		this.dispatcherMethod = dispatcherMethod;
	}

	public void setId(String id) {
		this.id = id;
	}

	private String getButton() {
		
		KarakterKontrolleri karakterKontrolleri = KarakterKontrolleri.KarakterKontrolleriYarat(KontrolType.KONTROLTYPE_ALPHA_AND_NUMERIC_AND_NOKTALAMA, 10000,true);
		
		String html = "";
		String parantezKapat = "";
		if(id == null ){
			id = formName+"Submit";
		} 
		html += "<INPUT type='button' id="+id+"	class='buton'";

		if (valueKey != null && !"".equals(valueKey))
			html += " value='"	+ ((org.apache.struts.util.PropertyMessageResources) pageContext.getServletContext().getAttribute("org.apache.struts.action.MESSAGE"))							.getMessage(valueKey) + "' ";
		else
			html += " value='" + value + "' ";
		if(width != null && !"".equals(width)){
			html += " style=\"width:"+width+";\"  ";
		}else {
			int valueLength = baslikGetir(valueKey).toString().length();
			if(valueLength > 9)
				html += " style=\"width:auto;\"  ";
			else 
				html += " style=\"width:75;\"  ";
		}
		html += " onClick=\"  ";
		if (preFunction != null && !"".equals(preFunction)) {
			html += "if("+preFunction + "){\r\n";
			parantezKapat = "}";
		}
		if (validation != null && "true".equals(validation)) {
			String formNameIlkHarfBuyuk = StringUtils.capitalize(formName);
			html += " if(validate"+formNameIlkHarfBuyuk+"(document.forms['" + formName + "'])){";
			parantezKapat += "}";
		}
		if (actionName == null || "".equals(actionName))
			html += formName+".action=this.form.action+'.do?";
		else
			html += formName+".action='" + actionName + ".do?";
		
		
		if (dispatcherMethod!= null || "".equals(dispatcherMethod)) {
			html += "dispatch=" + dispatcherMethod+'&';
		} 

		if (addParameters != null && !"".equals(addParameters)) {
			StringTokenizer tokenizer = new StringTokenizer(addParameters, ";,.-");
			while (tokenizer.hasMoreTokens()) {
				String token = "";
				
				token = tokenizer.nextToken();
				if (pageContext.getRequest().getAttribute(token)!= null)
					html += token+"="+ karakterKontrolleri.getGuvenlikKontrol(pageContext.getRequest().getAttribute(token).toString())+"&" ;
				else if(pageContext.getRequest().getParameter(token) != null && !"".equals(pageContext.getRequest().getParameter(token)))
					html += token+"="+ karakterKontrolleri.getGuvenlikKontrol(pageContext.getRequest().getParameter(token))+"&" ;
			}
		}
		
			html += " '; document.getElementById('"+id+"').disabled=true; "+formName+".submit();"+parantezKapat+"\" >" + "\r\n";

		
		return html;
	}

	
	
	public String baslikGetir(String deger) {
		String sonuc = "";
		if (deger != null && !"".equals(deger)) {
			try {
				sonuc = ((org.apache.struts.util.PropertyMessageResources) pageContext.getServletContext().getAttribute(
						"org.apache.struts.action.MESSAGE")).getMessage(deger);
			} catch (Exception ex) {
				sonuc = "";
			}
		}
		if (sonuc == null) {
			return "";
		} else {
			return sonuc;
		}

	}
	
	public int doStartTag() throws JspException {

		try {
			JspWriter out = pageContext.getOut();

			out.print(getButton());
		} catch (Exception ex) {
			throw new JspException(ex.getMessage());
		} finally {
			this.release();
		}
		return SKIP_BODY;
	}


	public void release() {
		super.release();
		value = null;
		id = null;
		dispatcherMethod = null;
		actionName = null;
		addParameters = null;
		validation = null;
		formName = null;
		preFunction = null;
		width= null;
	}

	public String getFormName() {
		return formName;
	}

	public void setFormName(String formName) {
		this.formName = formName;
	}

	public String getActionName() {
		return actionName;
	}

	public String getId() {
		return id;
	}

	public String getDispatcherMethod() {
		return dispatcherMethod;
	}

	public String getPreFunction() {
		return preFunction;
	}

	public String getValidation() {
		return validation;
	}

	public String getValue() {
		return value;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

}
