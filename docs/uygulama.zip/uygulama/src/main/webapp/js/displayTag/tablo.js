

	var eSatir = null;
	var bcColor = null;
	var oldClass = null;
	var newWindow=false;
	var parametreler=null;
	var sEleman=null;
	var sayfa=null;
	var listeSayfaDegiskeni=null;
	
	function rd(row) {
		oldClass = row.className;
		row.className = "onmouseover";
	}
	
	function er(row) {
		if (row.className != "selected") {
			row.className = oldClass;
		}
	}
	
	/*
		bir satiri secer ve renklendirir
		
		ySatir - object	- secilecek satir
		params - String - secilen satirdaki kayda ait parametre katari.
							orn: p1=v1&p2=v2&p3=v3
	*/
	function sec(ySatir, params) {
		if (ySatir == eSatir)
			return false;
		if (eSatir != null){
			eSatir.className = bcColor;
		}	
			
		
		if(document.getElementById("sayfa")!='undefined' && document.getElementById("sayfa")!=null ){
			sayfa = document.getElementById("sayfa").value;	
		}	
		if(document.getElementById("ekstraOnclick")!='undefined' && document.getElementById("ekstraOnclick")!=null ){
			document.getElementById("ekstraOnclick").value=params;
			document.getElementById("ekstraOnclick").onchange();
		}	
		
		sEleman = params;
		eSatir = ySatir;
		bcColor = oldClass;
		ySatir.className = "selected";
	}
	
	function exportFunc(adres, kayitSayisi) {
		if (kayitSayisi > maxExportKayitSayisi) {
			alert(maxExportKayitSayisi + " " + maxExportUyarisi);
		}
		else {
			window.open(adres);
		}
	}
	
	function dblclkg(adres, parametre) {
	
		adres = adres.substring(adres.lastIndexOf("/")+1);
	
		if(newWindow==true)
			window.open(adres+'?'+parametre,'ekle','alwaysRaised=yes,dependent=yes,directories=no,width=700,height=600,resizable,scrollbars=no,status=0');
		else {
			emektarEvalURL(adres,parametre);
		}
	}
	
function submitjs(hedefURI, silmeIslemi, seciliOlmali) {
	
		if (seciliOlmali == true) {
			if (sEleman == null) {
				alert(secinizUyarisi);
			}
			else {
				if (silmeIslemi) {
					if (confirm(siliniyorUyarisi)) {
						emektarEvalURL(hedefURI,sEleman);
					}
				}
				else {
					emektarEvalURL(hedefURI,sEleman);
				}
			}
		}
		else {
			emektarEvalURL(hedefURI,sEleman);
		}
	}

function emektarEvalURL(hedefURI,params){
			
			hedefURI = hedefURI.substring(hedefURI.lastIndexOf("/")+1);
			
			if (params != null) {
				if(hedefURI.indexOf("?")< 0){
					if(sayfa!=null)
						window.location = hedefURI +'?'+ params+'&'+listeSayfaDegiskeni+'='+sayfa;
					else	
						window.location = hedefURI +'?'+ params;
				}
				else{ 
					if(sayfa!=null)
						window.location = hedefURI +'&'+ params+'&'+listeSayfaDegiskeni+'='+sayfa;
					else	
						window.location = hedefURI +'&'+ params;
				}
			}
			else{
				window.location = hedefURI;
			}
	
}		