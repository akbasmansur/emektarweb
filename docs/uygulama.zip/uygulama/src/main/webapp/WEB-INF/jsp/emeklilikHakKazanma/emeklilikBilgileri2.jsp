<%@page language="java" contentType="text/html; charset=ISO-8859-9"
	pageEncoding="ISO-8859-9"%>
<%@taglib prefix="bean" uri="/WEB-INF/config/tld/struts-bean.tld"%>
<%@taglib prefix="display" uri="/WEB-INF/config/tld/displaytag.tld"%>
<%@taglib prefix="tiles" uri="/WEB-INF/config/tld/struts-tiles.tld"%>
<%@taglib prefix="html" uri="/WEB-INF/config/tld/struts-html.tld"%>
<%@taglib prefix="logic" uri="/WEB-INF/config/tld/struts-logic.tld"%>
<%@taglib prefix="nested" uri="/WEB-INF/config/tld/struts-nested.tld"%>
<%@taglib prefix="emektar" uri="/WEB-INF/config/tld/emektar.tld"%>
<%@page import="tr.gov.sgk.emektarWeb.genel.util.Sabit"%>

<script>
function maluliyetKontrol(){
 		var malul=document.forms[0].maluliyetVarmi.value;
 		
 		if(malul==<%=Sabit.EVET%>){
 			document.forms[0].maluliyetDerecesi.disabled = false;
 		 	document.forms[0].erkenYaslanmaVarmi.disabled = true;
 		 	document.forms[0].sadece3201.disabled=true;
 		} else if(malul==<%=Sabit.HAYIR%>){
 			document.forms[0].maluliyetDerecesi.disabled = true;
 		 	document.forms[0].erkenYaslanmaVarmi.disabled = false;
 		 	document.forms[0].sadece3201.disabled=false;
 		}
  	}
 	function erkenYaslanmaKontrol(){
 		var erkenYas=document.forms[0].erkenYaslanmaVarmi.value;
 		
 		if(erkenYas==<%=Sabit.EVET%>){
 			document.forms[0].maluliyetDerecesi.disabled = true;
 			document.forms[0].maluliyetDerecesi.value =  document.forms[0].maluliyetDerecesi.options[0].value;
  	 		document.forms[0].maluliyetVarmi.disabled = true;
	 		document.forms[0].sadece3201.disabled=true;
 	 	} else if(erkenYas==<%=Sabit.HAYIR%>){
 	 		document.forms[0].maluliyetDerecesi.disabled = true;
  	 		document.forms[0].maluliyetVarmi.disabled = false;
	 		document.forms[0].sadece3201.disabled=false;
 	 	}
 	}
 	 function sadece3201Kontrol(){
 	 	
 	 	if(document.forms[0].sadece3201.checked){
 	 	 	document.forms[0].maluliyetDerecesi.disabled = true;
 	 		document.forms[0].maluliyetVarmi.disabled = true;
 	 		document.forms[0].erkenYaslanmaVarmi.disabled = true;
 	 		document.forms[0].bakMuhCoc.checked = false;
 	 		bakimaMuhtacKontrol();
 	 		document.forms[0].bakMuhCoc.disabled = true;
 	 	} else{
 	 		document.forms[0].maluliyetDerecesi.disabled = true;
 	 		document.forms[0].maluliyetVarmi.disabled = false;
 	 		document.forms[0].erkenYaslanmaVarmi.disabled = false;
 	 		document.forms[0].bakMuhCoc.disabled = false;
 	 	}
 	}
 	
 	function bakimaMuhtacKontrol(){
 		var cinsiyetSelection= document.forms[0].cinsiyet;
 		
 		if(cinsiyetSelection[0].checked==true){
 	 	 	document.forms[0].bakMuhCoc.checked=false;
 	 	 	document.getElementById('bakGunSayisiRow').style.display ='none';
	 	 	document.forms[0].bakGunSayisi.value = '';
	 	 	document.forms[0].sadece3201.disabled = false;
 	 	 	
 	 	} else {
 	 	 		
 		if(document.forms[0].bakMuhCoc.checked){
 	 	 	document.getElementById('bakGunSayisiRow').style.display ='';
 	 	 	document.forms[0].sadece3201.disabled = true;
 	 	 	
 	 	} else{
	 	 	document.getElementById('bakGunSayisiRow').style.display ='none';
	 	 	document.forms[0].bakGunSayisi.value = '';
	 	 	document.forms[0].sadece3201.disabled = false;
 	 	}
 	 	}
 	}
</script>


<html:form action="/EmeklilikBilgileriAction.do">
<table class="formTablo" style="border: none" style="width=100%" align="center">
		<tr>
			<td class="formBaslikOrtali" colspan="2"><bean:message
				key="baslik.hakKazanma.emeklilikBilgileriGiriniz"/></td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.emeklilikTuru"/></div>
			</td>
			<td class="formKolonText" >
			<div align="left">
			<bean:message
				key="label.hakKazanma.emeklilikTuruTam"/>
			<html:radio property="emeklilikTuru" value="<%=Sabit.EMEKLILIKTURU_TAM %>"/>
			<bean:message
				key="label.hakKazanma.emeklilikTuruKismi"/>
			<html:radio property="emeklilikTuru" value="<%=Sabit.EMEKLILIKTURU_KISMI %>"/></div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.cinsiyet"/></div>
			</td>
			<td class="formKolonText" >
			<div align="left">
			<bean:message
				key="label.hakKazanma.cinsiyetErkek"/>
			<html:radio property="cinsiyet" value="<%=Sabit.CINSIYET_ERKEK %>" onclick="bakimaMuhtacKontrol()"/>
			<bean:message
				key="label.hakKazanma.cinsiyetKadin"/>
			<html:radio property="cinsiyet" value="<%=Sabit.CINSIYET_KADIN %>" onclick="bakimaMuhtacKontrol()"/>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.dogumTarihi" /></div>
			</td>
			<td class="formKolonText">
			<div align="left"><html:text property="dogumTarihi"
							maxlength="10" readonly="false" styleClass="metin"
							onfocus="javascript:vDateType='3'"
							onkeypress="DateFormat(this,this.value,event,false,'3')"
							onblur="DateFormat(this,this.value,event,true,'3')" /> <a
							href="#"><img src="<%=Sabit.ANA_DIZIN%>img/calendar.png"
							name="cal3" id="cal3" border="0"> </a>&nbsp; <a
							onclick="document.getElementById('dogumTarihi').value='';"><img
							style="cursor: pointer" src="<%=Sabit.ANA_DIZIN%>img/silgi.png">
						</a> <script>
								Calendar.setup({
								inputField    : "dogumTarihi",
								button        : "cal3",
								align         : "Tr",
								ifFormat      : "%d/%m/%Y"
								});
								</script>
			</div>
			</td>
		
		</tr>
		<tr>
			<td class="formBaslikOrtali" colspan="2"><bean:message
				key="baslik.hakKazanma.ozelDurumBilgileri"/></td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.maluliyetVarmi"/></div>
			</td>
			<td class="formKolonText">
			<div align="left">
			<html:select property="maluliyetVarmi" onchange="maluliyetKontrol()">
				<html:option value="<%=Sabit.HAYIR.toString() %>">Hay�r</html:option>
				<html:option value="<%=Sabit.EVET.toString() %>">Evet</html:option>
			</html:select>
			</div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message
				key="label.hakKazanma.maluliyetDerecesi" /></div>
			</td>
			<td class="formKolonText" colspan="3">
			<div align="left"><html:select property="maluliyetDerecesi" disabled="true">
				<html:option value=""><bean:message key="label.hakKazanma.listedenSeciniz"/></html:option>
				<html:option value="<%=Sabit.MALULIYET_40_49 %>">40 - 49</html:option>
				<html:option value="<%=Sabit.MALULIYET_50_59 %>">50 - 59</html:option>
				<html:option value="<%=Sabit.MALULIYET_60_100 %>">60 ve �zeri kuruma girmeden �nce mal�l olanlar</html:option>
			</html:select></div>
			</td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message key="label.hakKazanma.erkenYaslanmaVarmi" /></div>
			</td>

			<td class="formKolonText">
			<div align="left">
			<html:select property="erkenYaslanmaVarmi" onchange="erkenYaslanmaKontrol()">
				<html:option value="<%=Sabit.HAYIR.toString() %>">Hay�r</html:option>
				<html:option value="<%=Sabit.EVET.toString() %>">Evet</html:option>
			</html:select>
			</div>
			</td>
 
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message key="label.hakKazanma.bakMuhCocuk" /></div>
			</td>

			<td class="formKolonText">
			<div align="left">
			<html:checkbox property="bakMuhCoc" onclick="bakimaMuhtacKontrol()" ></html:checkbox>
			</div>
			</td>
 
		</tr>
		<tr id="bakGunSayisiRow">
			<td class="formKolonBaslik">
			<div align="left"><bean:message key="label.hakKazanma.bakGunSayisi" /></div>
			</td>

			<td class="formKolonText">
			<div align="left">
			<html:text property="bakGunSayisi" styleClass="metin"></html:text>
			</div>
			</td>
 
		</tr>
		<tr>
			<td class="formBaslikOrtali" colspan="2"><bean:message
				key="baslik.hakKazanma.sadece3201Bilgileri"/></td>
		</tr>
		<tr>
			<td class="formKolonBaslik">
			<div align="left"><bean:message key="label.hakKazanma.sadece3201" /></div>
			</td>

			<td class="formKolonText">
			<div align="left">
			<html:checkbox property="sadece3201" onclick="sadece3201Kontrol()"></html:checkbox>
			</div>
			</td>
 
		</tr>

</table>
<br/>
<div align="center">
<html:submit styleClass="buton"><bean:message key="buton.tamam"/></html:submit>
</div>
</html:form>

<script>
var erkenYas=document.forms[0].erkenYaslanmaVarmi.value;
var malul=document.forms[0].maluliyetVarmi.value;
if(malul==<%=Sabit.EVET%>)
	maluliyetKontrol();
else if(erkenYas==<%=Sabit.EVET%>)
	erkenYaslanmaKontrol();
else if(document.forms[0].sadece3201.checked)
	sadece3201Kontrol();

bakimaMuhtacKontrol();
if(document.forms[0].sadece3201.checked)
	sadece3201Kontrol();


	
</script>
