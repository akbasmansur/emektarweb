package tr.gov.sgk.emektarWeb.genel.util;


import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class KarakterKontrolleri {
	
	public enum KontrolType {
		KONTROLTYPE_NUMERIC, KONTROLTYPE_ALPHA, KONTROLTYPE_TARIH, KONTROLTYPE_PARA, KONTROLTYPE_ALPHA_AND_NUMERIC,KONTROLTYPE_IP,
		KONTROLTYPE_TARIH_TIMESTAMP,KONTROLTYPE_SAAT,
		KONTROLTYPE_ALPHA_AND_NUMERIC_AND_NOKTALAMA,KONTROLTYPE_ALPHA_AND_NUMERIC_AND_NOKTALAMA_TUMU}
	
	private static final int SPACEASCIIKOD = 32;
	private Set<Character> currentSet = new HashSet<Character>();
	private int maxSize ;
	private boolean boslukluMu;
	
	//baska turlu yaratilamasin
	private KarakterKontrolleri()
	{
		
	}
	
	public static KarakterKontrolleri KarakterKontrolleriYarat(int size,boolean boslukluMu) 
	{
		KarakterKontrolleri karakterKontrolleri = new KarakterKontrolleri();		
		karakterKontrolleri.setMaxSize(size);
		karakterKontrolleri.setBoslukluMu(boslukluMu);
		return karakterKontrolleri;
	}

	public static KarakterKontrolleri KarakterKontrolleriYarat(KontrolType kontrolType,int size,boolean boslukluMu) 
	{
		KarakterKontrolleri karakterKontrolleri = new KarakterKontrolleri();
		switch (kontrolType) {
		
		case KONTROLTYPE_NUMERIC:
			karakterKontrolleri.setCurrentSet(NUMERIC);
			break;
		case KONTROLTYPE_ALPHA:
			karakterKontrolleri.setCurrentSet(ALPHA);
			break;
		case KONTROLTYPE_TARIH:
			karakterKontrolleri.setCurrentSet(TARIH);
			break;
		case KONTROLTYPE_PARA:
			karakterKontrolleri.setCurrentSet(PARA);
			break;
		case KONTROLTYPE_ALPHA_AND_NUMERIC:
			karakterKontrolleri.getCurrentSet().addAll(NUMERIC);
			karakterKontrolleri.getCurrentSet().addAll(ALPHA);
			break;
		case KONTROLTYPE_IP:
			karakterKontrolleri.setCurrentSet(IP);
			break;
		case KONTROLTYPE_TARIH_TIMESTAMP:
			karakterKontrolleri.setCurrentSet(TARIH_TIMESTAMP);
			break;
		case KONTROLTYPE_SAAT:
			karakterKontrolleri.setCurrentSet(SAAT);
			break;
		case KONTROLTYPE_ALPHA_AND_NUMERIC_AND_NOKTALAMA:
			karakterKontrolleri.getCurrentSet().addAll(NUMERIC);
			karakterKontrolleri.getCurrentSet().addAll(ALPHA);
			karakterKontrolleri.getCurrentSet().addAll(NOKTALAMA);
			break;
		case KONTROLTYPE_ALPHA_AND_NUMERIC_AND_NOKTALAMA_TUMU:
			karakterKontrolleri.getCurrentSet().addAll(NUMERIC);
			karakterKontrolleri.getCurrentSet().addAll(ALPHA);
			karakterKontrolleri.getCurrentSet().addAll(NOKTALAMATUMU);
			break;	
		default:
			break;
		}
		karakterKontrolleri.setMaxSize(size);
		karakterKontrolleri.setBoslukluMu(boslukluMu);
		return karakterKontrolleri;
	}
	
	public Set getCurrentSet() {
		return currentSet;
	}
	public void setCurrentSet(Set<Character> currentSet) {
		this.currentSet = currentSet;
	}
	public int getMaxSize() {
		return maxSize;
	}
	public void setMaxSize(int maxSize) {
		this.maxSize = maxSize;
	}
	public boolean isBoslukluMu() {
		return boslukluMu;
	}
	public void setBoslukluMu(boolean boslukluMu) {
		this.boslukluMu = boslukluMu;
	}

	private static final Set<Character> NUMERIC = new HashSet<Character>();
	static {
		//numeric
		for(int i=48; i<=57; i++){
			NUMERIC.add( (char) i);
		}
	}
	//
	private static final Set<Character> TARIH=new HashSet<Character>();
	static {
		//numeric
		for(int i=48; i<=57; i++){
			TARIH.add((char) i);
		}
		TARIH.add((char)'-' );
		TARIH.add( (char)'.' );
		TARIH.add( (char)'/' );
	}
	//
	private static final Set<Character> PARA = new HashSet<Character>();
	static {
		//numeric
		for(int i=48; i<=57; i++){
			PARA.add( (char) i);
		}
		PARA.add((char)'+' );
		PARA.add( (char)',' );
		PARA.add( (char)'-' );
		PARA.add( (char)'.' );
	}
	//
	private static final Set<Character> IP =new HashSet<Character>();
	{
		//numeric
		for(int i=48; i<=57; i++){
			IP.add((char) i);
		}
		IP.add((char)'.' );
	}
	//
	private static final Set<Character> TARIH_TIMESTAMP = new HashSet<Character>();
	{
		//numeric
		for(int i=48; i<=57; i++){
			TARIH_TIMESTAMP.add(  (char) i);
		}
		TARIH_TIMESTAMP.add( (char)'-' );
		TARIH_TIMESTAMP.add( (char)'.' );
		TARIH_TIMESTAMP.add( (char)':' );
	}
	//
	private static final Set<Character> SAAT =new HashSet<Character>();
	{
		//numeric
		for(int i=48; i<=57; i++){
			SAAT.add( (char) i);
		}
		SAAT.add((char)'-' );
		SAAT.add( (char)':' );
	}
	//
	private static final Set<Character> ALPHA = new HashSet<Character>();
	static{
		//buyukHarf
		for(int i=65; i<=90; i++){
			ALPHA.add( (char) i);
		}
		//kucukHarf
		for(int i=97; i<=122; i++){
			ALPHA.add( (char) i);
		}
		//turkceKarakterler
		ALPHA.add( '\u00c7');	//C
		ALPHA.add( '\u00e7');	//c
		ALPHA.add( '\u011e');	//G
		ALPHA.add( '\u011f');	//g
		ALPHA.add( '\u015e');	//S
		ALPHA.add( '\u015f');	//s
		//
		ALPHA.add( '\u0130'); 	//I
		ALPHA.add( '\u0131');	//i
		ALPHA.add( '\u00d6');	//O
		ALPHA.add( '\u00f6');	//o
		ALPHA.add( '\u00dc');	//U
		ALPHA.add( '\u00fc');	//u
		//noktalama
		//ALPHA.put(44, (char)',' );
		//ALPHA.put(46, (char)'.' );
		//space
		//alpha.put(32, ' ');
	}
	private static final Set<Character> NOKTALAMATUMU = new HashSet<Character>();
	
	static {
		NOKTALAMATUMU.add( (char)'!' );
		NOKTALAMATUMU.add( (char)'"' );
		NOKTALAMATUMU.add( (char)'#' );
		NOKTALAMATUMU.add( (char)'$' );
		NOKTALAMATUMU.add( (char)'%' );
		NOKTALAMATUMU.add( (char)'&' );
		NOKTALAMATUMU.add( (char)'\'' );
		NOKTALAMATUMU.add( (char)'(' );
		NOKTALAMATUMU.add( (char)')' );
		NOKTALAMATUMU.add( (char)'*' );
		NOKTALAMATUMU.add( (char)'+' );
		NOKTALAMATUMU.add( (char)',' );
		NOKTALAMATUMU.add( (char)'-' );
		NOKTALAMATUMU.add( (char)'.' );
		NOKTALAMATUMU.add( (char)'/' );
		NOKTALAMATUMU.add( (char)':' );
		NOKTALAMATUMU.add( (char)';' );
		NOKTALAMATUMU.add( (char)'<' );
		NOKTALAMATUMU.add( (char)'=' );
		NOKTALAMATUMU.add( (char)'>' );
		NOKTALAMATUMU.add( (char)'?' );
		NOKTALAMATUMU.add( (char)'@' );
		NOKTALAMATUMU.add( (char)'[' );
		NOKTALAMATUMU.add( (char)'\\' );
		NOKTALAMATUMU.add( (char)']' );
		NOKTALAMATUMU.add( (char)'^' );
		NOKTALAMATUMU.add( (char)'_' );
		NOKTALAMATUMU.add( (char)'`' );
		NOKTALAMATUMU.add( (char)'{' );
		NOKTALAMATUMU.add( (char)'|' );
		NOKTALAMATUMU.add( (char)'}' );
		NOKTALAMATUMU.add( (char)'~' );
	}

	private static final Set<Character> NOKTALAMA = new HashSet<Character>();
	static {
			
		NOKTALAMA.add( (char)'!' );
		NOKTALAMA.add( (char)'(' );
		NOKTALAMA.add( (char)')' );
		NOKTALAMA.add( (char)',' );
		NOKTALAMA.add( (char)'-' );
		NOKTALAMA.add( (char)'.' );
		NOKTALAMA.add( (char)'/' );
		NOKTALAMA.add( (char)':' );
		NOKTALAMA.add( (char)';' );
		NOKTALAMA.add( (char)'?' );
		NOKTALAMA.add( (char)'\'' );
	}

	private static boolean isSpace(Character c){
		try {
			int a = (int) c;
			if(a == SPACEASCIIKOD)
				return true;
			else 
				return false;
		} catch (Exception e) {
			//e.printStackTrace();
		}
		return false;
	}
	

	private boolean check(Character c){
		try {
			
			if(isSpace(c)){
				return boslukluMu ? true : false;
			}
			if(currentSet.contains(c)){
				return true;
			}else{
				return false;
			}
		} catch (Exception e) {
			//e.printStackTrace();
		}
		return false;
	}




	private String getMaxUzunlukKontrol(String data){
		try {
			if(data!=null && data.trim().length()>0){
				if(data.trim().length()>maxSize){
					data = data.trim().substring(0,maxSize);
				}
			}
		} catch (Exception e) {
			//e.printStackTrace();
		}
		return data;
	}
	
	public String getGuvenlikKontrol(String data){
		
		if(data == null) return null;
		
		StringBuffer sb = new StringBuffer();
		try {
			if(data.trim().length()>0){
				data = data.trim();
				data = getMaxUzunlukKontrol(data);
				
				for (char c : data.toCharArray()){
					if(check(c))
					{
						sb = sb.append(c);
					}
				}
			}
		} catch (Exception e) {
			//e.printStackTrace();
		}
		return sb.toString();		
	}
	
	public String getGuvenlikKontrolContentType(String data)
	{
		if (data == null)
			return null;
		if (data.trim().length() > 0) 
		{
			data = getMaxUzunlukKontrol(data);
			data = data.trim().replaceAll("[^a-zA-Z0-9./-]", "");
		}

		return data;
	}
	
	public String getGuvenlikKontrolFileName(String data)
	{
		if (data == null)
			return null;
		if (data.trim().length() > 0) 
		{
			data = getMaxUzunlukKontrol(data);
			data = data.trim().replaceAll("[^a-zA-ZİÖÜŞÇĞıöüşçğ0-9._-]", "");
		}

		return data;
	}
	
	public String getGuvenlikKontrolIpAdres(String ip){
		
		if(ip != null){
			//IP adress pattern
			Pattern pattern = Pattern.compile("^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])$"); 
			
			Matcher matcher = pattern.matcher(ip);
			
			if(matcher.matches()){
				return ip;
			}else{
				return "IP_HATA";
			}				
		}else{
			return "";
		}	
	}
	
	public String getGuvenlikKontrolLog(String data)
	{
		if (data == null)
			return null;
		if (data.trim().length() > 0) 
		{
			data = getMaxUzunlukKontrol(data);
			data = data.trim().replaceAll("[\r\n%<>]", "");
		}

		return data;
	}
	
	public String getGuvenlikKontrolLog2(String data)
	{
		if (data == null)
			return null;
		if (data.trim().length() > 0) 
		{
			data = getMaxUzunlukKontrol(data);
			data = data.trim().replaceAll("[\r\n%<]", "");
		}

		return data;
	}

	
	public String getGuvenlikKontrolServerName(String data) 
	{
		if (data == null)
			return null;
		if (data.trim().length() > 0) {
			data = getMaxUzunlukKontrol(data);
			data = data.trim().replaceAll("[^0-9.:]", "");
		}

		return data;
	}
	
	public static void main(String[] args) {

	//	KarakterKontrolleri kk = KarakterKontrolleri.KarakterKontrolleriYarat(KontrolType.KONTROLTYPE_ALPHA, 100,true);		
	//	System.out.println(kk.getGuvenlikKontrol("1234564/*?0%¼$ aeiaeia  akeiuak 9hg ğk aiuy .yiş"));
		
		/*kk.getGuvenlikKontrol(data, bosluklu, maxUzunluk, tip)
	//	KarakterKontrolleri t3 = new KarakterKontrolleri();
		
		String sb = KarakterKontrolleri.getGuvenlikKontrol("1234564/*?0%¼$ aeiaeia  akeiuak 9hg ğk aiuy .yiş", true, 100, KarakterKontrolleri.LOG_ALPHA_AND_NUMERIC);
		String sb3 = KarakterKontrolleri.getGuvenlikKontrol("1234564/*?0%¼$ aeiaeia  akeiuak 9hg ğk aiuy .yiş", true, 100, KarakterKontrolleri.LOG_ALPHA_AND_NUMERIC_AND_NOKTALAMA_TUMU);
		String sb1 = KarakterKontrolleri.getGuvenlikKontrol("01/01/2012", true, 10, KarakterKontrolleri.LOG_TARIH);
		String sb2 = KarakterKontrolleri.getGuvenlikKontrol("255.054,54", true, 10, KarakterKontrolleri.LOG_PARA);
		System.out.println();
		System.out.println(sb.toString());
		System.out.println(sb3.toString());
		System.out.println(sb1.toString());
		System.out.println(sb2.toString());
		
		
		if(KarakterKontrolleri.ALPHA!=null){
			System.out.println(KarakterKontrolleri.ALPHA);
		}
		if(KarakterKontrolleri.NUMERIC!=null){
			System.out.println(KarakterKontrolleri.NUMERIC);
		}
		if(KarakterKontrolleri.TARIH!=null){
			System.out.println(KarakterKontrolleri.TARIH);
		}
		if(KarakterKontrolleri.PARA!=null){
			System.out.println(KarakterKontrolleri.PARA);
		}

	
		
		if(KarakterKontrolleri.PARA!=null){
			System.out.println(KarakterKontrolleri.PARA);
		}
		KarakterKontrolleri.getGuvenlikKontrol("dşkfjslkdjfksd ", true, 5, KarakterKontrolleri.LOG_ALPHA_AND_NUMERIC);
		*/
	/*	for( int i=0; i<256; i++){
			Character c =  (char) i;
			System.out.println(i + " - " + c + " - nv:"+ c.getNumericValue((char) i) + " - type:"+ c.getType((char) i)  );
			
		}*/
	/*	
		String xx=".,;:!?'-_/()[]\"";
	
		StringBuilder sb = new StringBuilder();
	    for (char c : xx.toCharArray()){
	    	sb.append((int)c);
	    	System.out.println((int)c + " - "+c);
	    	//System.out.println(isAlpha(c, false));
	    }*/ 	
	} 
}
