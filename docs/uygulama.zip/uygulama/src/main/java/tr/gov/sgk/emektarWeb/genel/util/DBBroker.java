package tr.gov.sgk.emektarWeb.genel.util;

import java.sql.Connection; 
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class DBBroker {  
	
	private static final Logger log = LoggerFactory.getLogger(DBBroker.class);
	
	public static String driver = "com.ibm.db2.jcc.DB2Driver";
	
	private static final String DATASOURCE_JNDI = "jdbc/EMEKTAR_DB"; // tek jndi oldu. server.xml de db properties ler dinamik yüklendiği için ortama göre connection alır dev, test veya prod
	private static Connection connection = null;

	private DBBroker() { 
  
	}
	
	private static void openConnection() throws NamingException, ClassNotFoundException {

		try {
			Context ctx = new InitialContext();
			DataSource ds = null;

			ds = (DataSource) ctx.lookup(DATASOURCE_JNDI);

			if (ds != null)
				connection = ds.getConnection();
			// System.out.println("DB Bağlantı kuruldu!!!");

			Class.forName(driver);
//			
//			if(SabitLokal.ortam.equalsIgnoreCase(Sabit.ortamProd)){
//				ds=(DataSource)ctx.lookup(urlProd);
//			}
//			if(SabitLokal.ortam.equalsIgnoreCase(Sabit.ortamTest)){
//				ds=(DataSource)ctx.lookup(urlTest);
//			}
//			if(SabitLokal.ortam.equalsIgnoreCase(Sabit.ortamLokal)){
//				ds=(DataSource)ctx.lookup(urlLokal);
//			}
//
//			if(ds != null){
//				connection=ds.getConnection();    
//			}
			
		} catch (SQLException e) {
			log.error(e.getMessage()); 
			//e.printStackTrace();
		}

	}

	public static Connection getConnection() throws NamingException, ClassNotFoundException {
		try {
			if (connection == null || connection.isClosed()) {
				openConnection();
			}
		} catch (SQLException e) {
			log.error(e.getMessage());
			//e.printStackTrace();
		}
		return connection;
	}
	
	
	public static void closeStatement(Statement statement) {
		try {
			if (statement != null)
				statement.close();
		} catch (Exception e) {
			log.error(e.getMessage());
			//e.printStackTrace();
		}	
	}
	
	public static void closeResultset(ResultSet resultSet) {
		try {
			if (resultSet != null)
				resultSet.close();
		} catch (Exception e) {
			log.error(e.getMessage());
			// throw new DBFactoryException(e.getMessage());
		}
	}
}
